import { useEffect, useRef } from 'react'

interface BeamGridConfig {
    gridSize?: number
    beamCount?: number
    extraBeamCount?: number
}

export function useBeamGrid(
    containerRef: React.RefObject<HTMLDivElement | null>,
    config: BeamGridConfig = {},
) {
    const canvasRef = useRef<HTMLCanvasElement>(null)

    useEffect(() => {
        const canvas = canvasRef.current
        const container = containerRef.current
        if (!canvas || !container) return

        const ctx = canvas.getContext('2d')
        if (!ctx) return

        const gridSize = config.gridSize ?? 40
        const beamCount = config.beamCount ?? 8
        const extraBeamCount = config.extraBeamCount ?? 3

        const rect = container.getBoundingClientRect()
        const dpr = window.devicePixelRatio || 1
        canvas.width = rect.width * dpr
        canvas.height = rect.height * dpr
        canvas.style.width = rect.width + 'px'
        canvas.style.height = rect.height + 'px'
        ctx.scale(dpr, dpr)

        const cols = Math.floor(rect.width / gridSize)
        const rows = Math.floor(rect.height / gridSize)

        // Pre-render grid
        const bgCanvas = document.createElement('canvas')
        bgCanvas.width = canvas.width
        bgCanvas.height = canvas.height
        const bgCtx = bgCanvas.getContext('2d')!
        bgCtx.scale(dpr, dpr)
        bgCtx.strokeStyle = '#1a1a1a'
        bgCtx.lineWidth = 1
        bgCtx.beginPath()
        for (let x = 0; x <= rect.width; x += gridSize) { bgCtx.moveTo(x, 0); bgCtx.lineTo(x, rect.height) }
        for (let y = 0; y <= rect.height; y += gridSize) { bgCtx.moveTo(0, y); bgCtx.lineTo(rect.width, y) }
        bgCtx.stroke()

        type Beam = { pos: number; dir: 'x' | 'y'; offset: number; speed: number; thickness: number }
        const beams: Beam[] = []
        for (let i = 0; i < beamCount; i++) {
            beams.push({
                pos: Math.floor(Math.random() * (Math.random() > 0.5 ? cols : rows)) * gridSize,
                dir: Math.random() > 0.5 ? 'x' : 'y',
                offset: Math.random() * Math.max(rect.width, rect.height),
                speed: 0.8 + Math.random() * 1.5,
                thickness: 3,
            })
        }
        for (let i = 0; i < extraBeamCount; i++) {
            beams.push({
                pos: Math.floor(Math.random() * (Math.random() > 0.5 ? cols : rows)) * gridSize,
                dir: Math.random() > 0.5 ? 'x' : 'y',
                offset: Math.random() * Math.max(rect.width, rect.height),
                speed: 0.4 + Math.random() * 0.5,
                thickness: 2,
            })
        }

        let mx = 0, my = 0, mouseIn = false, lastMouse = Date.now()
        const onMove = (e: MouseEvent) => {
            const r = container.getBoundingClientRect()
            mx = e.clientX - r.left; my = e.clientY - r.top
            mouseIn = true; lastMouse = Date.now()
        }
        const onLeave = () => { mouseIn = false }
        container.addEventListener('mousemove', onMove)
        container.addEventListener('mouseleave', onLeave)

        let animId: number
        const beamColor = 'rgba(0, 180, 255, 0.8)'

        const draw = () => {
            ctx.clearRect(0, 0, rect.width, rect.height)
            ctx.drawImage(bgCanvas, 0, 0, rect.width, rect.height)

            const idle = Date.now() - lastMouse > 2000
            const speedMult = idle ? 1.15 : 1

            beams.forEach(b => {
                ctx.strokeStyle = beamColor
                ctx.lineWidth = b.thickness
                ctx.shadowBlur = 50
                ctx.shadowColor = beamColor
                ctx.beginPath()
                const len = gridSize * 1.5
                if (b.dir === 'x') {
                    const start = -len + (b.offset % (rect.width + len))
                    ctx.moveTo(start, b.pos); ctx.lineTo(start + len, b.pos)
                    b.offset += b.speed * speedMult
                    if (b.offset > rect.width + len) b.offset = 0
                } else {
                    const start = -len + (b.offset % (rect.height + len))
                    ctx.moveTo(b.pos, start); ctx.lineTo(b.pos, start + len)
                    b.offset += b.speed * speedMult
                    if (b.offset > rect.height + len) b.offset = 0
                }
                ctx.stroke()
            })

            if (mouseIn && !idle) {
                const cx = Math.floor(mx / gridSize) * gridSize
                const cy = Math.floor(my / gridSize) * gridSize
                ctx.shadowBlur = 150; ctx.shadowColor = beamColor; ctx.strokeStyle = beamColor
                ctx.lineWidth = 9
                ctx.beginPath(); ctx.rect(cx, cy, gridSize, gridSize); ctx.stroke()
                ctx.lineWidth = 4.5; ctx.shadowBlur = 75
                for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
                    if (!dx && !dy) continue
                    const nx = cx + dx * gridSize, ny = cy + dy * gridSize
                    if (nx >= 0 && nx < rect.width && ny >= 0 && ny < rect.height) {
                        ctx.beginPath(); ctx.rect(nx, ny, gridSize, gridSize); ctx.stroke()
                    }
                }
                ctx.lineWidth = 2.25; ctx.shadowBlur = 37
                for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 2; dy++) {
                    if (Math.abs(dx) <= 1 && Math.abs(dy) <= 1) continue
                    const nx = cx + dx * gridSize, ny = cy + dy * gridSize
                    if (nx >= 0 && nx < rect.width && ny >= 0 && ny < rect.height) {
                        ctx.beginPath(); ctx.rect(nx, ny, gridSize, gridSize); ctx.stroke()
                    }
                }
            }

            ctx.shadowBlur = 0
            animId = requestAnimationFrame(draw)
        }
        draw()

        return () => {
            cancelAnimationFrame(animId)
            container.removeEventListener('mousemove', onMove)
            container.removeEventListener('mouseleave', onLeave)
        }
    }, [containerRef, config.gridSize, config.beamCount, config.extraBeamCount])

    return canvasRef
}
