import { useEffect, useRef } from 'react'

interface ShaderConfig {
    fragmentShader: string
    uniforms?: Record<string, 'vec2' | 'float'>
}

export function useWebGLShader(
    containerRef: React.RefObject<HTMLDivElement | null>,
    config: ShaderConfig,
    interactive = false,
) {
    const canvasRef = useRef<HTMLCanvasElement>(null)
    const mouseRef = useRef({ x: 0, y: 0 })

    useEffect(() => {
        const canvas = canvasRef.current
        const container = containerRef.current
        if (!canvas || !container) return

        const gl = canvas.getContext('webgl')
        if (!gl) return

        const vsSource = 'attribute vec4 a_position; void main() { gl_Position = a_position; }'

        function compile(type: number, src: string) {
            const s = gl!.createShader(type)
            if (!s) return null
            gl!.shaderSource(s, src)
            gl!.compileShader(s)
            if (!gl!.getShaderParameter(s, gl!.COMPILE_STATUS)) {
                console.error(gl!.getShaderInfoLog(s))
                gl!.deleteShader(s)
                return null
            }
            return s
        }

        const vs = compile(gl.VERTEX_SHADER, vsSource)
        const fs = compile(gl.FRAGMENT_SHADER, config.fragmentShader)
        if (!vs || !fs) return

        const prog = gl.createProgram()!
        gl.attachShader(prog, vs)
        gl.attachShader(prog, fs)
        gl.linkProgram(prog)
        if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return
        gl.useProgram(prog)

        const buf = gl.createBuffer()
        gl.bindBuffer(gl.ARRAY_BUFFER, buf)
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW)
        const pos = gl.getAttribLocation(prog, 'a_position')
        gl.enableVertexAttribArray(pos)
        gl.vertexAttribPointer(pos, 2, gl.FLOAT, false, 0, 0)

        const iResLoc = gl.getUniformLocation(prog, 'iResolution')
        const iTimeLoc = gl.getUniformLocation(prog, 'iTime')
        const iMouseLoc = gl.getUniformLocation(prog, 'iMouse')
        const start = Date.now()

        const onMouseMove = (e: MouseEvent) => {
            const r = container.getBoundingClientRect()
            mouseRef.current.x = e.clientX - r.left
            mouseRef.current.y = r.height - (e.clientY - r.top)
        }
        const onMouseLeave = () => { mouseRef.current.x = 0; mouseRef.current.y = 0 }

        if (interactive) {
            container.addEventListener('mousemove', onMouseMove)
            container.addEventListener('mouseleave', onMouseLeave)
        }

        let animId: number
        const render = () => {
            const w = container.clientWidth
            const h = container.clientHeight
            canvas.width = w
            canvas.height = h
            gl.viewport(0, 0, w, h)
            if (iResLoc) gl.uniform2f(iResLoc, w, h)
            if (iTimeLoc) gl.uniform1f(iTimeLoc, (Date.now() - start) / 1000)
            if (iMouseLoc) gl.uniform2f(iMouseLoc, mouseRef.current.x, mouseRef.current.y)
            gl.drawArrays(gl.TRIANGLES, 0, 6)
            animId = requestAnimationFrame(render)
        }
        render()

        return () => {
            cancelAnimationFrame(animId)
            if (interactive) {
                container.removeEventListener('mousemove', onMouseMove)
                container.removeEventListener('mouseleave', onMouseLeave)
            }
        }
    }, [config.fragmentShader, interactive, containerRef])

    return canvasRef
}
