import { useEffect, useRef } from 'react'

export function useInteractiveGrid(
    containerRef: React.RefObject<HTMLDivElement | null>,
) {
    const canvasRef = useRef<HTMLCanvasElement>(null)

    useEffect(() => {
        const canvas = canvasRef.current
        const container = containerRef.current
        if (!canvas || !container) return
        const ctx = canvas.getContext('2d')
        if (!ctx) return

        const gridSize = 50
        const trailLength = 3
        const idleSpeed = 0.2
        const glowRadius = 20
        const idleRandomCount = 5

        const rect = container.getBoundingClientRect()
        canvas.width = rect.width
        canvas.height = rect.height

        const cols = Math.floor(rect.width / gridSize)
        const rows = Math.floor(rect.height / gridSize)

        let trail: { x: number; y: number }[] = []
        let lastMouseTime = Date.now()

        let idleTargets = Array.from({ length: idleRandomCount }, () => ({
            x: Math.floor(Math.random() * cols), y: Math.floor(Math.random() * rows)
        }))
        let idlePositions = idleTargets.map(p => ({ ...p }))

        const onMove = (e: MouseEvent) => {
            const r = container.getBoundingClientRect()
            const rawX = e.clientX - r.left, rawY = e.clientY - r.top
            if (rawX < 0 || rawY < 0 || rawX > rect.width || rawY > rect.height) return
            lastMouseTime = Date.now()
            const sx = Math.floor(rawX / gridSize), sy = Math.floor(rawY / gridSize)
            const last = trail[0]
            if (!last || last.x !== sx || last.y !== sy) {
                trail.unshift({ x: sx, y: sy })
                if (trail.length > trailLength) trail.pop()
            }
        }
        container.addEventListener('mousemove', onMove)

        let animId: number
        const draw = () => {
            ctx.clearRect(0, 0, rect.width, rect.height)
            ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = 1
            for (let x = 0; x <= rect.width; x += gridSize) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, rect.height); ctx.stroke() }
            for (let y = 0; y <= rect.height; y += gridSize) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(rect.width, y); ctx.stroke() }

            if (Date.now() - lastMouseTime > 2000) {
                idlePositions.forEach((pos, i) => {
                    const t = idleTargets[i]
                    const dx = t.x - pos.x, dy = t.y - pos.y
                    if (Math.abs(dx) < 0.01 && Math.abs(dy) < 0.01) {
                        idleTargets[i] = { x: Math.floor(Math.random() * cols), y: Math.floor(Math.random() * rows) }
                    } else { pos.x += dx * idleSpeed; pos.y += dy * idleSpeed }
                    const rx = Math.round(pos.x), ry = Math.round(pos.y)
                    const last = trail[0]
                    if (!last || last.x !== rx || last.y !== ry) {
                        trail.unshift({ x: rx, y: ry })
                        if (trail.length > trailLength * idleRandomCount) trail.pop()
                    }
                })
            }

            trail.forEach((cell, idx) => {
                const alpha = 1 - idx * (1 / (trailLength + 1))
                const color = `rgba(255, 255, 255, ${alpha * 0.5})`
                ctx.fillStyle = color
                ctx.shadowColor = color
                ctx.shadowBlur = glowRadius
                ctx.fillRect(cell.x * gridSize, cell.y * gridSize, gridSize, gridSize)
            })
            ctx.shadowBlur = 0
            animId = requestAnimationFrame(draw)
        }
        draw()

        return () => {
            cancelAnimationFrame(animId)
            container.removeEventListener('mousemove', onMove)
        }
    }, [containerRef])

    return canvasRef
}
