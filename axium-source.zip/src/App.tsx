import { lazy, Suspense } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import Navbar from './components/Navbar'

// Lazy loaded pages
const Home = lazy(() => import('./pages/Home'))
const ThreeDElements = lazy(() => import('./pages/ThreeDElements'))
const Backgrounds = lazy(() => import('./pages/Backgrounds'))
const UIComponents = lazy(() => import('./pages/UIComponents'))
const Icons = lazy(() => import('./pages/Icons'))
const ColorPalette = lazy(() => import('./pages/ColorPalette'))
const Designs = lazy(() => import('./pages/Designs'))
const Minimalist = lazy(() => import('./pages/designs/Minimalist'))
const Bauhaus = lazy(() => import('./pages/designs/Bauhaus'))
const Modern = lazy(() => import('./pages/designs/Modern'))
const Newsprint = lazy(() => import('./pages/designs/Newsprint'))
const Terminal = lazy(() => import('./pages/designs/Terminal'))
const Swiss = lazy(() => import('./pages/designs/Swiss'))
const Luxury = lazy(() => import('./pages/designs/Luxury'))
const MinimalistModern = lazy(() => import('./pages/designs/MinimalistModern'))
const TextAnimations = lazy(() => import('./pages/TextAnimations'))
const Buttons = lazy(() => import('./pages/Buttons'))

// Loading Fallback
const PageLoader = () => (
    <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000' }}>
        <div style={{ width: '40px', height: '40px', border: '2px solid rgba(255,255,255,0.1)', borderTopColor: '#6366f1', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
)

import { SplashScreen } from './components/UI/SplashScreen'

export default function App() {
    const location = useLocation()
    const hideNav = location.pathname.startsWith('/website-designs/') && location.pathname !== '/website-designs'

    return (
        <SplashScreen>
            {!hideNav && <Navbar />}
            <Suspense fallback={<PageLoader />}>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/3d-elements" element={<ThreeDElements />} />
                    <Route path="/backgrounds" element={<Backgrounds />} />
                    <Route path="/ui-components" element={<UIComponents />} />
                    <Route path="/text-animations" element={<TextAnimations />} />
                    <Route path="/buttons" element={<Buttons />} />
                    <Route path="/icons" element={<Icons />} />
                    <Route path="/color-palette" element={<ColorPalette />} />
                    <Route path="/website-designs" element={<Designs />} />
                    <Route path="/website-designs/minimalist-monochrome" element={<Minimalist />} />
                    <Route path="/website-designs/bauhaus" element={<Bauhaus />} />
                    <Route path="/website-designs/modern" element={<Modern />} />
                    <Route path="/website-designs/newsprint" element={<Newsprint />} />
                    <Route path="/website-designs/terminal-cli" element={<Terminal />} />
                    <Route path="/website-designs/swiss-international-typographic-style" element={<Swiss />} />
                    <Route path="/website-designs/luxury-editorial" element={<Luxury />} />
                    <Route path="/website-designs/minimalist-modern" element={<MinimalistModern />} />
                </Routes>
            </Suspense>
        </SplashScreen>
    )
}
