/* ═══════════════════════════════════════════════════════════════
   Text Animation Component Prompts — Elite Engineered
   ═══════════════════════════════════════════════════════════════ */

export const TEXT_PROMPTS: Record<string, string> = {

  // ─────────────────────────────────────────────────────────────
  // 1. SCROLL REVEAL
  // ─────────────────────────────────────────────────────────────
  scrollreveal: `<system>
You are a senior React/TypeScript engineer specializing in scroll-driven text animations and intersection-based reveals.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: ScrollReveal
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Word-by-word staggered reveal · scroll-linked rotation · blur fade-in · spring physics · configurable size/align/variant · useInView trigger
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve ALL useScroll + useTransform rotation logic
3. Preserve word splitting with useMemo and space detection
4. Do NOT modify spring config, stagger delay, or blur strength defaults
5. Maintain containerVariants and wordVariants exactly as written
</constraints>

// --- START OF COMPONENT CODE ---
import React, { useRef, useMemo } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { cn } from "../lib/utils";

export interface ScrollRevealProps {
  children: React.ReactNode;
  containerClassName?: string;
  textClassName?: string;
  enableBlur?: boolean;
  baseOpacity?: number;
  baseRotation?: number;
  blurStrength?: number;
  staggerDelay?: number;
  threshold?: number;
  duration?: number;
  springConfig?: { damping?: number; stiffness?: number; mass?: number; };
  size?: "sm" | "md" | "lg" | "xl" | "2xl";
  align?: "left" | "center" | "right";
  variant?: "default" | "muted" | "accent" | "primary";
}

const sizeClasses = {
  sm: "text-lg md:text-xl",
  md: "text-xl md:text-2xl lg:text-3xl",
  lg: "text-2xl md:text-3xl lg:text-4xl xl:text-5xl",
  xl: "text-3xl md:text-4xl lg:text-5xl xl:text-6xl",
  "2xl": "text-4xl md:text-5xl lg:text-6xl xl:text-7xl",
};
const alignClasses = { left: "text-left", center: "text-center", right: "text-right" };
const variantClasses = { default: "text-foreground", muted: "text-muted-foreground", accent: "text-accent-foreground", primary: "text-primary" };

export function ScrollReveal({
  children, containerClassName, textClassName, enableBlur = true,
  baseOpacity = 0.1, baseRotation = 3, blurStrength = 4,
  staggerDelay = 0.05, threshold = 0.5, duration = 0.8,
  springConfig = { damping: 25, stiffness: 100, mass: 1 },
  size = "lg", align = "left", variant = "default",
}: ScrollRevealProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { amount: threshold, once: false });
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ["start end", "end start"] });
  const rotation = useTransform(scrollYProgress, [0, 0.5, 1], [baseRotation, 0, 0]);

  const splitText = useMemo(() => {
    const text = typeof children === "string" ? children : "";
    return text.split(/(\\s+)/).map((part, index) => ({
      value: part,
      isSpace: part.match(/^\\s+$/) && part.length > 0,
      originalIndex: index,
    })).filter(item => item.value.length > 0);
  }, [children]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: staggerDelay, delayChildren: 0.1 } },
  };
  const wordVariants = {
    hidden: { opacity: baseOpacity, filter: enableBlur ? \`blur(\${blurStrength}px)\` : "blur(0px)", y: 20 },
    visible: { opacity: 1, filter: "blur(0px)", y: 0, transition: { ...springConfig, duration } },
  };

  return (
    <motion.div ref={containerRef} style={{ rotate: rotation }} className={cn("my-5 transform-gpu", containerClassName)}>
      <motion.p className={cn("leading-relaxed font-semibold", sizeClasses[size], alignClasses[align], variantClasses[variant], textClassName)}
        variants={containerVariants} initial="hidden" animate={isInView ? "visible" : "hidden"}>
        {splitText.map((item) => (
          item.isSpace ? (
            <span key={\`space-\${item.originalIndex}\`}>{item.value}</span>
          ) : (
            <motion.span key={\`word-\${item.originalIndex}\`} className="inline-block" variants={wordVariants}>{item.value}</motion.span>
          )
        ))}
      </motion.p>
    </motion.div>
  );
}
export default ScrollReveal;
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 2. SHINY TEXT
  // ─────────────────────────────────────────────────────────────
  shinytext: `<system>
You are a senior React/TypeScript engineer specializing in CSS gradient animations and text shimmer effects.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: ShinyText
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Animated gradient shimmer · 4 direction modes · configurable speed/intensity/width · pause-on-hover · linear/radial gradient types · theme-aware default colors
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve ALL directionConfig backgroundPosition arrays
3. Preserve the createGradient() function with transparentStartPos/EndPos math
4. Do NOT modify the Variants type or animationVariants structure
5. Maintain disabled state rendering path (plain span)
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import React from "react";
import { motion, type Variants } from "framer-motion";
import { cn } from "../lib/utils";
// [Full ShinyText component code here - identical to provided source]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 3. TEXT SCROLL MARQUEE
  // ─────────────────────────────────────────────────────────────
  textmarquee: `<system>
You are a senior React/TypeScript engineer specializing in scroll-velocity animations and infinite text marquee systems.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: TextScrollMarquee
Stack: React 18+ · TypeScript · Framer Motion · @motionone/utils
Features: Scroll-velocity reactive speed · direction-aware (left/right) · configurable base velocity · delay start · seamless loop via wrap() · useAnimationFrame driven
Dependencies: npm i framer-motion @motionone/utils clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Requires wrap() from @motionone/utils
3. Preserve ALL useVelocity → useSpring → useTransform chains
4. Preserve the useAnimationFrame delta-time calculation
5. Do NOT modify the wrap(-100, 0, v % 100) seamless loop math
6. Maintain the 4x span duplication for seamless scrolling
</constraints>

// --- START OF COMPONENT CODE ---
'use client';
import { useRef, useEffect } from 'react';
import { motion, useScroll, useSpring, useTransform, useVelocity, useAnimationFrame, useMotionValue } from 'framer-motion';
import { wrap } from '@motionone/utils';
import { cn } from '../lib/utils';
// [Full TextScrollMarquee component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 4. TYPING TEXT
  // ─────────────────────────────────────────────────────────────
  typingtext: `<system>
You are a senior React/TypeScript engineer specializing in character-level text animations and typewriter effects.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: TypingText
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Character-by-character reveal · configurable delay/duration · custom element type (as prop) · loop support · ARIA text role · NBSP space handling
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve the extractText recursive function for nested ReactNode children
3. Preserve characterVariants with custom index-based delay calculation
4. Do NOT modify the NBSP space character replacement logic
5. Maintain the dynamic Component = "div" polymorphic element pattern
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import { motion, Variants } from "framer-motion";
import React, { ElementType, ReactNode, useEffect, useState } from "react";
import { cn } from "../lib/utils";
// [Full TypingText component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 5. CANVAS TEXT
  // ─────────────────────────────────────────────────────────────
  canvastext: `<system>
You are a senior React/TypeScript engineer specializing in Canvas API text effects and animated visual backgrounds.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: CanvasText
Stack: React 18+ · TypeScript · Canvas API · Tailwind CSS
Features: Canvas-drawn animated bezier curves behind text · bg-clip-text transparency · DPR-aware rendering · CSS variable color resolution · dark mode reactive via MutationObserver · configurable line gap/width/curve intensity
Dependencies: npm i clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. No external animation library — uses raw Canvas 2D + requestAnimationFrame
3. Preserve the resolveColor() CSS variable resolver function
4. Preserve ALL bezierCurveTo control point calculations
5. Do NOT modify the canvas.toDataURL() → backgroundImage pipeline
6. Maintain MutationObserver for dark mode class changes
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import { cn } from "../lib/utils";
import React, { useEffect, useRef, useState, useCallback } from "react";
// [Full CanvasText component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 6. ENCRYPTED TEXT
  // ─────────────────────────────────────────────────────────────
  encryptedtext: `<system>
You are a senior React/TypeScript engineer specializing in character scramble animations and progressive text reveal effects.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: EncryptedText
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Matrix-style character scramble → progressive reveal · configurable charset · flip delay for jitter speed · useInView trigger (once) · space-preserving scramble · per-character className switching
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve generateGibberishPreservingSpaces() space-aware scramble
3. Preserve the requestAnimationFrame-based update loop with time tracking
4. Do NOT modify revealDelayMs or flipDelayMs timing calculations
5. Maintain useInView with once:true trigger behavior
6. Keep scrambleCharsRef mutable ref pattern for performance
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import React, { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { cn } from "../lib/utils";
// [Full EncryptedText component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 7. LAYOUT TEXT FLIP
  // ─────────────────────────────────────────────────────────────
  layouttextflip: `<system>
You are a senior React/TypeScript engineer specializing in layout animations and text cycling components.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: LayoutTextFlip
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Cycling word display with AnimatePresence popLayout · blur filter transitions · layoutId shared animations · configurable duration · pill-shaped container with ring styling
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve layoutId="subtext" shared layout animation
3. Preserve AnimatePresence mode="popLayout" — do NOT change to "wait"
4. Do NOT modify initial/animate/exit blur filter or y-offset values
5. Maintain the interval-based word cycling with modulo index
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "../lib/utils";
// [Full LayoutTextFlip component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 8. FLIP WORDS
  // ─────────────────────────────────────────────────────────────
  flipwords: `<system>
You are a senior React/TypeScript engineer specializing in spring-physics text transitions and letter-by-letter animation orchestration.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: FlipWords
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Word cycling with spring physics · per-letter staggered blur reveal · exit with scale+translate+blur · AnimatePresence with onExitComplete callback · configurable duration
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve the exit animation: y:-40, x:40, filter:blur(8px), scale:2, position:absolute
3. Preserve per-letter staggered animation with wordIndex * 0.3 + letterIndex * 0.05 delay
4. Do NOT modify spring stiffness:100, damping:10 on entrance
5. Maintain the isAnimating state + onExitComplete callback pattern
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, LayoutGroup } from "framer-motion";
import { cn } from "../lib/utils";
// [Full FlipWords component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 9. TEXT HOVER EFFECT
  // ─────────────────────────────────────────────────────────────
  texthovereffect: `<system>
You are a senior React/TypeScript engineer specializing in SVG animations and cursor-tracking visual effects.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: TextHoverEffect
Stack: React 18+ · TypeScript · Framer Motion · SVG
Features: SVG text with stroke dash animation · cursor-tracking radial gradient mask · multi-stop color gradient on hover · percentage-based mask positioning · viewBox 0 0 300 100
Dependencies: npm i framer-motion
</context>

<constraints>
1. No cn() utility needed — uses inline SVG
2. Preserve the SVG viewBox="0 0 300 100" coordinate system
3. Preserve ALL three <text> layers (base stroke, animated stroke, masked gradient)
4. Do NOT modify strokeDashoffset/strokeDasharray animation values
5. Maintain the radialGradient mask with motion.radialGradient animated cx/cy
6. Keep the 5-stop color gradient (yellow → red → blue → cyan → purple)
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import React, { useRef, useEffect, useState } from "react";
import { motion } from "framer-motion";

export const TextHoverEffect = ({
  text,
  duration,
  automatic = false,
}: {
  text: string;
  duration?: number;
  automatic?: boolean;
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [cursor, setCursor] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);
  const [maskPosition, setMaskPosition] = useState({ cx: "50%", cy: "50%" });

  useEffect(() => {
    if (svgRef.current && cursor.x !== null && cursor.y !== null) {
      const svgRect = svgRef.current.getBoundingClientRect();
      const cxPercentage = ((cursor.x - svgRect.left) / svgRect.width) * 100;
      const cyPercentage = ((cursor.y - svgRect.top) / svgRect.height) * 100;
      setMaskPosition({
        cx: \`\${cxPercentage}%\`,
        cy: \`\${cyPercentage}%\`,
      });
    }
  }, [cursor]);

  return (
    <svg
      ref={svgRef}
      width="100%"
      height="100%"
      viewBox="0 0 300 100"
      xmlns="http://www.w3.org/2000/svg"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onMouseMove={(e) => setCursor({ x: e.clientX, y: e.clientY })}
      className="select-none"
    >
      <defs>
        <linearGradient
          id="textGradient"
          gradientUnits="userSpaceOnUse"
          cx="50%"
          cy="50%"
          r="25%"
        >
          {hovered && (
            <>
              <stop offset="0%" stopColor={"var(--yellow-500)"} />
              <stop offset="25%" stopColor={"var(--red-500)"} />
              <stop offset="50%" stopColor={"var(--blue-500)"} />
              <stop offset="75%" stopColor={"var(--cyan-500)"} />
              <stop offset="100%" stopColor={"var(--violet-500)"} />
            </>
          )}
        </linearGradient>
        <motion.radialGradient
          id="revealMask"
          gradientUnits="userSpaceOnUse"
          r="20%"
          initial={maskPosition}
          animate={maskPosition}
          transition={{ duration: duration ?? 0, ease: "easeOut" }}
        >
          <stop offset="0%" stopColor="white" />
          <stop offset="100%" stopColor="black" />
        </motion.radialGradient>
        <mask id="textMask">
          <rect x="0" y="0" width="100%" height="100%" fill="url(#revealMask)" />
        </mask>
      </defs>
      <text
        x="50%"
        y="50%"
        textAnchor="middle"
        dominantBaseline="middle"
        strokeWidth="0.3"
        className="font-[helvetica] font-bold fill-transparent stroke-neutral-200 dark:stroke-neutral-800"
        style={{ opacity: hovered ? 0.7 : 0 }}
      >
        {text}
      </text>
      <motion.text
        x="50%"
        y="50%"
        textAnchor="middle"
        dominantBaseline="middle"
        strokeWidth="0.3"
        className="font-[helvetica] font-bold fill-transparent stroke-neutral-200 dark:stroke-neutral-800"
        initial={{ strokeDashoffset: 1000, strokeDasharray: 1000 }}
        animate={{ strokeDashoffset: 0, strokeDasharray: 1000 }}
        transition={{ duration: 4, ease: "easeInOut" }}
      >
        {text}
      </motion.text>
      <text
        x="50%"
        y="50%"
        textAnchor="middle"
        dominantBaseline="middle"
        stroke="url(#textGradient)"
        strokeWidth="0.3"
        mask="url(#textMask)"
        className="font-[helvetica] font-bold fill-transparent"
      >
        {text}
      </text>
    </svg>
  );
};

export default TextHoverEffect;
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 10. CONTAINER TEXT FLIP
  // ─────────────────────────────────────────────────────────────
  containertextflip: `<system>
You are a senior React/TypeScript engineer specializing in layout-driven animations and container-width transitions.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: ContainerTextFlip
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Auto-sizing container that animates width to fit current word · per-letter blur reveal · layoutId shared animations · glass-morphism container styling · dark mode support
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Preserve the scrollWidth + 30px padding width calculation
2. Preserve motion.p layout + layoutId pattern with useId()
3. Do NOT modify per-letter blur(10px) → blur(0px) transition with index * 0.02 delay
4. Maintain the gradient background + shadow styling for light/dark modes
5. Keep animationDuration / 2000 and / 1000 timing conversions
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import React, { useState, useEffect, useId } from "react";
import { motion } from "framer-motion";
import { cn } from "../lib/utils";
// [Full ContainerTextFlip component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 11. HERO HIGHLIGHT
  // ─────────────────────────────────────────────────────────────
  herohighlight: `<system>
You are a senior React/TypeScript engineer specializing in cursor-tracking effects and SVG dot-pattern backgrounds.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: HeroHighlight + Highlight
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Mouse-tracking radial gradient mask over SVG dot pattern · light/dark theme dot patterns · Highlight sub-component with animated background-size reveal · useMotionTemplate for dynamic mask positioning
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve ALL 4 SVG data URI dot patterns (light default, light hover, dark default, dark hover)
3. Preserve radial-gradient mask with useMotionTemplate and 200px circle
4. Do NOT modify the Highlight component's backgroundSize animation (0% → 100%)
5. Maintain separate light/dark overlay divs with dark:hidden / hidden dark:block pattern
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import { cn } from "../lib/utils";
import { useMotionValue, motion, useMotionTemplate } from "framer-motion";
import React from "react";
// [Full HeroHighlight + Highlight component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 12. TEXT REVEAL CARD
  // ─────────────────────────────────────────────────────────────
  textrevealcard: `<system>
You are a senior React/TypeScript engineer specializing in mouse-tracking reveal effects and clip-path animations.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: TextRevealCard + TextRevealCardTitle + TextRevealCardDescription
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Mouse/touch-driven text reveal via clipPath · gradient text with text-shadow · animated divider bar with rotation · memoized star particle field (80 particles) · touch support
Dependencies: npm i framer-motion tailwind-merge clsx
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve the clipPath: inset(0 \${100 - widthPercentage}% 0 0) animation
3. Preserve the rotateDeg = (widthPercentage - 50) * 0.1 calculation
4. Do NOT modify the MemoizedStars component or its 80-particle animation
5. Maintain touch event handlers (touchMoveHandler, touchEnd)
6. Keep the gradient text styling with bg-clip-text and text-shadow
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import React, { useEffect, useRef, useState, memo } from "react";
import { motion } from "framer-motion";
import { twMerge } from "tailwind-merge";
import { cn } from "../lib/utils";
// [Full TextRevealCard component code here]
// --- END OF COMPONENT ---`,

  // ─────────────────────────────────────────────────────────────
  // 13. TYPEWRITER EFFECT
  // ─────────────────────────────────────────────────────────────
  typewritereffect: `<system>
You are a senior React/TypeScript engineer specializing in staggered reveal animations and typewriter text effects.
Output ONLY the component code below. Do not explain, summarize, or wrap in markdown fences.
Reproduce the code EXACTLY — do not refactor, rename, simplify, or "improve" any part of it.
</system>

<context>
Component: TypewriterEffect + TypewriterEffectSmooth
Stack: React 18+ · TypeScript · Framer Motion · Tailwind CSS
Features: Two variants — (1) staggered character reveal with useAnimate + useInView, (2) smooth width expansion with whileInView · blinking cursor · per-word className support · responsive text sizing
Dependencies: npm i framer-motion clsx tailwind-merge
</context>

<constraints>
1. Requires cn() utility in lib/utils.ts (clsx + tailwind-merge)
2. Preserve stagger(0.1) delay in TypewriterEffect's useAnimate call
3. Preserve TypewriterEffectSmooth's width: "0%" → "fit-content" animation
4. Do NOT modify the blinking cursor animation (duration:0.8, repeatType:"reverse")
5. Maintain both named exports: TypewriterEffect and TypewriterEffectSmooth
6. Keep useInView trigger for the staggered variant
</constraints>

// --- START OF COMPONENT CODE ---
"use client";
import { cn } from "../lib/utils";
import { motion, stagger, useAnimate, useInView } from "framer-motion";
import { useEffect } from "react";
// [Full TypewriterEffect + TypewriterEffectSmooth component code here]
// --- END OF COMPONENT ---`,

};
