/* ═══════════════════════════════════════════════════════════════
   Button Component Prompts — Elite Engineered
   ═══════════════════════════════════════════════════════════════ */

export const BUTTON_PROMPTS: Record<string, string> = {

    btn_sketch: `<system>You are a senior frontend engineer specializing in micro-interaction button design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Sketch — offset box-shadow on hover, sharp border, white bg, black text.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve exact shadow values: 4px_4px_0px_0px_rgba(0,0,0)
2. Keep transition duration-200
3. Maintain rounded-md border-black</constraints>

// --- START ---
<button className="px-4 py-2 rounded-md border border-black bg-white text-black text-sm hover:shadow-[4px_4px_0px_0px_rgba(0,0,0)] transition duration-200">
  Sketch
</button>
// --- END ---`,

    btn_simple: `<system>You are a senior frontend engineer specializing in micro-interaction button design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Simple — subtle lift on hover with translate-y and shadow.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve hover:-translate-y-1 transform
2. Keep neutral-300 border, neutral-100 bg, neutral-500 text
3. Maintain rounded-md and duration-200</constraints>

// --- START ---
<button className="px-4 py-2 rounded-md border border-neutral-300 bg-neutral-100 text-neutral-500 text-sm hover:-translate-y-1 transform transition duration-200 hover:shadow-md">
  Simple
</button>
// --- END ---`,

    btn_invert: `<system>You are a senior frontend engineer specializing in micro-interaction button design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Invert — teal bg inverts to white on hover with border reveal.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve teal-500 → white color inversion
2. Keep border-2 border-transparent → hover:border-teal-500
3. Maintain font-bold and rounded-md</constraints>

// --- START ---
<button className="px-8 py-2 rounded-md bg-teal-500 text-white font-bold transition duration-200 hover:bg-white hover:text-black border-2 border-transparent hover:border-teal-500">
  Invert it
</button>
// --- END ---`,

    btn_connect: `<system>You are a senior frontend engineer specializing in premium pill-button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Tailwind Connect — pill with radial gradient glow on hover, ring border, arrow icon.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve the radial-gradient at 75% 100% at 50% 0% with rgba(56,189,248)
2. Keep ring-1 ring-white/10 on inner div
3. Maintain bottom emerald-400 gradient line
4. Preserve the SVG arrow icon path exactly</constraints>

// --- START ---
<button className="bg-slate-800 no-underline group cursor-pointer relative shadow-2xl shadow-zinc-900 rounded-full p-px text-xs font-semibold leading-6 text-white inline-block">
  <span className="absolute inset-0 overflow-hidden rounded-full">
    <span className="absolute inset-0 rounded-full bg-[image:radial-gradient(75%_100%_at_50%_0%,rgba(56,189,248,0.6)_0%,rgba(56,189,248,0)_75%)] opacity-0 transition-opacity duration-500 group-hover:opacity-100"></span>
  </span>
  <div className="relative flex space-x-2 items-center z-10 rounded-full bg-zinc-950 py-0.5 px-4 ring-1 ring-white/10">
    <span>Tailwind Connect</span>
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M10.75 8.75L14.25 12L10.75 15.25"></path>
    </svg>
  </div>
  <span className="absolute -bottom-0 left-[1.125rem] h-px w-[calc(100%-2.25rem)] bg-gradient-to-r from-emerald-400/0 via-emerald-400/90 to-emerald-400/0 transition-opacity duration-500 group-hover:opacity-40"></span>
</button>
// --- END ---`,

    btn_gradient: `<system>You are a senior frontend engineer specializing in micro-interaction button design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Gradient — rounded-full pill with blue gradient, focus ring, hover shadow.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve bg-gradient-to-b from-blue-500 to-blue-600
2. Keep focus:ring-2 focus:ring-blue-400
3. Maintain rounded-full and hover:shadow-xl</constraints>

// --- START ---
<button className="px-8 py-2 rounded-full bg-gradient-to-b from-blue-500 to-blue-600 text-white focus:ring-2 focus:ring-blue-400 hover:shadow-xl transition duration-200">
  Gradient
</button>
// --- END ---`,

    btn_unapologetic: `<system>You are a senior frontend engineer specializing in creative offset-shadow button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Unapologetic — sharp corners, yellow offset background that slides to zero on hover.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve yellow-300 offset div at -bottom-2 -right-2
2. Keep group-hover:bottom-0 group-hover:right-0 transition
3. Maintain dark:border-white support
4. Keep -z-10 on offset div</constraints>

// --- START ---
<button className="px-8 py-2 border border-black bg-transparent text-black dark:border-white relative group transition duration-200">
  <div className="absolute -bottom-2 -right-2 bg-yellow-300 h-full w-full -z-10 group-hover:bottom-0 group-hover:right-0 transition-all duration-200" />
  <span className="relative">Unapologetic</span>
</button>
// --- END ---`,

    btn_litup: `<system>You are a senior frontend engineer specializing in gradient-border button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Lit Up Borders — gradient border via layered divs, inner black bg turns transparent on hover.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve p-[3px] outer wrapper with relative positioning
2. Keep indigo-500 to purple-500 gradient on absolute inset-0 div
3. Maintain hover:bg-transparent on inner div
4. Keep rounded-lg outer, rounded-[6px] inner</constraints>

// --- START ---
<button className="p-[3px] relative">
  <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
  <div className="px-8 py-2 bg-black rounded-[6px] relative group transition duration-200 text-white hover:bg-transparent">
    Lit up borders
  </div>
</button>
// --- END ---`,

    btn_bordermagic: `<system>You are a senior frontend engineer specializing in animated border effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Border Magic — spinning conic gradient border, pill shape, backdrop blur.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve animate-[spin_2s_linear_infinite] on gradient span
2. Keep conic-gradient from 90deg with #E2CBFF and #393BB2
3. Maintain inset-[-1000%] for oversized gradient
4. Keep backdrop-blur-3xl on inner span</constraints>

// --- START ---
<button className="relative inline-flex h-12 overflow-hidden rounded-full p-[1px] focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-50">
  <span className="absolute inset-[-1000%] animate-[spin_2s_linear_infinite] bg-[conic-gradient(from_90deg_at_50%_50%,#E2CBFF_0%,#393BB2_50%,#E2CBFF_100%)]" />
  <span className="inline-flex h-full w-full cursor-pointer items-center justify-center rounded-full bg-slate-950 px-3 py-1 text-sm font-medium text-white backdrop-blur-3xl">
    Border Magic
  </span>
</button>
// --- END ---`,

    btn_brutal: `<system>You are a senior frontend engineer specializing in brutalist UI design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Brutal — stacked multi-layer box-shadow, uppercase, dark mode support.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve ALL 5 shadow layers: 1px through 5px
2. Keep dark:shadow with rgba(255,255,255) values
3. Maintain uppercase, border-2, and text-sm
4. Keep dark:border-white</constraints>

// --- START ---
<button className="px-8 py-0.5 border-2 border-black dark:border-white uppercase bg-white text-black transition duration-200 text-sm shadow-[1px_1px_rgba(0,0,0),2px_2px_rgba(0,0,0),3px_3px_rgba(0,0,0),4px_4px_rgba(0,0,0),5px_5px_0px_0px_rgba(0,0,0)] dark:shadow-[1px_1px_rgba(255,255,255),2px_2px_rgba(255,255,255),3px_3px_rgba(255,255,255),4px_4px_rgba(255,255,255),5px_5px_0px_0px_rgba(255,255,255)]">
  Brutal
</button>
// --- END ---`,

    btn_favourite: `<system>You are a senior frontend engineer specializing in micro-interaction button design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Favourite — solid black, rounded-md, darkens slightly on hover with shadow.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve bg-black hover:bg-black/[0.8]
2. Keep font-semibold and rounded-md
3. Maintain hover:shadow-lg</constraints>

// --- START ---
<button className="px-8 py-2 bg-black text-white text-sm rounded-md font-semibold hover:bg-black/[0.8] hover:shadow-lg">
  Favourite
</button>
// --- END ---`,

    btn_outline: `<system>You are a senior frontend engineer specializing in micro-interaction button design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Outline — neutral border, white bg, subtle gray on hover.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve border-neutral-600 and rounded-xl
2. Keep hover:bg-gray-100 transition
3. Maintain bg-white text-black</constraints>

// --- START ---
<button className="px-4 py-2 rounded-xl border border-neutral-600 text-black bg-white hover:bg-gray-100 transition duration-200">
  Outline
</button>
// --- END ---`,

    btn_shimmer: `<system>You are a senior frontend engineer specializing in animated gradient button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Shimmer — animated diagonal gradient sweep, dark theme, slate tones.
Stack: React · Tailwind CSS · Requires custom shimmer keyframe animation.
Keyframes: shimmer animation moves backgroundPosition from 0 0 to -200% 0 over 2s linear infinite.</context>
<constraints>
1. Preserve bg-[linear-gradient(110deg,#000103,45%,#1e2631,55%,#000103)]
2. Keep bg-[length:200%_100%] for animation range
3. Maintain animate-shimmer class (requires tailwind config)
4. Keep border-slate-800 and text-slate-400
5. REQUIRED: Add shimmer keyframe to tailwind config</constraints>

// --- START ---
<button className="inline-flex h-12 animate-shimmer items-center justify-center rounded-md border border-slate-800 bg-[linear-gradient(110deg,#000103,45%,#1e2631,55%,#000103)] bg-[length:200%_100%] px-6 font-medium text-slate-400 transition-colors focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-50">
  Shimmer
</button>

/* tailwind.config.js — add to theme.extend: */
// animation: { shimmer: "shimmer 2s linear infinite" }
// keyframes: { shimmer: { from: { backgroundPosition: "0 0" }, to: { backgroundPosition: "-200% 0" } } }
// --- END ---`,

    btn_nextblue: `<system>You are a senior frontend engineer specializing in brand-styled button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Next.js Blue — brand blue with glow shadow, lighter on hover.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve bg-[#0070f3] and exact shadow values
2. Keep hover:shadow with rgba(0,118,255,23%)
3. Maintain font-light and rounded-md</constraints>

// --- START ---
<button className="shadow-[0_4px_14px_0_rgb(0,118,255,39%)] hover:shadow-[0_6px_20px_rgba(0,118,255,23%)] hover:bg-[rgba(0,118,255,0.9)] px-8 py-2 bg-[#0070f3] rounded-md text-white font-light transition duration-200 ease-linear">
  Next.js Blue
</button>
// --- END ---`,

    btn_nextwhite: `<system>You are a senior frontend engineer specializing in brand-styled button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Next.js White — white bg, gray text, subtle shadow on hover.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve bg-[#fff] and text-[#696969]
2. Keep exact shadow-[0_4px_14px_0_rgb(0,0,0,10%)] values
3. Maintain font-light and rounded-md</constraints>

// --- START ---
<button className="shadow-[0_4px_14px_0_rgb(0,0,0,10%)] hover:shadow-[0_6px_20px_rgba(93,93,93,23%)] px-8 py-2 bg-[#fff] text-[#696969] rounded-md font-light transition duration-200 ease-linear">
  Next White
</button>
// --- END ---`,

    btn_spotify: `<system>You are a senior frontend engineer specializing in brand-styled button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Spotify — Spotify green pill, scale-up on hover, uppercase bold tracking.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve bg-[#1ED760] and hover:bg-[#21e065]
2. Keep hover:scale-105 transform
3. Maintain tracking-widest uppercase font-bold
4. Keep rounded-full and px-12 py-4</constraints>

// --- START ---
<button className="px-12 py-4 rounded-full bg-[#1ED760] font-bold text-white tracking-widest uppercase transform hover:scale-105 hover:bg-[#21e065] transition-colors duration-200">
  Spotify
</button>
// --- END ---`,

    btn_backdrop: `<system>You are a senior frontend engineer specializing in glassmorphism button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Backdrop Blur — semi-transparent with backdrop-blur, black border, glow on hover.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve backdrop-blur-sm and bg-white/[0.2]
2. Keep hover:shadow-[0px_0px_4px_4px_rgba(0,0,0,0.1)]
3. Maintain border-black rounded-md text-sm</constraints>

// --- START ---
<button className="px-4 py-2 text-black backdrop-blur-sm border border-black rounded-md hover:shadow-[0px_0px_4px_4px_rgba(0,0,0,0.1)] bg-white/[0.2] text-sm transition duration-200">
  Backdrop blur
</button>
// --- END ---`,

    btn_playlist: `<system>You are a senior frontend engineer specializing in minimal outline button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Playlist — large pill, inset shadow border, fills solid on hover.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve shadow-[inset_0_0_0_2px_#616467]
2. Keep hover:bg-[#616467] hover:text-white
3. Maintain tracking-widest uppercase font-bold
4. Keep dark:text-neutral-200</constraints>

// --- START ---
<button className="shadow-[inset_0_0_0_2px_#616467] text-black px-12 py-4 rounded-full tracking-widest uppercase font-bold bg-transparent hover:bg-[#616467] hover:text-white dark:text-neutral-200 transition duration-200">
  Playlist
</button>
// --- END ---`,

    btn_figma: `<system>You are a senior frontend engineer specializing in micro-interaction button design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Figma — solid black, lifts on hover with translate-y.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve hover:-translate-y-1 transform
2. Keep bg-black text-white rounded-lg font-bold
3. Maintain transition duration-400</constraints>

// --- START ---
<button className="px-6 py-2 bg-black text-white rounded-lg font-bold transform hover:-translate-y-1 transition duration-400">
  Figma
</button>
// --- END ---`,

    btn_figmaoutline: `<system>You are a senior frontend engineer specializing in outline button design with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Figma Outline — inset shadow ring, transparent bg, lifts on hover, dark mode support.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve shadow-[0_0_0_3px_#000000_inset]
2. Keep dark:border-white dark:text-white
3. Maintain hover:-translate-y-1 and rounded-lg</constraints>

// --- START ---
<button className="shadow-[0_0_0_3px_#000000_inset] px-6 py-2 bg-transparent border border-black dark:border-white dark:text-white text-black rounded-lg font-bold transform hover:-translate-y-1 transition duration-400">
  Figma Outline
</button>
// --- END ---`,

    btn_topgradient: `<system>You are a senior frontend engineer specializing in gradient accent button effects with Tailwind CSS.
Output ONLY the JSX button code below. Reproduce EXACTLY.</system>
<context>Button: Top Gradient — dark pill with teal gradient line on top edge, hover shadow glow.
Stack: React · Tailwind CSS · No dependencies.</context>
<constraints>
1. Preserve the absolute top gradient line via-teal-500 with w-1/2 mx-auto -top-px
2. Keep bg-slate-700 rounded-full border-slate-600
3. Maintain hover:shadow-white/[0.1] and shadow-2xl
4. Keep relative z-20 on span text</constraints>

// --- START ---
<button className="px-8 py-2 rounded-full relative bg-slate-700 text-white text-sm hover:shadow-2xl hover:shadow-white/[0.1] transition duration-200 border border-slate-600">
  <div className="absolute inset-x-0 h-px w-1/2 mx-auto -top-px shadow-2xl bg-gradient-to-r from-transparent via-teal-500 to-transparent" />
  <span className="relative z-20">Top gradient</span>
</button>
// --- END ---`,

};
