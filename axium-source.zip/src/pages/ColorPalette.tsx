import React, { useState, useEffect, useCallback, useRef } from 'react'
import { Copy, Check, Unlock, Lock, Download, Shuffle, Image as ImageIcon } from 'lucide-react'
import './ColorPalette.css'

interface Color {
    hex: string
    locked: boolean
}

// Pre-defined trending palettes
const TRENDING_PALETTES = [
    { name: 'Midnight Neon', colors: ['#0f172a', '#1e1b4b', '#4c1d95', '#7c3aed', '#c084fc'] },
    { name: 'Forest Mist', colors: ['#064e3b', '#065f46', '#059669', '#10b981', '#34d399'] },
    { name: 'Sunset Vibe', colors: ['#4a044e', '#86198f', '#d946ef', '#f472b6', '#fbcfe8'] },
    { name: 'Ocean Depth', colors: ['#082f49', '#0369a1', '#0284c7', '#38bdf8', '#7dd3fc'] },
    { name: 'Desert Sand', colors: ['#78350f', '#b45309', '#d97706', '#f59e0b', '#fcd34d'] },
    { name: 'Cyberpunk', colors: ['#fce7f3', '#fbcfe8', '#f9a8d4', '#f472b6', '#ec4899'] },
    { name: 'Dracula', colors: ['#282a36', '#44475a', '#6272a4', '#8be9fd', '#ff79c6'] },
    { name: 'Nordic', colors: ['#2e3440', '#3b4252', '#434c5e', '#88c0d0', '#81a1c1'] },
    { name: 'Dark Nebula', colors: ['#0b0c10', '#1f2833', '#45a29e', '#66fcf1', '#c5c6c7'] },
    { name: 'Luxury Gold', colors: ['#111111', '#2a2a2a', '#b8860b', '#ffd700', '#fff8dc'] },
    { name: 'Deep Royal', colors: ['#0f0c29', '#302b63', '#24243e', '#7b4397', '#dc2430'] },
    { name: 'Midnight Blue', colors: ['#0a192f', '#112240', '#233554', '#64ffda', '#ccd6f6'] },
    { name: 'Abyss Purple', colors: ['#120e1f', '#251543', '#391a61', '#6b30b0', '#9b5de5'] },
    { name: 'Ocean Dark', colors: ['#021217', '#06303d', '#0d576a', '#178ca6', '#26c5e6'] },
    { name: 'Onyx & Ruby', colors: ['#080808', '#1a1a1a', '#2c2c2c', '#8a0303', '#ff2a2a'] },
    { name: 'Amethyst', colors: ['#16122d', '#2c244c', '#534381', '#8874c4', '#cbbcf6'] },
    { name: 'Executive', colors: ['#1e293b', '#334155', '#475569', '#94a3b8', '#f8fafc'] },
    { name: 'Cyber Night', colors: ['#09090b', '#18181b', '#27272a', '#00f0ff', '#ff003c'] },
    { name: 'Vintage 80s', colors: ['#2d3047', '#93b5c6', '#ddedaa', '#f0cf65', '#d7816a'] },
    { name: 'Pastel Dreams', colors: ['#ffb3ba', '#ffdfba', '#ffffba', '#baffc9', '#bae1ff'] },
    { name: 'Monochrome', colors: ['#171717', '#404040', '#737373', '#a3a3a3', '#d4d4d4'] },
    { name: 'Autumn Leaves', colors: ['#8c271e', '#d95a2b', '#e8bb4f', '#737538', '#2b4022'] },
    { name: 'Berry Pop', colors: ['#4a0e4e', '#81175b', '#c22d56', '#ea6344', '#f1a84f'] },
    { name: 'Emerald City', colors: ['#022c22', '#064e3b', '#047857', '#34d399', '#a7f3d0'] },
    { name: 'Candy Shop', colors: ['#f0e130', '#f485b0', '#b951b1', '#5426b3', '#23158c'] },
]

export default function ColorPalette() {
    const [colors, setColors] = useState<Color[]>([])
    const [copied, setCopied] = useState<string | null>(null)
    const [showExport, setShowExport] = useState(false)
    const canvasRef = useRef<HTMLCanvasElement>(null)

    // Generate random hex color
    const generateRandomColor = () => '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0')

    const generatePalette = useCallback(() => {
        setColors(prev => {
            if (prev.length === 0) {
                return Array(5).fill(null).map(() => ({ hex: generateRandomColor(), locked: false }))
            }
            return prev.map(c => c.locked ? c : { ...c, hex: generateRandomColor() })
        })
    }, [])

    useEffect(() => {
        generatePalette()
    }, [generatePalette])

    // Spacebar listener for generation
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.code === 'Space' && e.target === document.body) {
                e.preventDefault()
                generatePalette()
            }
        }
        window.addEventListener('keydown', handleKeyDown)
        return () => window.removeEventListener('keydown', handleKeyDown)
    }, [generatePalette])

    const toggleLock = (index: number) => {
        setColors(prev => prev.map((c, i) => i === index ? { ...c, locked: !c.locked } : c))
    }

    const updateColor = (index: number, newHex: string) => {
        setColors(prev => prev.map((c, i) => i === index ? { ...c, hex: newHex } : c))
    }

    const copyToClipboard = (hex: string) => {
        navigator.clipboard.writeText(hex)
        setCopied(hex)
        setTimeout(() => setCopied(null), 2000)
    }

    const copyFullPalette = () => {
        const hexes = colors.map(c => c.hex.toUpperCase()).join(', ')
        navigator.clipboard.writeText(hexes)
        setCopied('full')
        setTimeout(() => setCopied(null), 2000)
    }

    const loadTrending = (palette: string[]) => {
        setColors(palette.map(hex => ({ hex, locked: false })))
    }

    const triggerDownload = (url: string, filename: string) => {
        const link = document.createElement('a')
        link.href = url
        link.download = filename
        link.click()
    }

    // Helper to determine text color based on background luminance
    const getContrast = (hex: string) => {
        const r = parseInt(hex.substr(1, 2), 16)
        const g = parseInt(hex.substr(3, 2), 16)
        const b = parseInt(hex.substr(5, 2), 16)
        const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000
        return (yiq >= 128) ? '#000000' : '#ffffff'
    }

    // Export logic
    const exportPalette = (format: 'png' | 'jpeg' | 'svg') => {
        if (format === 'svg') {
            const svgContent = `
                <svg xmlns="http://www.w3.org/2000/svg" width="1000" height="500" viewBox="0 0 1000 500">
                    ${colors.map((c, i) => `<rect x="${i * 200}" y="0" width="200" height="500" fill="${c.hex}"/>`).join('')}
                    ${colors.map((c, i) => `<text x="${i * 200 + 100}" y="450" font-family="sans-serif" font-size="24" font-weight="bold" fill="${getContrast(c.hex)}" text-anchor="middle">${c.hex.toUpperCase()}</text>`).join('')}
                </svg>
            `.trim()
            const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' })
            triggerDownload(URL.createObjectURL(blob), `palette.${format}`)
        } else {
            const canvas = canvasRef.current
            if (!canvas) return
            const ctx = canvas.getContext('2d')
            if (!ctx) return

            canvas.width = 1000
            canvas.height = 500

            // Draw colors
            colors.forEach((c, i) => {
                ctx.fillStyle = c.hex
                ctx.fillRect(i * 200, 0, 200, 500)

                // Draw text
                ctx.fillStyle = getContrast(c.hex)
                ctx.font = 'bold 24px sans-serif'
                ctx.textAlign = 'center'
                ctx.fillText(c.hex.toUpperCase(), i * 200 + 100, 450)
            })

            const mimeType = format === 'png' ? 'image/png' : 'image/jpeg'
            triggerDownload(canvas.toDataURL(mimeType, 1.0), `palette.${format}`)
        }
        setShowExport(false)
    }

    return (
        <div className="palette-page">
            <canvas ref={canvasRef} style={{ display: 'none' }} />

            <header className="palette-header fade-up">
                <div className="palette-header__inner">
                    <h1 className="palette-header__title">Color Palette Generator</h1>
                    <p className="palette-header__desc">
                        Explore endless color combinations. Press <strong>Spacebar</strong> to generate new colors.
                        Download your schemas in high-res PNG, JPEG, or SVG formats.
                    </p>

                    <div className="palette-actions">
                        <div className="palette-actions-group">
                            <button className="palette-btn palette-btn--primary" onClick={generatePalette}>
                                <Shuffle size={18} /> <span className="hide-mobile">Generate</span>
                            </button>

                            <button className="palette-btn palette-btn--secondary" onClick={copyFullPalette}>
                                {copied === 'full' ? <Check size={18} /> : <Copy size={18} />}
                                <span className="hide-mobile">{copied === 'full' ? 'Copied!' : 'Copy All'}</span>
                            </button>
                        </div>

                        <div className="export-dropdown-wrapper">
                            <button className="palette-btn palette-btn--ghost" onClick={() => setShowExport(!showExport)}>
                                <Download size={18} /> <span className="hide-mobile">Export</span>
                            </button>
                            {showExport && (
                                <div className="export-dropdown">
                                    <button onClick={() => exportPalette('png')}><ImageIcon size={14} /> Export as PNG</button>
                                    <button onClick={() => exportPalette('jpeg')}><ImageIcon size={14} /> Export as JPEG</button>
                                    <button onClick={() => exportPalette('svg')}><ImageIcon size={14} /> Export as SVG</button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </header>

            <main className="palette-main fade-up fade-up-2">
                <div className="color-stripes">
                    {colors.map((color, idx) => (
                        <div
                            key={idx}
                            className="color-stripe"
                            style={{ backgroundColor: color.hex, color: getContrast(color.hex) }}
                        >
                            <div className="stripe-actions">
                                <div className="stripe-picker-wrapper">
                                    <button
                                        className="stripe-btn stripe-hex-btn"
                                        onClick={(e) => {
                                            e.stopPropagation()
                                            copyToClipboard(color.hex)
                                        }}
                                        title="Click to copy, Edit color below"
                                        style={{ color: getContrast(color.hex) }}
                                    >
                                        {copied === color.hex ? <Check size={28} /> : <span className="stripe-hex">{color.hex.toUpperCase()}</span>}
                                    </button>

                                    <input
                                        type="color"
                                        value={color.hex}
                                        onChange={(e) => updateColor(idx, e.target.value)}
                                        className="native-color-picker"
                                        title="Choose custom color"
                                    />
                                </div>

                                <button
                                    className="stripe-btn stripe-btn--lock"
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        toggleLock(idx)
                                    }}
                                    title={color.locked ? "Unlock color" : "Lock color"}
                                    style={{ color: getContrast(color.hex) }}
                                >
                                    {color.locked ? <Lock size={24} /> : <Unlock size={24} opacity={0.5} />}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>

                {colors.length === 5 && (
                    <div className="live-preview-section" style={{
                        '--c1': colors[0].hex,
                        '--c2': colors[1].hex,
                        '--c3': colors[2].hex,
                        '--c4': colors[3].hex,
                        '--c5': colors[4].hex,
                        '--t1': getContrast(colors[0].hex),
                        '--t2': getContrast(colors[1].hex),
                        '--t3': getContrast(colors[2].hex),
                        '--t4': getContrast(colors[3].hex),
                        '--t5': getContrast(colors[4].hex),
                    } as React.CSSProperties}>
                        <h2 className="trending-title">Live UI Visualization</h2>
                        <p className="trending-desc">See how your palette maps to a real website layout.</p>

                        <div className="preview-window">
                            {/* Navbar */}
                            <div className="pw-nav">
                                <div className="pw-logo">Brand</div>
                                <div className="pw-links">
                                    <span>Features</span>
                                    <span>Pricing</span>
                                    <button className="pw-btn pw-btn--small">Get Started</button>
                                </div>
                            </div>

                            {/* Hero */}
                            <div className="pw-hero">
                                <h1 className="pw-h1">Build the Next Big Thing</h1>
                                <p className="pw-p">Accelerate your workflow with premium tools, intelligent insights, and highly customizable UI modules designed for modern creators.</p>
                                <div className="pw-actions">
                                    <button className="pw-btn pw-btn--primary">Start Free Trial</button>
                                    <button className="pw-btn pw-btn--secondary">Book Demo</button>
                                </div>
                            </div>

                            {/* Grid / Features */}
                            <div className="pw-grid">
                                {[1, 2, 3].map(i => (
                                    <div key={i} className="pw-card">
                                        <div className="pw-icon" />
                                        <h3>Analytics Tracking {i}</h3>
                                        <p>Monitor your performance in real-time with comprehensive data visualization.</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                <div className="trending-section">
                    <h2 className="trending-title">Top Trending Palettes</h2>
                    <p className="trending-desc">Curated top-level color plates used by designers worldwide.</p>

                    <div className="trending-grid">
                        {TRENDING_PALETTES.map((tp, i) => (
                            <div key={i} className="trending-card" onClick={() => loadTrending(tp.colors)}>
                                <div className="tc-colors">
                                    {tp.colors.map((c, j) => (
                                        <div key={j} className="tc-color" style={{ backgroundColor: c }} />
                                    ))}
                                </div>
                                <div className="tc-info">
                                    <span className="tc-name">{tp.name}</span>
                                    <span className="tc-action">Apply</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </main>
        </div>
    )
}
