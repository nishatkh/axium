import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import COMPONENT_PROMPTS from '../data/prompts'
import DemoSection from '../components/DemoSection'
import Sidebar from '../components/Sidebar'
import {
    SketchPreview, SimplePreview, InvertPreview, ConnectPreview,
    GradientPreview, UnapologeticPreview, LitUpPreview, BorderMagicPreview,
    BrutalPreview, FavouritePreview, OutlinePreview, ShimmerPreview,
    NextBluePreview, NextWhitePreview, SpotifyPreview, BackdropPreview,
    PlaylistPreview, FigmaPreview, FigmaOutlinePreview, TopGradientPreview
} from '../components/ButtonPreviews'
import './DetailPage.css'

const DEMOS = [
    { id: 'btn_sketch', title: 'Sketch', desc: 'Offset box-shadow button with sharp border and white background.' },
    { id: 'btn_simple', title: 'Simple', desc: 'Elegant lift-on-hover button with subtle shadow.' },
    { id: 'btn_invert', title: 'Invert', desc: 'Teal button that inverts colors on hover with border reveal.' },
    { id: 'btn_connect', title: 'Tailwind Connect', desc: 'Premium pill button with radial gradient glow and arrow icon.' },
    { id: 'btn_gradient', title: 'Gradient', desc: 'Rounded pill with blue gradient, focus ring, and hover shadow.' },
    { id: 'btn_unapologetic', title: 'Unapologetic', desc: 'Sharp corners with yellow offset background that slides on hover.' },
    { id: 'btn_litup', title: 'Lit Up Borders', desc: 'Gradient border via layered divs, inner bg turns transparent on hover.' },
    { id: 'btn_bordermagic', title: 'Border Magic', desc: 'Spinning conic gradient animated border with pill shape.' },
    { id: 'btn_brutal', title: 'Brutal', desc: 'Brutalist multi-layer stacked box-shadow with dark mode support.' },
    { id: 'btn_favourite', title: 'Favourite', desc: 'Solid black button with darkened hover and shadow.' },
    { id: 'btn_outline', title: 'Outline', desc: 'Clean neutral border with subtle gray background on hover.' },
    { id: 'btn_shimmer', title: 'Shimmer', desc: 'Animated diagonal gradient sweep with dark theme.' },
    { id: 'btn_nextblue', title: 'Next.js Blue', desc: 'Brand blue with glow shadow, lightens on hover.' },
    { id: 'btn_nextwhite', title: 'Next.js White', desc: 'White background with gray text and subtle shadow.' },
    { id: 'btn_spotify', title: 'Spotify', desc: 'Spotify green pill with scale-up hover and uppercase tracking.' },
    { id: 'btn_backdrop', title: 'Backdrop Blur', desc: 'Semi-transparent glass button with backdrop blur.' },
    { id: 'btn_playlist', title: 'Playlist', desc: 'Large pill with inset shadow border, fills solid on hover.' },
    { id: 'btn_figma', title: 'Figma', desc: 'Solid black rounded button that lifts on hover.' },
    { id: 'btn_figmaoutline', title: 'Figma Outline', desc: 'Inset shadow ring with transparent background, lifts on hover.' },
    { id: 'btn_topgradient', title: 'Top Gradient', desc: 'Dark pill with teal gradient accent line on top edge.' },
]

function ButtonPreview({ id }: { id: string }) {
    switch (id) {
        case 'btn_sketch': return <SketchPreview />
        case 'btn_simple': return <SimplePreview />
        case 'btn_invert': return <InvertPreview />
        case 'btn_connect': return <ConnectPreview />
        case 'btn_gradient': return <GradientPreview />
        case 'btn_unapologetic': return <UnapologeticPreview />
        case 'btn_litup': return <LitUpPreview />
        case 'btn_bordermagic': return <BorderMagicPreview />
        case 'btn_brutal': return <BrutalPreview />
        case 'btn_favourite': return <FavouritePreview />
        case 'btn_outline': return <OutlinePreview />
        case 'btn_shimmer': return <ShimmerPreview />
        case 'btn_nextblue': return <NextBluePreview />
        case 'btn_nextwhite': return <NextWhitePreview />
        case 'btn_spotify': return <SpotifyPreview />
        case 'btn_backdrop': return <BackdropPreview />
        case 'btn_playlist': return <PlaylistPreview />
        case 'btn_figma': return <FigmaPreview />
        case 'btn_figmaoutline': return <FigmaOutlinePreview />
        case 'btn_topgradient': return <TopGradientPreview />
        default: return <div className="btn-preview">{id.toUpperCase()}</div>
    }
}

export default function Buttons() {
    const location = useLocation()

    useEffect(() => {
        if (location.hash) {
            const el = document.getElementById(location.hash.slice(1))
            if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
        }
    }, [location])

    return (
        <div className="detail">
            <Sidebar items={DEMOS.map(d => ({ id: d.id, label: d.title }))} />
            <main className="detail__main">
                <div className="detail__inner">
                    <header className="detail__header fade-up">
                        <h1 className="detail__title">Buttons</h1>
                        <p className="detail__desc">Premium Tailwind CSS button components with AI-ready prompts — 20 styles from minimal to magical.</p>
                    </header>
                    {DEMOS.map(demo => (
                        <DemoSection key={demo.id} id={demo.id} title={demo.title} description={demo.desc} prompt={COMPONENT_PROMPTS[demo.id] || ''}>
                            <ButtonPreview id={demo.id} />
                        </DemoSection>
                    ))}
                </div>
            </main>
        </div>
    )
}
