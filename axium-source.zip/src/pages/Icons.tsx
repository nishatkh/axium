import React, { useState } from 'react'
import { Copy, Check, Search } from 'lucide-react'
import './Icons.css'

// Load components and raw source code using Vite's glob import
const iconComponents = import.meta.glob('../components/icons/*.tsx', { eager: true })
const iconSources = import.meta.glob('../components/icons/*.tsx', { query: '?raw', eager: true, import: 'default' })

// Parse components and sources into a structured array
const ICONS = Object.keys(iconComponents).map(path => {
    const filename = path.split('/').pop()?.replace('.tsx', '') || ''
    const module = iconComponents[path] as any
    // Some icons export default, some export named (same as filename)
    const Component = module[filename] || module.default || Object.values(module)[0] as React.ElementType
    const rawCode = iconSources[path] as string
    return { name: filename, Component, rawCode }
}).sort((a, b) => a.name.localeCompare(b.name))

export default function Icons() {
    const [copied, setCopied] = useState<string | null>(null)
    const [search, setSearch] = useState('')

    const handleCopy = (name: string, code: string) => {
        navigator.clipboard.writeText(code)
        setCopied(name)
        setTimeout(() => setCopied(null), 2000)
    }

    const filtered = ICONS.filter(i => i.name.toLowerCase().includes(search.toLowerCase()))

    return (
        <div className="icons-page">
            <header className="icons-header fade-up">
                <div className="icons-header__inner">
                    <span className="icons-header__badge">Interactive Icons</span>
                    <h1 className="icons-header__title">Animated SVG Icons</h1>
                    <p className="icons-header__desc">
                        A collection of {ICONS.length} beautiful, highly-customizable Framer Motion icons. Hover to interact, click to copy the full TypeScript source.
                    </p>
                    <div className="icons-search-wrapper">
                        <Search className="icons-search-icon" size={18} />
                        <input
                            type="text"
                            placeholder="Search icons..."
                            className="icons-search"
                            value={search}
                            onChange={e => setSearch(e.target.value)}
                        />
                    </div>
                </div>
            </header>

            <main className="icons-main">
                <div className="icons-grid fade-up fade-up-2">
                    {filtered.map(({ name, Component, rawCode }) => (
                        <div key={name} className="icon-card">
                            <div className="icon-card__stage">
                                {Component ? <Component width={40} height={40} stroke="#ffffff" /> : <div />}
                            </div>
                            <div className="icon-card__footer">
                                <span className="icon-card__name">{name}</span>
                                <button
                                    className={`icon-card__copy ${copied === name ? 'is-copied' : ''}`}
                                    onClick={() => handleCopy(name, rawCode)}
                                    title={`Copy ${name} source code`}
                                >
                                    {copied === name ? <Check size={14} /> : <Copy size={14} />}
                                </button>
                            </div>
                        </div>
                    ))}
                    {filtered.length === 0 && (
                        <div className="icons-empty">No icons found matching "{search}"</div>
                    )}
                </div>
            </main>
        </div>
    )
}
