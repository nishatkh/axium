import { useEffect, useRef } from 'react'
import { useLocation } from 'react-router-dom'
import COMPONENT_PROMPTS from '../data/prompts'
import DemoSection from '../components/DemoSection'
import Sidebar from '../components/Sidebar'
import { useBeamGrid } from '../hooks/useBeamGrid'
import { useWebGLShader } from '../hooks/useWebGLShader'
import { useInteractiveGrid } from '../hooks/useInteractiveGrid'
import './DetailPage.css'

const GRADIENT_SHADER = `
precision mediump float;
uniform vec2 iResolution;
uniform float iTime;

void main() {
    vec2 uv = gl_FragCoord.xy / iResolution.xy;
    float time = iTime * 0.4;
    
    // Create organic movement
    vec2 p = uv * 2.0 - 1.0;
    p.x *= iResolution.x / iResolution.y;
    
    float wave = sin(p.x * 2.0 + time) * 0.5 + 0.5;
    wave += cos(p.y * 1.5 - time * 0.8) * 0.4;
    
    // Axium Palette: Deep Purples, Royal Blues, and Pure Black
    vec3 color1 = vec3(0.05, 0.02, 0.15); // Deep Night Purple
    vec3 color2 = vec3(0.1, 0.15, 0.4);  // Cyber Blue
    vec3 color3 = vec3(0.0, 0.0, 0.0);   // Void Black
    
    float mix1 = smoothstep(0.2, 0.8, wave + p.x * 0.5);
    float mix2 = smoothstep(0.4, 0.9, 1.0 - wave + p.y * 0.3);
    
    vec3 color = mix(color1, color2, mix1);
    color = mix(color, color3, mix2 * 0.7);
    
    // Add a very subtle vignette
    float vignette = 1.2 - length(p * 0.6);
    color *= clamp(vignette, 0.0, 1.0);
    
    gl_FragColor = vec4(color, 1.0);
}
`

const REFLECT_SHADER = `
precision mediump float;
uniform vec2 iResolution;
uniform float iTime;
#define TAU 6.28318530718
#define MAX_ITER 5
void mainImage(out vec4 fragColor, in vec2 fragCoord) {
  float time = iTime * 0.3 + 23.0;
  vec2 uv = fragCoord.xy / iResolution.xy;
  vec2 p = mod(uv * TAU, TAU) - 250.0;
  vec2 i = vec2(p);
  float c = 1.0;
  float inten = 0.005;
  for (int n = 0; n < MAX_ITER; n++) {
    float t = time * (1.0 - (3.0 / float(n + 1)));
    i = p + vec2(cos(t - i.x) + sin(t + i.y), sin(t - i.y) + cos(t + i.x));
    c += 1.0 / length(vec2(p.x / (sin(i.x + t) / inten), p.y / (cos(i.y + t) / inten)));
  }
  c /= float(MAX_ITER);
  c = 1.17 - pow(c, 1.4);
  vec3 colour = vec3(pow(abs(c), 8.0));
  // Axium Refinement: Shift from Cyan to Deep Purple/Blue
  colour = clamp(colour + vec3(0.02, 0.01, 0.08), 0.0, 1.0);
  fragColor = vec4(colour, 1.0);
}
void main() { mainImage(gl_FragColor, gl_FragCoord.xy); }
`

const LIQUID_SHADER = `
precision mediump float;
uniform vec2 iResolution;
uniform float iTime;
uniform vec2 iMouse;
vec3 getGradientColor(vec2 uv, float time) {
  float speed = 1.2;
  vec2 c1 = vec2(0.5 + sin(time*speed*0.4)*0.4, 0.5 + cos(time*speed*0.5)*0.4);
  vec2 c2 = vec2(0.5 + cos(time*speed*0.6)*0.5, 0.5 + sin(time*speed*0.45)*0.5);
  vec2 c3 = vec2(0.5 + sin(time*speed*0.35)*0.45, 0.5 + cos(time*speed*0.55)*0.45);
  vec2 c4 = vec2(0.5 + cos(time*speed*0.5)*0.4, 0.5 + sin(time*speed*0.4)*0.4);
  vec2 c5 = vec2(0.5 + sin(time*speed*0.7)*0.35, 0.5 + cos(time*speed*0.6)*0.35);
  vec2 c6 = vec2(0.5 + cos(time*speed*0.45)*0.5, 0.5 + sin(time*speed*0.65)*0.5);
  float gradientRadius = 0.45;
  float i1 = 1.0 - smoothstep(0.0, gradientRadius, length(uv - c1));
  float i2 = 1.0 - smoothstep(0.0, gradientRadius, length(uv - c2));
  float i3 = 1.0 - smoothstep(0.0, gradientRadius, length(uv - c3));
  float i4 = 1.0 - smoothstep(0.0, gradientRadius, length(uv - c4));
  float i5 = 1.0 - smoothstep(0.0, gradientRadius, length(uv - c5));
  float i6 = 1.0 - smoothstep(0.0, gradientRadius, length(uv - c6));
  vec3 color1 = vec3(0.08, 0.04, 0.18); // Axium Deep Purple
  vec3 color2 = vec3(0.02, 0.1, 0.3);   // Axium Cyber Blue
  vec3 darkNavy = vec3(0.0, 0.0, 0.0);  // Void Black
  vec3 color = vec3(0.0);
  color += color1 * i1 * (0.55 + 0.45*sin(time*speed)) * 0.5;
  color += color2 * i2 * (0.55 + 0.45*cos(time*speed*1.2)) * 1.8;
  color += color1 * i3 * (0.55 + 0.45*sin(time*speed*0.8)) * 0.5;
  color += color2 * i4 * (0.55 + 0.45*cos(time*speed*1.3)) * 1.8;
  color += color1 * i5 * (0.55 + 0.45*sin(time*speed*1.1)) * 0.5;
  color += color2 * i6 * (0.55 + 0.45*cos(time*speed*0.9)) * 1.8;
  vec2 ruv1 = uv - 0.5;
  float a1 = time*speed*0.15;
  ruv1 = vec2(ruv1.x*cos(a1)-ruv1.y*sin(a1), ruv1.x*sin(a1)+ruv1.y*cos(a1)) + 0.5;
  float ri1 = 1.0 - smoothstep(0.0, 0.8, length(ruv1-0.5));
  color += mix(color1, color1, ri1)*0.45*0.5;
  vec2 ruv2 = uv - 0.5;
  float a2 = -time*speed*0.12;
  ruv2 = vec2(ruv2.x*cos(a2)-ruv2.y*sin(a2), ruv2.x*sin(a2)+ruv2.y*cos(a2)) + 0.5;
  float ri2 = 1.0 - smoothstep(0.0, 0.8, length(ruv2-0.5));
  color += mix(color2, color2, ri2)*0.4*1.8;
  color = clamp(color, vec3(0.0), vec3(1.0)) * 1.8;
  float lum = dot(color, vec3(0.299, 0.587, 0.114));
  color = mix(vec3(lum), color, 1.35);
  color = pow(color, vec3(0.92));
  float b = length(color);
  float mf = max(b*1.2, 0.15);
  color = mix(darkNavy, color, mf);
  if (b > 1.0) color = color * (1.0/b);
  return color;
}
float grain(vec2 uv, float time) {
  vec2 g = uv * iResolution * 0.5;
  return fract(sin(dot(g+time, vec2(12.9898, 78.233)))*43758.5453)*2.0-1.0;
}
void main() {
  vec2 uv = gl_FragCoord.xy / iResolution.xy;
  if (iMouse.x > 0.0) {
    vec2 mUv = iMouse / iResolution;
    float dist = length(uv - mUv);
    float ripple = sin(dist*20.0-iTime*3.0)*0.02*(1.0-smoothstep(0.0,0.3,dist));
    uv += vec2(ripple);
  }
  vec3 color = getGradientColor(uv, iTime);
  color += grain(uv, iTime) * 0.08;
  color = clamp(color, vec3(0.0), vec3(1.0));
  gl_FragColor = vec4(color, 1.0);
}
`

const DEMOS = [
    { id: 'beamgrid', title: 'Beam Grid Background', desc: 'Canvas-based grid with animated beams, interactive mouse highlights, and idle animation.', type: 'beamgrid' as const },
    { id: 'gradient', title: 'Gradient Background', desc: 'WebGL shader-based animated gradient with organic mesh movement and cyber-dark palette.', type: 'gradient' as const },
    { id: 'interactivegrid', title: 'Interactive Grid', desc: 'Canvas grid with mouse-reactive glow trail, idle wandering cells, and dark-mode styling.', type: 'igrid' as const },
    { id: 'reflect', title: 'Reflect Background', desc: 'WebGL caustic shader refined with deep Axium purple tones for a premium atmospheric effect.', type: 'reflect' as const },
    { id: 'liquid', title: 'Liquid Surface', desc: 'Liquid gradient with moving color centers and high-fidelity Axium dark aesthetic.', type: 'liquid' as const },
]

function BeamGridDemo() {
    const containerRef = useRef<HTMLDivElement>(null)
    const canvasRef = useBeamGrid(containerRef)
    return (
        <div ref={containerRef} style={{ width: '100%', height: '100%', background: '#000000' }}>
            <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
        </div>
    )
}

function GradientDemo() {
    const containerRef = useRef<HTMLDivElement>(null)
    const canvasRef = useWebGLShader(containerRef, { fragmentShader: GRADIENT_SHADER })
    return (
        <div ref={containerRef} style={{ width: '100%', height: '100%', background: '#000000' }}>
            <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
        </div>
    )
}

function InteractiveGridDemo() {
    const containerRef = useRef<HTMLDivElement>(null)
    const canvasRef = useInteractiveGrid(containerRef)
    return (
        <div ref={containerRef} style={{ width: '100%', height: '100%', background: '#000000', cursor: 'crosshair' }}>
            <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
        </div>
    )
}

function ReflectDemo() {
    const containerRef = useRef<HTMLDivElement>(null)
    const canvasRef = useWebGLShader(containerRef, { fragmentShader: REFLECT_SHADER })
    return (
        <div ref={containerRef} style={{ width: '100%', height: '100%', background: '#000000' }}>
            <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
        </div>
    )
}

function LiquidDemo() {
    const containerRef = useRef<HTMLDivElement>(null)
    const canvasRef = useWebGLShader(containerRef, { fragmentShader: LIQUID_SHADER }, true)
    return (
        <div ref={containerRef} style={{ width: '100%', height: '100%', background: '#000000', cursor: 'none' }}>
            <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
        </div>
    )
}

function BgDemo({ type }: { type: string }) {
    switch (type) {
        case 'beamgrid': return <BeamGridDemo />
        case 'gradient': return <GradientDemo />
        case 'igrid': return <InteractiveGridDemo />
        case 'reflect': return <ReflectDemo />
        case 'liquid': return <LiquidDemo />
        default: return null
    }
}

export default function Backgrounds() {
    const location = useLocation()

    useEffect(() => {
        if (location.hash) {
            const el = document.getElementById(location.hash.slice(1))
            if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
        }
    }, [location])

    return (
        <div className="detail">
            <Sidebar items={DEMOS.map(d => ({ id: d.id, label: d.title }))} />
            <main className="detail__main">
                <div className="detail__inner">
                    <header className="detail__header fade-up">
                        <h1 className="detail__title">Backgrounds</h1>
                        <p className="detail__desc">Premium animated background components — real WebGL shaders, interactive canvas grids, and liquid surfaces.</p>
                    </header>
                    {DEMOS.map(demo => (
                        <DemoSection key={demo.id} id={demo.id} title={demo.title} description={demo.desc} prompt={COMPONENT_PROMPTS[demo.id] || ''}>
                            <BgDemo type={demo.type} />
                        </DemoSection>
                    ))}
                </div>
            </main>
        </div>
    )
}
