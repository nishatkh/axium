import { Link } from 'react-router-dom'
import { useEffect, useRef, useState, useMemo } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import { GlowingEffect } from '../components/UI/glowing-effect'
import ShaderBackground from '../components/UI/shader-background'
import { ShaderAnimation } from '@/components/UI/shader-animation'
import { LayoutTextFlip } from '../components/UI/layout-text-flip'
import { HeroButton } from '../components/UI/hero-button'
import { AnalyticsDashboard } from '../components/Dashboard/AnalyticsDashboard'
import './Home.css'

interface CardData {
    name: string
    desc: string
    tag: string
    href: string
    preview: string
    image?: string
    span?: number
    row?: number
}

const CARDS: CardData[] = [
    { name: '3D Elements', desc: 'Premium 3D components with physics-based interactions.', tag: 'R3F + Motion', href: '/3d-elements', preview: 'ring', span: 8, row: 2, image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=1200&auto=format&fit=crop' },
    { name: 'Backgrounds', desc: 'Hardware-accelerated animated canvases.', tag: 'WebGL', href: '/backgrounds', preview: 'grad', span: 4, row: 1, image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1200&auto=format&fit=crop' },
    { name: 'UI Components', desc: 'Glassmorphic interface primitives for elite apps.', tag: 'React', href: '/ui-components', preview: 'uidock', span: 4, row: 1, image: 'https://images.unsplash.com/photo-1558655146-d09347e92766?q=80&w=1200&auto=format&fit=crop' },
    { name: 'Text Animations', desc: 'Liquid text effects and high-fidelity reveals.', tag: 'Motion', href: '/text-animations', preview: 'uireveal', span: 6, row: 1, image: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=1200&auto=format&fit=crop' },
    { name: 'Button Styles', desc: 'Interactive buttons with neumorphic depth.', tag: 'CSS', href: '/buttons', preview: 'icons', span: 6, row: 1, image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1200&auto=format&fit=crop' },
    { name: 'Elite Prompts', desc: 'Master-level prompts for complete design systems.', tag: 'AI-Prompt', href: '/website-designs', preview: 'designs', span: 12, row: 2, image: 'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?q=80&w=1600&auto=format&fit=crop' },
]

function MiniPreview({ image, name }: { image: string, name: string }) {
    return (
        <div className="absolute inset-0 w-full h-full overflow-hidden">
            <motion.div
                initial={{ scale: 1.1, opacity: 0 }}
                animate={{ scale: 1, opacity: 0.6 }}
                whileHover={{ scale: 1.05, opacity: 0.8 }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
                className="w-full h-full"
            >
                <img
                    src={image}
                    alt={name}
                    className="w-full h-full object-cover grayscale brightness-50 contrast-125"
                />
            </motion.div>
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
        </div>
    )
}

export default function Home() {
    return (
        <main className="home">
            <section className="hero">
                <div className="hero__noise" />
                <div className="absolute inset-0 z-0">
                    <ShaderAnimation />
                </div>
                <div className="hero__glow" />

                <motion.div
                    className="hero__content relative z-10 flex flex-col items-center justify-center text-center px-4 w-full max-w-5xl mx-auto min-h-[90vh]"
                >
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                        className="mb-6"
                    >
                        <LayoutTextFlip
                            text="Welcome to "
                            words={["Axium", "Innovation", "The Future", "The System"]}
                            duration={3000}
                        />
                    </motion.div>

                    <motion.p
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                        className="hero__subtitle text-base md:text-lg text-white/50 mb-12 tracking-[0.05em] uppercase font-medium"
                        style={{ fontFamily: 'system-ui' }}
                    >
                        Architecting digital elegance through light, motion, and depth
                    </motion.p>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                        className="hero__actions flex flex-wrap justify-center gap-4"
                    >
                        <HeroButton to="/3d-elements" variant="primary">
                            Explore Library
                        </HeroButton>
                        <HeroButton to="/website-designs" variant="secondary">
                            Design Systems
                        </HeroButton>
                    </motion.div>
                </motion.div>
            </section>

            <AnalyticsDashboard />

            <section className="bento">
                <div className="bento__header">
                    <h2 className="bento__title font-display">Crafted with precision</h2>
                </div>

                <div className="bento__grid">
                    {CARDS.map((card, i) => (
                        <Link
                            to={card.href}
                            key={i}
                            className={`bento__item bento__item--span-${card.span} bento__item--row-${card.row}`}
                            style={{ position: 'relative' }}
                        >
                            <GlowingEffect spread={40} glow={true} disabled={false} proximity={64} inactiveZone={0.01} />
                            <div style={{ position: 'relative', zIndex: 10, display: 'flex', flexDirection: 'column', height: '100%', width: '100%' }}>
                                <div className="bento__preview-container">
                                    <MiniPreview image={card.image!} name={card.name} />
                                </div>
                                <div className="bento__item-content">
                                    <h3 className="bento__item-title">{card.name}</h3>
                                    <p className="bento__item-desc">{card.desc}</p>
                                </div>
                            </div>
                        </Link>
                    ))}
                </div>
            </section>

            <footer className="footer" style={{ padding: '80px 24px', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div className="font-display" style={{ fontSize: '24px', fontWeight: 800 }}>Axium</div>
                    <div style={{ display: 'flex', gap: '32px', color: 'var(--text-2)', fontSize: '14px' }}>
                        <a href="https://github.com/nishatkh/axium.git" target="_blank" rel="noreferrer">GitHub</a>
                        <span>© 2026 Axium. All rights reserved.</span>
                    </div>
                </div>
            </footer>
        </main >
    )
}
