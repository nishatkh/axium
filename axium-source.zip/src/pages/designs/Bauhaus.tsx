import React, { useEffect } from 'react'
import { Plus, Move, LayoutGrid, Monitor, ArrowRight, Layers, Box, Settings } from 'lucide-react'

export default function Bauhaus() {
    useEffect(() => {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;700;900&family=Space+Mono&family=Inter:wght@400;700;900&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }, []);

    return (
        <div className="bauhaus-root bg-[#F7F5F0] text-[#111] min-h-screen font-sans overflow-x-hidden selection:bg-[#FFD300] selection:text-black">
            <style>{`
                .bauhaus-root {
                    --red: #E32636;
                    --yellow: #FFD300;
                    --blue: #0038A8;
                    --black: #111111;
                    --paper: #F7F5F0;
                    --divider: 4px solid var(--black);
                }
                .bauhaus-root h1, .bauhaus-root h2, .bauhaus-root h3 {
                    font-family: "Space Grotesk", sans-serif;
                    text-transform: uppercase;
                    line-height: 0.9;
                    letter-spacing: -0.04em;
                    font-weight: 900;
                }
                .bauhaus-root .mono {
                    font-family: "Space Mono", monospace;
                    text-transform: uppercase;
                    font-size: 11px;
                    letter-spacing: 0.1em;
                    font-weight: 700;
                }
                .bauhaus-root .btn-bauhaus {
                    background: var(--red);
                    color: var(--paper);
                    border: 4px solid var(--black);
                    padding: 1.25rem 2.5rem;
                    font-weight: 900;
                    text-transform: uppercase;
                    font-size: 14px;
                    box-shadow: 8px 8px 0px 0px var(--black);
                    transition: all 0.1s linear;
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 12px;
                }
                .bauhaus-root .btn-bauhaus:active {
                    box-shadow: 0px 0px 0px 0px var(--black);
                    transform: translate(8px, 8px);
                }
                .bauhaus-root .grid-cell {
                    border: 2px solid var(--black);
                    background: white;
                }
                .bauhaus-root .sidebar-tag {
                   writing-mode: vertical-rl;
                   text-orientation: mixed;
                   padding: 20px 10px;
                   border-left: 4px solid var(--black);
                   font-family: "Space Mono", monospace;
                   text-transform: uppercase;
                   font-size: 10px;
                   font-weight: 900;
                }
                @keyframes marquee {
                    0% { transform: translateX(0); }
                    100% { transform: translateX(-50%); }
                }
                .bauhaus-root .marquee {
                    white-space: nowrap;
                    overflow: hidden;
                    display: flex;
                    border-bottom: 4px solid var(--black);
                    background: var(--black);
                    color: white;
                    padding: 15px 0;
                }
                .bauhaus-root .marquee-content {
                    display: flex;
                    animation: marquee 20s linear infinite;
                    gap: 60px;
                    padding-left: 60px;
                }
            `}</style>

            {/* Marquee Header */}
            <div className="marquee">
                <div className="marquee-content mono">
                    <span>FORM_FOLLOWS_FUNCTION</span>
                    <span>MODULAR_SYSTEM_V2.4</span>
                    <span>WEIMAR // DESSAU // BERLIN</span>
                    <span>OBJECTIVE_INDUSTRIAL_DESIGN</span>
                    <span>FORM_FOLLOWS_FUNCTION</span>
                    <span>MODULAR_SYSTEM_V2.4</span>
                    <span>WEIMAR // DESSAU // BERLIN</span>
                    <span>OBJECTIVE_INDUSTRIAL_DESIGN</span>
                </div>
            </div>

            {/* Main Header */}
            <header className="border-b-4 border-black bg-white grid grid-cols-1 md:grid-cols-12 divide-x-0 md:divide-x-4 divide-black">
                <div className="md:col-span-4 p-8 flex items-center gap-6">
                    <div className="flex gap-1">
                        <div className="w-4 h-4 rounded-none bg-[#E32636] border-2 border-black" />
                        <div className="w-4 h-4 rounded-none bg-[#FFD300] border-2 border-black" />
                        <div className="w-4 h-4 rounded-none bg-[#0038A8] border-2 border-black" />
                    </div>
                    <span className="text-4xl font-black italic tracking-tighter">KONSTRUKT.</span>
                </div>
                <div className="hidden md:flex md:col-span-5 p-8 gap-12 mono items-center">
                    <a href="#" className="hover:text-[var(--blue)] border-b-2 border-transparent hover:border-[var(--blue)] transition-all pb-1">Catalog</a>
                    <a href="#" className="hover:text-[var(--red)] border-b-2 border-transparent hover:border-[var(--red)] transition-all pb-1">Logic</a>
                    <a href="#" className="hover:text-[var(--yellow)] border-b-2 border-transparent hover:border-[var(--yellow)] transition-all pb-1">Archive</a>
                </div>
                <div className="md:col-span-3 bg-[#FFD300] p-8 flex items-center justify-between font-black uppercase tracking-tight cursor-pointer hover:bg-white transition-colors border-l-4 border-black group">
                    <span>Build System</span>
                    <Plus className="group-hover:rotate-180 transition-transform duration-500" />
                </div>
            </header>

            {/* Hero Section */}
            <section className="grid grid-cols-1 md:grid-cols-12 border-b-4 border-black">
                <div className="md:col-span-8 p-12 md:p-24 bg-white relative">
                    <div className="absolute top-0 right-0 w-1/3 h-full border-l-4 border-black bg-[#F7F5F0] -z-0" />
                    <div className="relative z-10">
                        <h1 className="text-[14vw] md:text-[11vw] mb-16 hover:text-[var(--blue)] transition-colors duration-500">
                            THE NEW<br />OBJECT.
                        </h1>
                        <div className="flex flex-col md:flex-row gap-12 items-start">
                            <button className="btn-bauhaus">
                                <Box size={20} />
                                Start Constructing
                            </button>
                            <div className="max-w-[320px] font-bold text-sm leading-tight border-l-4 border-black pl-6">
                                RETHINKING THE INDUSTRIAL PROCESS THROUGH THE LENS OF RADICAL SIMPLICITY AND MATHEMATICAL ORDER.
                            </div>
                        </div>
                    </div>
                </div>
                <div className="md:col-span-4 bg-[#0038A8] p-0 flex">
                    <div className="flex-1 flex flex-col justify-between p-12 text-white">
                        <div className="mono text-white/40">Case Study 01 // Structuralism</div>
                        <div className="text-8xl font-black italic">A01</div>
                        <p className="mono text-xs opacity-60">GEOMETRY IS THE LANGUAGE OF REALITY.</p>
                    </div>
                    <div className="sidebar-tag bg-white text-black">TECHNICAL_SPECIFICATION_B3</div>
                </div>
            </section>

            {/* Feature Grid - Non-Standard Layout */}
            <section className="grid grid-cols-1 md:grid-cols-3 divide-x-0 md:divide-x-4 divide-black border-b-4 border-black bg-white">
                <article className="p-12 flex flex-col gap-8 group">
                    <div className="w-20 h-20 bg-[var(--red)] border-4 border-black flex items-center justify-center text-white group-hover:translate-x-4 group-hover:-translate-y-4 transition-transform shadow-[0_0_0_0_#111] group-hover:shadow-[12px_12px_0_0_#111]">
                        <LayoutGrid size={40} />
                    </div>
                    <div className="mono text-zinc-400">01 // Logic</div>
                    <h2 className="text-5xl">Grid Control</h2>
                    <p className="text-sm font-bold opacity-70 leading-relaxed">
                        Our layout is not an aesthetic choice, but a rigid structural requirement. The grid governs every pixel, ensuring absolute rational balance.
                    </p>
                    <ArrowRight className="mt-auto transition-transform group-hover:translate-x-4" />
                </article>

                <article className="p-12 bg-[#E32636] text-white flex flex-col justify-between min-h-[500px] overflow-hidden relative">
                    <div className="absolute top-0 right-0 p-12 mono text-white/30 text-8xl font-black">?</div>
                    <div className="relative z-10">
                        <div className="mono mb-12">02 // Theory</div>
                        <h2 className="text-7xl mb-12">COLOR<br />TRIAD.</h2>
                        <div className="flex gap-4">
                            <div className="w-12 h-1); border-2 border-white bg-[#E32636]" />
                            <div className="w-12 h-12 border-2 border-white bg-[#FFD300]" />
                            <div className="w-12 h-12 border-2 border-white bg-[#0038A8]" />
                        </div>
                    </div>
                    <p className="mono text-xs leading-loose relative z-10">THE PSYCHOLOGY OF PRIMARY TONES IN INDUSTRIAL PRODUCTION.</p>
                </article>

                <article className="p-0 flex flex-col divide-y-4 divide-black">
                    <div className="p-12 flex-1 bg-white">
                        <h3 className="text-3xl mb-4">ASPECT RATIO</h3>
                        <div className="h-2 bg-black w-full" />
                        <div className="mt-8 grid grid-cols-2 gap-4">
                            <div className="aspect-square bg-zinc-100 border-2 border-black" />
                            <div className="aspect-video bg-zinc-100 border-2 border-black" />
                        </div>
                    </div>
                    <div className="p-12 h-64 bg-[#FFD300] flex flex-col justify-center">
                        <div className="text-6xl font-black leading-none">ORDER.</div>
                        <div className="mono mt-4">Systematic Execution</div>
                    </div>
                </article>
            </section>

            {/* Product Catalog Section */}
            <section className="bg-white p-12 md:p-24">
                <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-12">
                    <h2 className="text-8xl md:text-[10rem]">OBJECTS.</h2>
                    <div className="max-w-xs mono text-right leading-relaxed opacity-40">
                        OUR CATALOGUE COMPRISES 24 INDIVIDUAL MODULES DESIGNED FOR LIMITLESS RECOMBINATION.
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-1px bg-black border-4 border-black">
                    {[
                        { name: "CHAIR_B3", price: "$2,850", color: "#0038A8", tag: "Structural" },
                        { name: "TABLE_KD", price: "$4,200", color: "#E32636", tag: "Modular" },
                        { name: "LAMP_MT", price: "$980", color: "#FFD300", tag: "Electric" },
                        { name: "UNIT_S2", price: "$8,500", color: "#111111", tag: "Spatial" }
                    ].map((item, i) => (
                        <div key={i} className="bg-white p-12 flex flex-col justify-between min-h-[500px] hover:bg-zinc-50 transition-colors cursor-pointer group">
                            <div>
                                <div className="flex justify-between items-center mb-12">
                                    <div className="mono text-[9px] border border-black px-2 py-1">{item.tag}</div>
                                    <div className="mono text-xs">{item.price}</div>
                                </div>
                                <h3 className="text-4xl font-bold">{item.name}</h3>
                            </div>
                            <div className="relative h-48 flex items-center justify-center">
                                <div className="w-32 h-32 border-4 border-black group-hover:scale-125 transition-transform duration-500" style={{ backgroundColor: item.color }} />
                                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Plus size={48} className="text-white mix-blend-difference" />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Footer */}
            <footer className="bg-black text-[#F7F5F0] p-12 md:p-24 border-t-[12px] border-[#FFD300]">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-16 md:gap-0">
                    <div className="md:col-span-6">
                        <div className="text-6xl font-black mb-12 italic tracking-tighter transition-all hover:tracking-normal cursor-pointer">KONSTRUKT.SYSTEMS</div>
                        <p className="max-w-md mono text-[10px] leading-relaxed uppercase opacity-40">
                            THE SCHOOL WAS FOUNDED WITH THE IDEA OF CREATING A TOTAL WORK OF ART.
                            WE CONTINUE THAT LEGACY THROUGH THE PRODUCTION OF FUNCTIONAL OBJECTS
                            FOR THE DIGITAL ARCHIVE.
                        </p>
                    </div>
                    <div className="md:col-span-3 flex flex-col gap-6 mono text-xs">
                        <h4 className="opacity-40">Navigation_Nodes</h4>
                        <a href="#" className="hover:text-[var(--red)]">[ THE_MANIFESTO ]</a>
                        <a href="#" className="hover:text-[var(--yellow)]">[ THE_CATALOGUE ]</a>
                        <a href="#" className="hover:text-[var(--blue)]">[ THE_WORKSHOP ]</a>
                        <a href="#" className="hover:text-white">[ THE_ARCHIVE ]</a>
                    </div>
                    <div className="md:col-span-3 flex flex-col gap-6 mono text-xs">
                        <h4 className="opacity-40">Location_Address</h4>
                        <p>MODULE 019 // GRID SECTOR 4<br />DESSAU, GERMANY // 06846</p>
                        <div className="flex gap-4 mt-4">
                            <Settings size={18} />
                            <Layers size={18} />
                            <Monitor size={18} />
                        </div>
                    </div>
                </div>
                <div className="mt-32 pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-12 opacity-30 mono text-[9px]">
                    <div>© 2024 KONSTRUKT DESIGN LABORATORY ALL RIGHTS RESERVED</div>
                    <div className="flex gap-8">
                        <div className="flex gap-2">
                            <span className="w-2 h-2 bg-[#E32636]" />
                            <span className="w-2 h-2 bg-[#FFD300]" />
                            <span className="w-2 h-2 bg-[#0038A8]" />
                        </div>
                        <span>SYSTEM_VER_3.0.0</span>
                        <span>DESIGN_BY_MNML_SYS</span>
                    </div>
                </div>
            </footer>
        </div>
    )
}
