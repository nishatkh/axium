import React, { useEffect } from 'react'
import { ArrowRight, ChevronRight, Activity, Command, Cpu, Sparkles, Layout, Zap, Layers, Globe, Shield, ZapIcon } from 'lucide-react'
import { ShaderAnimation } from '@/components/UI/shader-animation'

export default function Modern() {
    useEffect(() => {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }, []);

    return (
        <div className="modern-root bg-[#050505] text-[#EDEDED] min-h-screen font-sans overflow-x-hidden selection:bg-[#5E6AD2]/30 selection:text-white">
            <style>{`
                .modern-root {
                    --accent: #5E6AD2;
                    --accent-glow: rgba(94, 106, 210, 0.4);
                    --border: rgba(255, 255, 255, 0.08);
                    --card-bg: rgba(255, 255, 255, 0.02);
                }
                .modern-root h1, .modern-root h2, .modern-root h3 {
                    letter-spacing: -0.04em;
                    font-weight: 800;
                    line-height: 1.1;
                }
                .modern-root .glass {
                    background: var(--card-bg);
                    border: 1px solid var(--border);
                    backdrop-filter: blur(20px);
                    box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.05);
                }
                .modern-root .btn-modern {
                    background: white;
                    color: black;
                    padding: 0.8rem 1.8rem;
                    border-radius: 99px;
                    font-weight: 600;
                    font-size: 14px;
                    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
                    display: inline-flex;
                    align-items: center;
                    gap: 10px;
                    cursor: pointer;
                    border: 1px solid white;
                }
                .modern-root .btn-modern:hover {
                    background: transparent;
                    color: white;
                    transform: translateY(-2px);
                    box-shadow: 0 10px 30px -10px var(--accent);
                }
                .modern-root .badge {
                    background: rgba(94, 106, 210, 0.1);
                    border: 1px solid rgba(94, 106, 210, 0.2);
                    color: #8B8BFF;
                    padding: 4px 12px;
                    border-radius: 99px;
                    font-size: 12px;
                    font-weight: 600;
                }
                @keyframes float {
                    0%, 100% { transform: translateY(0); }
                    50% { transform: translateY(-20px); }
                }
                .modern-root .animate-float {
                    animation: float 6s ease-in-out infinite;
                }
                .modern-root .text-gradient {
                    background: linear-gradient(180deg, #FFFFFF 0%, rgba(255, 255, 255, 0.5) 100%);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                .modern-root .grid-pattern {
                    background-image: radial-gradient(circle at 1px 1px, rgba(255,255,255,0.05) 1px, transparent 0);
                    background-size: 40px 40px;
                }
            `}</style>

            {/* Ambient Background */}
            <div className="fixed inset-0 grid-pattern -z-10" />
            <div className="fixed inset-0 pointer-events-none -z-20">
                <ShaderAnimation />
            </div>
            <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#5E6AD2]/10 blur-[120px] rounded-full pointer-events-none -z-10" />
            <div className="fixed bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#8B5CF6]/10 blur-[120px] rounded-full pointer-events-none -z-10" />

            {/* Nav */}
            <nav className="fixed top-0 w-full z-50 py-8 px-10">
                <div className="max-w-7xl mx-auto flex justify-between items-center glass rounded-full py-2 px-6">
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#5E6AD2] to-[#8B5CF6] flex items-center justify-center">
                            <Zap size={18} color="white" fill="white" />
                        </div>
                        <span className="font-bold text-lg tracking-tight">TRANSFORM.</span>
                    </div>
                    <div className="hidden md:flex gap-10 text-xs font-semibold text-zinc-400 uppercase tracking-widest">
                        <a href="#" className="hover:text-white transition-colors">Platform</a>
                        <a href="#" className="hover:text-white transition-colors">Resources</a>
                        <a href="#" className="hover:text-white transition-colors">Pricing</a>
                    </div>
                    <div className="flex items-center gap-4">
                        <button className="text-xs font-bold text-zinc-400 hover:text-white transition-colors">Sign In</button>
                        <button className="btn-modern !py-1.5 !px-4 !text-xs">Start Trial</button>
                    </div>
                </div>
            </nav>

            {/* Hero Section */}
            <section className="relative pt-60 pb-40 px-10 text-center">
                <div className="max-w-4xl mx-auto">
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass mb-12 animate-in">
                        <span className="badge">New</span>
                        <span className="text-xs font-semibold text-zinc-400">Transform Engine v4 is now available globally</span>
                        <ChevronRight size={14} className="text-zinc-600" />
                    </div>

                    <h1 className="text-7xl md:text-9xl mb-10 text-gradient">
                        Accelerate your<br />digital evolution.
                    </h1>

                    <p className="text-xl text-zinc-400 max-w-2xl mx-auto mb-16 leading-relaxed font-light">
                        The unified API for high-performance engineering teams. Orchestrate complex workflows, manage global infrastructure, and scale without limits.
                    </p>

                    <div className="flex flex-wrap justify-center gap-6">
                        <button className="btn-modern text-lg px-12 py-5">
                            Get Implementation Details
                            <ArrowRight size={20} />
                        </button>
                        <button className="glass px-12 py-5 rounded-full text-lg font-semibold flex items-center gap-3 hover:border-zinc-500 transition-colors">
                            <Command size={20} className="text-zinc-500" />
                            Talk to Engineers
                        </button>
                    </div>

                    {/* Integrated Stats */}
                    <div className="mt-32 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-5xl mx-auto border-t border-white/5 pt-12">
                        {[
                            { val: '200M+', label: 'Daily Requests' },
                            { val: '99.99%', label: 'Global Uptime' },
                            { val: '<12ms', label: 'Average Latency' },
                            { val: '4.5k', label: 'Team Integrations' }
                        ].map((item, i) => (
                            <div key={i} className="text-center">
                                <div className="text-3xl font-black mb-1">{item.val}</div>
                                <div className="text-[10px] mono text-zinc-500 tracking-widest">{item.label}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Feature Bento Grid - Highly Refined */}
            <section className="py-40 px-10">
                <div className="max-w-7xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-6 auto-rows-[300px]">
                        {/* Featured Cell */}
                        <div className="md:col-span-8 md:row-span-2 glass rounded-[40px] p-12 overflow-hidden relative group">
                            <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-bl from-[#5E6AD2]/20 to-transparent -z-10 group-hover:opacity-50 transition-opacity" />
                            <div className="h-full flex flex-col justify-between max-w-md">
                                <div>
                                    <div className="w-14 h-14 rounded-2xl bg-[#5E6AD2] flex items-center justify-center shadow-lg shadow-[#5E6AD2]/40 mb-10">
                                        <ZapIcon size={28} fill="white" color="white" />
                                    </div>
                                    <h2 className="text-5xl font-bold mb-6">Real-time Cloud <br />Orchestration</h2>
                                    <p className="text-zinc-400 text-lg leading-relaxed">
                                        Automate your entire stack with a single, type-safe API. Our engine dynamically optimizes resource allocation based on real-time traffic surges.
                                    </p>
                                </div>
                                <button className="flex items-center gap-2 font-bold text-[#8B8BFF] group-hover:gap-4 transition-all">
                                    Learn about Orchestration <ArrowRight size={18} />
                                </button>
                            </div>
                            {/* Abstract Visual Simulation */}
                            <div className="hidden md:block absolute bottom-12 right-12 w-64 h-64 border border-white/5 rounded-3xl animate-float">
                                <div className="absolute inset-4 border border-zinc-800 rounded-2xl flex items-center justify-center">
                                    <div className="w-full h-[1px] bg-zinc-800 absolute rotate-45" />
                                    <div className="w-full h-[1px] bg-zinc-800 absolute -rotate-45" />
                                </div>
                            </div>
                        </div>

                        {/* Secondary Cells */}
                        <div className="md:col-span-4 glass rounded-[40px] p-10 flex flex-col justify-between">
                            <Shield className="text-[#5E6AD2]" size={32} />
                            <div>
                                <h3 className="text-2xl font-bold mb-3">Enterprise Shield</h3>
                                <p className="text-zinc-500 text-sm leading-relaxed">Military-grade encryption for every data point moving through the platform.</p>
                            </div>
                        </div>

                        <div className="md:col-span-4 glass rounded-[40px] p-10 flex flex-col justify-between bg-zinc-950">
                            <Globe className="text-white" size={32} />
                            <div>
                                <h3 className="text-2xl font-bold mb-3">Edge Priority</h3>
                                <p className="text-zinc-500 text-sm leading-relaxed">Route traffic through 400+ nodes globally for sub-millisecond local response.</p>
                            </div>
                        </div>

                        <div className="md:col-span-6 glass rounded-[40px] p-10 flex items-center gap-10">
                            <div className="flex-1">
                                <h3 className="text-2xl font-bold mb-3">AI Integration</h3>
                                <p className="text-zinc-500 text-sm">Natural language control for your infrastructure management.</p>
                            </div>
                            <div className="w-32 h-32 glass rounded-full flex items-center justify-center">
                                <Sparkles className="text-zinc-300" />
                            </div>
                        </div>

                        <div className="md:col-span-6 glass rounded-[40px] p-10 bg-[var(--accent)] text-white group cursor-pointer overflow-hidden relative">
                            <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                            <div className="relative z-10 flex h-full items-center justify-between">
                                <div>
                                    <h3 className="text-3xl font-bold mb-2">Build with us</h3>
                                    <p className="text-white/70">Join 50,000+ developers shipping on Transform.</p>
                                </div>
                                <ArrowRight size={40} className="group-hover:translate-x-4 transition-transform" />
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Final CTA */}
            <section className="py-40 px-10 text-center relative overflow-hidden">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1200px] h-[1200px] border border-white/5 rounded-full -z-10" />
                <div className="max-w-4xl mx-auto relative z-10">
                    <h2 className="text-6xl md:text-8xl font-bold mb-12">Universal scale<br />awaits you.</h2>
                    <div className="flex flex-col md:flex-row justify-center gap-6">
                        <button className="btn-modern text-lg px-12 py-5">Start Deployment</button>
                        <button className="glass px-12 py-5 rounded-full text-lg font-semibold">Self-Host Option</button>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="py-32 px-10 border-t border-white/5">
                <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-16">
                    <div className="col-span-2">
                        <div className="flex items-center gap-2 font-bold text-xl tracking-tight mb-8">
                            <ZapIcon size={20} fill="#5E6AD2" color="#5E6AD2" />
                            TRANSFORM.ENGINE
                        </div>
                        <p className="text-zinc-500 max-w-sm mb-12 leading-relaxed">
                            Pioneering the next era of infrastructure orchestration.
                            Built for speed. Designed for scale. Shipped from San Francisco.
                        </p>
                        <div className="flex gap-8 mono text-[10px] tracking-widest text-zinc-600 uppercase">
                            <a href="#" className="hover:text-white transition-colors">Twitter</a>
                            <a href="https://github.com/nishatkh/axium.git" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">GitHub</a>
                            <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
                        </div>
                    </div>
                    <div className="flex flex-col gap-5 text-sm text-zinc-500">
                        <h4 className="text-white font-bold mb-2 uppercase tracking-widest text-xs">Resources</h4>
                        <a href="#">API Documentation</a>
                        <a href="#">Security Profile</a>
                        <a href="#">Uptime Logs</a>
                        <a href="#">Open Source Core</a>
                    </div>
                    <div className="flex flex-col gap-5 text-sm text-zinc-500">
                        <h4 className="text-white font-bold mb-2 uppercase tracking-widest text-xs">Legal</h4>
                        <a href="#">Privacy Policy</a>
                        <a href="#">Terms of Service</a>
                        <a href="#">Cookie Settings</a>
                        <a href="#">Trust Center</a>
                    </div>
                </div>
                <div className="max-w-7xl mx-auto mt-32 pt-12 border-t border-white/5 flex justify-between items-center text-[10px] mono text-zinc-600 opacity-40">
                    <div>© 2024 TRANSFORM TOOLING INC. ALL RIGHTS RESERVED.</div>
                    <div>VERSION_6.2.0_ORBITAL</div>
                </div>
            </footer>
        </div>
    )
}
