import React, { useEffect } from 'react'
import { ArrowRight, Instagram, ArrowDownRight, Plus, Minus, Star, Menu, Search, ShoppingBag } from 'lucide-react'

export default function Luxury() {
    useEffect(() => {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }, []);

    return (
        <div className="luxury-root bg-[#F9F8F6] text-[#1A1A1A] min-h-screen font-sans selection:bg-[#D4AF37] selection:text-white overflow-x-hidden" style={{ fontFamily: '"Inter", sans-serif' }}>
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500&display=swap');

                .luxury-root {
                    --alabaster: #F9F8F6;
                    --charcoal: #1A1A1A;
                    --gold: #D4AF37;
                    --taupe: #EBE5DE;
                    --grey: #6C6863;
                }

                .luxury-root h1, .luxury-root h2, .luxury-root h3, .luxury-root .serif {
                    font-family: 'Playfair Display', serif;
                }

                /* Noise Texture Overlay */
                .luxury-root .noise-bg::before {
                    content: "";
                    position: fixed;
                    top: 0;
                    right: 0;
                    bottom: 0;
                    left: 0;
                    z-index: 50;
                    pointer-events: none;
                    opacity: 0.02;
                    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
                }

                /* Vertical Text Label */
                .luxury-root .vertical-label {
                    writing-mode: vertical-rl;
                    text-orientation: mixed;
                }

                /* Drop Cap */
                .luxury-root .drop-cap::first-letter {
                    float: left;
                    font-family: 'Playfair Display', serif;
                    font-size: 5rem;
                    line-height: 0.8;
                    margin-top: 0.1em;
                    margin-right: 0.1em;
                    font-weight: 700;
                    color: var(--charcoal);
                }

                /* Gold Sliding Button Animation */
                .luxury-root .btn-gold-slide {
                    position: relative;
                    overflow: hidden;
                    transition: all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                    background-color: var(--charcoal);
                    color: white;
                    border: none;
                    padding: 1rem 2.5rem;
                    text-transform: uppercase;
                    font-size: 0.75rem;
                    letter-spacing: 0.2em;
                    font-weight: 500;
                    z-index: 1;
                }

                .luxury-root .btn-gold-slide::before {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: var(--gold);
                    transform: translateX(-100%);
                    transition: transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                    z-index: -1;
                }

                .luxury-root .btn-gold-slide:hover::before {
                    transform: translateX(0);
                }

                .luxury-root .btn-gold-slide:hover {
                    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
                }

                /* Grayscale to Color Transition */
                .luxury-root .editorial-img-container {
                    overflow: hidden;
                    position: relative;
                }

                .luxury-root .editorial-img {
                    transition: all 1.8s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                    filter: grayscale(100%);
                }

                .luxury-root .group:hover .editorial-img {
                    filter: grayscale(0%);
                    transform: scale(1.05);
                }

                /* Custom Underline */
                .luxury-root .luxury-link {
                    position: relative;
                    padding-bottom: 2px;
                }

                .luxury-root .luxury-link::after {
                    content: "";
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 0;
                    height: 1px;
                    background-color: var(--gold);
                    transition: width 0.5s ease;
                }

                .luxury-root .luxury-link:hover::after {
                    width: 100%;
                }

                /* Grid Lines */
                .luxury-root .grid-line {
                    position: fixed;
                    top: 0;
                    bottom: 0;
                    width: 1px;
                    background-color: rgba(26, 26, 26, 0.1);
                    pointer-events: none;
                    z-index: 40;
                }
            `}</style>

            <div className="noise-bg"></div>

            {/* Architectural Grid Lines */}
            <div className="grid-line left-[8%] hidden md:block"></div>
            <div className="grid-line left-[33%] hidden md:block"></div>
            <div className="grid-line left-[66%] hidden md:block"></div>
            <div className="grid-line right-[8%] hidden md:block"></div>

            {/* Navigation */}
            <nav className="relative z-[60] px-8 md:px-[8%] py-8 flex justify-between items-center border-b border-[#1A1A1A]/10">
                <div className="flex items-center gap-8">
                    <button className="md:hidden"><Menu size={20} /></button>
                    <div className="hidden md:flex gap-10 text-[10px] tracking-[0.3em] font-medium uppercase">
                        <a href="#" className="luxury-link">Collections</a>
                        <a href="#" className="luxury-link">Archives</a>
                        <a href="#" className="luxury-link">Sustainability</a>
                    </div>
                </div>

                <div className="absolute left-1/2 -translate-x-1/2 text-2xl font-bold tracking-[0.2em] serif italic">
                    ÉDITORIAL
                </div>

                <div className="flex items-center gap-8">
                    <div className="hidden md:flex items-center gap-4">
                        <Search size={16} strokeWidth={1.5} />
                        <Instagram size={16} strokeWidth={1.5} />
                    </div>
                    <div className="relative">
                        <ShoppingBag size={20} strokeWidth={1.5} />
                        <span className="absolute -top-1 -right-1 bg-[#D4AF37] text-white text-[8px] w-3 h-3 flex items-center justify-center rounded-full">2</span>
                    </div>
                </div>
            </nav>

            {/* Hero Section */}
            <section className="relative min-h-[90vh] flex flex-col pt-20 overflow-hidden">
                <div className="px-8 md:px-[8%] relative z-10">
                    <div className="flex flex-col md:flex-row justify-between items-end mb-16">
                        <div className="max-w-xl">
                            <div className="flex items-center gap-6 mb-8">
                                <span className="h-px w-12 bg-[#D4AF37]"></span>
                                <span className="text-[10px] tracking-[0.4em] font-medium uppercase text-[#6C6863]">Autumn / Winter 2024 Collection</span>
                            </div>
                            <h1 className="text-7xl md:text-9xl leading-[0.9] tracking-tighter mb-8 serif">
                                The <span className="italic text-[#D4AF37]">Art</span> of <br />Restraint.
                            </h1>
                        </div>
                        <div className="hidden md:block max-w-[280px] text-xs leading-relaxed text-[#6C6863] text-right mb-4">
                            Exploring the intersection of architectural precision and tactile luxury. A study in cinematic slow-motion and high-contrast editorial design.
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-0 items-start">
                        <div className="md:col-span-1 hidden md:block">
                            <div className="vertical-label text-[10px] tracking-[0.4em] font-medium uppercase text-[#6C6863] py-20 border-l border-[#1A1A1A]/10 pl-4 h-full">
                                Editorial / Vol. 01 — The New Essentialism
                            </div>
                        </div>
                        <div className="md:col-span-7 group">
                            <div className="editorial-img-container shadow-[0_8px_32px_rgba(0,0,0,0.12)]">
                                <img
                                    src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1600"
                                    alt="Editorial Fashion"
                                    className="editorial-img w-full aspect-[16/10] object-cover"
                                />
                                <div className="absolute bottom-8 left-8 bg-[#F9F8F6] p-4 hidden md:block translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-700">
                                    <div className="text-[10px] tracking-[0.2em] font-bold uppercase mb-1">Model: Amara Vane</div>
                                    <div className="text-[10px] text-[#6C6863] uppercase">Paris, France</div>
                                </div>
                            </div>
                        </div>
                        <div className="md:col-span-4 md:pl-20 py-12 flex flex-col justify-end min-h-[400px]">
                            <p className="text-lg leading-relaxed text-[#1A1A1A] mb-12 italic serif">
                                "Luxury is not about social status; it's about a state of mind. It's the quiet confidence that comes from knowing every detail has been perfected."
                            </p>
                            <div className="flex gap-12">
                                <button className="btn-gold-slide">Shop Collection</button>
                                <button className="flex items-center gap-4 text-xs tracking-[0.2em] uppercase font-bold group">
                                    <span>The Film</span>
                                    <ArrowRight size={14} className="group-hover:translate-x-2 transition-transform duration-500" />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Featured Section */}
            <section className="py-32 md:py-48 px-8 md:px-[8%] bg-[#1A1A1A] text-[#F9F8F6] relative overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-20 items-center">
                    <div className="md:col-span-5 relative z-10">
                        <div className="text-[#D4AF37] text-[10px] tracking-[0.4em] uppercase font-bold mb-8">The Philosophy</div>
                        <h2 className="text-5xl md:text-7xl serif leading-tight mb-12">
                            Curated <br /><span className="italic">Excellence.</span>
                        </h2>
                        <p className="text-sm md:text-base leading-relaxed text-[#F9F8F6]/60 mb-12 drop-cap">
                            We believe that objects should have a soul. Our process begins with the finest raw materials, sourced from historic ateliers across Europe. We don't follow trends; we create lasting impressions. Each piece is a testament to the enduring power of high-contrast design and architectural precision.
                        </p>
                        <button className="border border-[#F9F8F6]/20 bg-transparent text-[#F9F8F6] px-10 py-4 text-[10px] tracking-[0.3em] uppercase hover:bg-[#F9F8F6] hover:text-[#1A1A1A] transition-all duration-500">
                            Our Process
                        </button>
                    </div>
                    <div className="md:col-span-7 grid grid-cols-2 gap-8 relative z-10">
                        <div className="group mt-20">
                            <div className="editorial-img-container shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
                                <img
                                    src="https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&q=80&w=800"
                                    alt="Editorial Detail"
                                    className="editorial-img w-full aspect-[3/4] object-cover"
                                />
                            </div>
                        </div>
                        <div className="group">
                            <div className="editorial-img-container shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
                                <img
                                    src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=800"
                                    alt="Editorial Fabric"
                                    className="editorial-img w-full aspect-[3/4] object-cover"
                                />
                            </div>
                        </div>
                    </div>
                </div>
                {/* Decorative Element */}
                <div className="absolute top-0 right-0 w-1/3 h-full bg-[#EBE5DE]/5 -z-0"></div>
            </section>

            {/* Product Section */}
            <section className="py-32 md:py-48 px-8 md:px-[8%]">
                <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
                    <div className="max-w-xl">
                        <h2 className="text-5xl md:text-6xl serif mb-6">Signature Pieces</h2>
                        <div className="h-px w-24 bg-[#D4AF37] mb-8"></div>
                    </div>
                    <div className="flex gap-4">
                        <button className="w-12 h-12 flex items-center justify-center border border-[#1A1A1A]/10 hover:border-[#1A1A1A] transition-colors"><Minus size={16} /></button>
                        <button className="w-12 h-12 flex items-center justify-center border border-[#1A1A1A]/10 hover:border-[#1A1A1A] transition-colors"><Plus size={16} /></button>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
                    {[
                        { name: 'Alabaster Silk Scarf', price: '$420', img: 'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?auto=format&fit=crop&q=80&w=800' },
                        { name: 'Charcoal Wool Coat', price: '$1,850', img: 'https://images.unsplash.com/photo-1539533113208-f6df8cc8b543?auto=format&fit=crop&q=80&w=800' },
                        { name: 'Gold Leaf Earring', price: '$780', img: 'https://images.unsplash.com/photo-1535633302704-b02f4f141240?auto=format&fit=crop&q=80&w=800' }
                    ].map((item, i) => (
                        <div key={i} className="group cursor-pointer">
                            <div className="editorial-img-container mb-8 shadow-[0_4px_24px_rgba(0,0,0,0.08)] group-hover:shadow-[0_8px_32px_rgba(0,0,0,0.15)] transition-all duration-700">
                                <img
                                    src={item.img}
                                    alt={item.name}
                                    className="editorial-img w-full aspect-[4/5] object-cover"
                                />
                            </div>
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="text-xl serif italic mb-2 group-hover:text-[#D4AF37] transition-colors duration-500">{item.name}</h3>
                                    <p className="text-[10px] tracking-[0.2em] uppercase text-[#6C6863]">Sustainable Silk / Linen</p>
                                </div>
                                <div className="text-sm font-medium">{item.price}</div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Testimonial Section */}
            <section className="py-32 md:py-48 px-8 md:px-[8%] bg-[#EBE5DE]/30 border-t border-b border-[#1A1A1A]/5">
                <div className="max-w-4xl mx-auto text-center">
                    <div className="flex justify-center gap-2 mb-12">
                        {Array.from({ length: 5 }).map((_, i) => <Star key={i} size={14} fill="#D4AF37" color="#D4AF37" />)}
                    </div>
                    <h2 className="text-3xl md:text-4xl serif italic leading-relaxed mb-16 px-8 drop-cap">
                        "The level of detail in this collection is simply unparalleled. It doesn't scream for attention, it commands it through pure, unadulterated quality. This is the new standard of editorial digital experiences."
                    </h2>
                    <div className="flex flex-col items-center">
                        <div className="w-20 h-20 rounded-full overflow-hidden mb-6 grayscale hover:grayscale-0 transition-all duration-1000 border-2 border-[#D4AF37]">
                            <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200" alt="Author" className="w-full h-full object-cover" />
                        </div>
                        <div className="text-[10px] tracking-[0.4em] uppercase font-bold">Isabella Thorne</div>
                        <div className="text-[10px] tracking-[0.2em] uppercase text-[#6C6863] mt-2">Creative Director, Vogue</div>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="bg-[#1A1A1A] text-[#F9F8F6] pt-32 pb-16 px-8 md:px-[8%] relative overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-20 mb-32 relative z-10">
                    <div className="md:col-span-6">
                        <div className="text-5xl md:text-7xl serif italic mb-12">ÉDITORIAL.</div>
                        <div className="max-w-md text-sm leading-relaxed text-[#F9F8F6]/60 mb-12">
                            Join our private circle for exclusive access to archival releases, cinematic previews, and editorial insights into the making of luxury.
                        </div>
                        <form className="flex border-b border-[#F9F8F6]/20 pb-4 max-w-sm group focus-within:border-[#D4AF37] transition-colors duration-500">
                            <input
                                type="email"
                                placeholder="Email Address"
                                className="bg-transparent border-none outline-none text-sm w-full serif italic placeholder:text-[#F9F8F6]/30"
                            />
                            <button type="submit" className="text-[10px] tracking-[0.3em] uppercase font-bold hover:text-[#D4AF37] transition-colors">Submit</button>
                        </form>
                    </div>
                    <div className="md:col-span-6 grid grid-cols-2 md:grid-cols-3 gap-12">
                        <div className="flex flex-col gap-6">
                            <h4 className="text-[10px] tracking-[0.3em] uppercase font-bold text-[#D4AF37]">Information</h4>
                            <div className="flex flex-col gap-4 text-xs font-medium text-[#F9F8F6]/60 uppercase tracking-widest">
                                <a href="#" className="hover:text-white transition-colors">About Us</a>
                                <a href="#" className="hover:text-white transition-colors">Careers</a>
                                <a href="#" className="hover:text-white transition-colors">Stores</a>
                                <a href="#" className="hover:text-white transition-colors">Contact</a>
                            </div>
                        </div>
                        <div className="flex flex-col gap-6">
                            <h4 className="text-[10px] tracking-[0.3em] uppercase font-bold text-[#D4AF37]">Support</h4>
                            <div className="flex flex-col gap-4 text-xs font-medium text-[#F9F8F6]/60 uppercase tracking-widest">
                                <a href="#" className="hover:text-white transition-colors">Shipping</a>
                                <a href="#" className="hover:text-white transition-colors">Returns</a>
                                <a href="#" className="hover:text-white transition-colors">Warranty</a>
                                <a href="#" className="hover:text-white transition-colors">FAQ</a>
                            </div>
                        </div>
                        <div className="flex flex-col gap-6 col-span-2 md:col-span-1">
                            <h4 className="text-[10px] tracking-[0.3em] uppercase font-bold text-[#D4AF37]">Social</h4>
                            <div className="flex flex-col gap-4 text-xs font-medium text-[#F9F8F6]/60 uppercase tracking-widest">
                                <a href="#" className="hover:text-white transition-colors">Instagram</a>
                                <a href="#" className="hover:text-white transition-colors">Vimeo</a>
                                <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="pt-16 border-t border-[#F9F8F6]/5 flex flex-col md:flex-row justify-between items-center gap-8 relative z-10">
                    <div className="text-[10px] tracking-[0.2em] uppercase text-[#F9F8F6]/30">
                        © 2024 ÉDITORIAL INDUSTRIES. ALL RIGHTS RESERVED.
                    </div>
                    <div className="flex gap-12 text-[10px] tracking-[0.3em] uppercase font-black">
                        PARIS / NEW YORK / TOKYO / LONDON
                    </div>
                    <div className="text-[10px] tracking-[0.1em] text-[#F9F8F6]/30 uppercase">
                        Privacy Policy / Terms of Service
                    </div>
                </div>

                {/* Decorative Grid Marker */}
                <div className="absolute bottom-0 right-0 p-12 opacity-5 pointer-events-none">
                    <div className="text-[15rem] leading-none serif font-black">01</div>
                </div>
            </footer>
        </div>
    )
}
