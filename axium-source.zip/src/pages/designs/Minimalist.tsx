import React, { useEffect } from 'react'
import { ArrowRight, Menu, X, Instagram, Twitter, Mail, ArrowUpRight } from 'lucide-react'

export default function Minimalist() {
    useEffect(() => {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Source+Serif+4:ital,opsz,wght@0,8..60,300;0,8..60,400;1,8..60,400&family=JetBrains+Mono:wght@400;500&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }, []);

    return (
        <div className="minimalist-root bg-white text-black min-h-screen font-serif selection:bg-black selection:text-white" style={{ fontFamily: '"Source Serif 4", Georgia, serif' }}>
            <style>{`
                .minimalist-root {
                    --ink: #000000;
                    --paper: #ffffff;
                }
                .minimalist-root h1, .minimalist-root h2, .minimalist-root h3 {
                    font-family: "Playfair Display", serif;
                    text-transform: uppercase;
                    letter-spacing: -0.05em;
                    line-height: 0.85;
                }
                .minimalist-root .mono {
                    font-family: "JetBrains Mono", monospace;
                    text-transform: uppercase;
                    letter-spacing: 0.15em;
                    font-size: 10px;
                    font-weight: 500;
                }
                .minimalist-root .btn-ink {
                    background: var(--ink);
                    color: var(--paper);
                    padding: 1.25rem 3rem;
                    text-transform: uppercase;
                    letter-spacing: 0.25em;
                    font-size: 10px;
                    font-weight: 700;
                    border: none;
                    transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
                    cursor: pointer;
                }
                .minimalist-root .btn-ink:hover {
                    padding-right: 4rem;
                    background: #222;
                }
                .minimalist-root .hairline {
                    border-top: 1px solid var(--ink);
                    width: 100%;
                    opacity: 0.1;
                }
                .minimalist-root .rule {
                    border-top: 2px solid var(--ink);
                    width: 100%;
                }
                .minimalist-root .vertical-line {
                    width: 1px;
                    height: 100%;
                    background: var(--ink);
                    opacity: 0.1;
                }
                @keyframes slideUp {
                    from { transform: translateY(50px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
                .minimalist-root .animate-in {
                    animation: slideUp 1.2s cubic-bezier(0.16, 1, 0.3, 1) both;
                }
            `}</style>

            {/* Global Borders / Framing */}
            <div className="fixed inset-0 pointer-events-none z-[100] border-[12px] md:border-[24px] border-white" />

            {/* Header Navigation */}
            <nav className="fixed top-0 left-0 w-full z-50 p-12 md:p-20 flex justify-between items-start pointer-events-none">
                <div className="pointer-events-auto">
                    <div className="text-2xl font-black italic tracking-tighter hover:tracking-normal transition-all duration-500 cursor-pointer">AS.</div>
                    <div className="mono mt-2 opacity-40">London / Kyoto</div>
                </div>
                <div className="hidden md:flex flex-col gap-4 pointer-events-auto text-right">
                    <button className="mono hover:translate-x-[-8px] transition-transform duration-300">Archive_01</button>
                    <button className="mono hover:translate-x-[-8px] transition-transform duration-300">Method_02</button>
                    <button className="mono hover:translate-x-[-8px] transition-transform duration-300">Studio_03</button>
                    <button className="mono hover:translate-x-[-8px] transition-transform duration-300 font-bold">Connect</button>
                </div>
                <button className="md:hidden pointer-events-auto">
                    <Menu size={24} />
                </button>
            </nav>

            {/* Hero Section */}
            <header className="relative min-h-screen flex flex-col justify-end p-12 md:p-24 pb-32">
                <div className="max-w-[90vw] animate-in">
                    <h1 className="text-[18vw] leading-[0.8] font-black italic md:-ml-2">
                        STARK<br />REDUCTION.
                    </h1>
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mt-20 items-end">
                        <div className="md:col-span-4 border-t-2 border-black pt-8">
                            <div className="mono mb-4">Volume 01 / Spatial Logic</div>
                            <p className="text-xl leading-relaxed text-zinc-800">
                                We curate the void. An architectural practice dedicated to the ruthless elimination of the ornamental, finding authority in the silence between forms.
                            </p>
                        </div>
                        <div className="hidden md:block md:col-span-4" />
                        <div className="md:col-span-4 flex flex-col items-start gap-8">
                            <button className="btn-ink">Inquire Studio</button>
                            <div className="mono opacity-30 text-[9px] max-w-[180px]">
                                OUR PHILOSOPHY IS ROOTED IN THE BELIEF THAT LESS IS NOT JUST MORE, BUT EVERYTHING.
                            </div>
                        </div>
                    </div>
                </div>

                {/* Background Textural Element */}
                <div className="absolute top-1/2 left-0 w-full h-[1px] bg-black/5 -z-10" />
            </header>

            {/* Case Study Section - Dramatic Contrast */}
            <section className="bg-black text-white py-40 md:py-60 px-12 md:px-24">
                <div className="max-w-7xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-24 items-center">
                        <div className="order-2 md:order-1 relative">
                            <div className="aspect-[3/4] bg-zinc-900 overflow-hidden relative group">
                                <div className="absolute inset-0 bg-white/5 group-hover:bg-transparent transition-colors duration-700" />
                                <div className="absolute top-8 left-8 mono text-zinc-500">PROJECT_08B / KYOTO</div>
                                <div className="absolute bottom-12 right-12 text-6xl italic font-black text-zinc-800">08.</div>
                            </div>
                            <div className="absolute -bottom-12 -right-12 w-64 h-64 border border-white/10 -z-10" />
                        </div>
                        <div className="order-1 md:order-2 flex flex-col gap-12">
                            <div className="mono text-zinc-500">Structure / Material / Light</div>
                            <h2 className="text-7xl md:text-9xl font-bold leading-none tracking-tighter">
                                THE EDGE<br />OF NOTHING.
                            </h2>
                            <p className="text-xl text-zinc-400 max-w-md leading-relaxed font-light italic">
                                "The most powerful spaces are those that do not demand your attention, but allow your thoughts to expand within them."
                            </p>
                            <button className="flex items-center gap-4 group self-start">
                                <span className="mono text-white group-hover:translate-x-2 transition-transform">Explore Methodology</span>
                                <ArrowRight size={20} className="text-zinc-500 group-hover:translate-x-4 transition-transform" />
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            {/* Grid Exhibition */}
            <section className="py-40 px-12 md:px-24 bg-white">
                <div className="flex justify-between items-end mb-20">
                    <div>
                        <div className="mono text-zinc-400 mb-4">Studio Principles</div>
                        <h2 className="text-6xl font-bold tracking-tighter">THE JOURNAL.</h2>
                    </div>
                    <div className="hidden md:block mono">Issue 04 / 2024</div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-zinc-100 border-y border-zinc-100">
                    {[
                        { num: '01', title: 'Absolute Contrast', desc: 'The interplay between pure light and total shadow defines the architectural soul.' },
                        { num: '02', title: 'Honest Material', desc: 'Preserving the original integrity of concrete, glass, and raw structural steel.' },
                        { num: '03', title: 'Dynamic Void', desc: 'Vacant space is not empty; it is the most active element in our design logic.' }
                    ].map((item, i) => (
                        <div key={i} className="py-12 md:p-12 hover:bg-zinc-50 transition-colors group cursor-pointer">
                            <div className="flex justify-between items-start mb-12">
                                <span className="text-4xl italic font-black text-zinc-100 group-hover:text-black transition-colors">{item.num}</span>
                                <ArrowUpRight size={20} className="text-zinc-200 group-hover:text-black transition-colors" />
                            </div>
                            <h3 className="text-3xl font-bold mb-6 italic">{item.title}</h3>
                            <p className="text-zinc-500 leading-relaxed font-light">{item.desc}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Full Width Quote - Massive Type */}
            <section className="py-40 md:py-60 px-12 overflow-hidden bg-black text-white text-center">
                <h2 className="text-[12vw] font-black italic leading-[0.8] opacity-10 whitespace-nowrap -ml-40">
                    LESS BUT BETTER • LESS BUT BETTER • LESS BUT BETTER
                </h2>
                <div className="max-w-4xl mx-auto relative z-10 -mt-20 md:-mt-32">
                    <p className="text-2xl md:text-4xl font-light italic leading-relaxed">
                        Architecture should not speak; it should remain silent and allow the light to tell the story of the space.
                    </p>
                    <div className="mt-12 mono text-zinc-500">Dieter Rams / Inspiration</div>
                </div>
                <h2 className="text-[12vw] font-black italic leading-[0.8] opacity-10 whitespace-nowrap ml-40 mt-12">
                    REDUCE EVERYTHING • REDUCE EVERYTHING • REDUCE EVERYTHING
                </h2>
            </section>

            {/* Footer */}
            <footer className="bg-white py-24 md:py-40 px-12 md:px-24 border-t-8 border-black">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-16 md:gap-0">
                    <div className="md:col-span-6">
                        <div className="text-5xl font-black italic mb-8">AS. STUDIO</div>
                        <p className="max-w-xs text-zinc-500 leading-relaxed">
                            A global collective of architects and designers rethinking the minimalist aesthetic for the modern age.
                        </p>
                    </div>
                    <div className="md:col-span-2 flex flex-col gap-6">
                        <div className="mono opacity-40">Connect</div>
                        <div className="flex flex-col gap-2 font-bold underline underline-offset-4">
                            <a href="#" className="hover:text-zinc-400">Instagram</a>
                            <a href="#" className="hover:text-zinc-400">Twitter</a>
                            <a href="#" className="hover:text-zinc-400">Bento</a>
                        </div>
                    </div>
                    <div className="md:col-span-2 flex flex-col gap-6">
                        <div className="mono opacity-40">Studio</div>
                        <div className="flex flex-col gap-2 font-bold underline underline-offset-4">
                            <a href="#" className="hover:text-zinc-400">London</a>
                            <a href="#" className="hover:text-zinc-400">Kyoto</a>
                            <a href="#" className="hover:text-zinc-400">Berlin</a>
                        </div>
                    </div>
                    <div className="md:col-span-2 flex flex-col gap-6">
                        <div className="mono opacity-40">Privacy</div>
                        <div className="flex flex-col gap-2 font-bold underline underline-offset-4">
                            <a href="#" className="hover:text-zinc-400">Terms</a>
                            <a href="#" className="hover:text-zinc-400">Legal</a>
                        </div>
                    </div>
                </div>
                <div className="mt-32 pt-8 border-t border-zinc-100 flex flex-col md:flex-row justify-between items-center gap-8 mono text-[9px] opacity-30">
                    <div>© 2024 ASH & STONE ARCHITECTURAL STUDIO. ALL RIGHTS RESERVED.</div>
                    <div className="flex gap-12">
                        <span>VERSION 2.4.0</span>
                        <span>DESIGNED BY MNML_SYS</span>
                    </div>
                </div>
            </footer>
        </div>
    )
}
