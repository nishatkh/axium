import React, { useState, useEffect } from 'react'
import { Terminal as TerminalIcon, Shield, Activity, Cpu, Lock, Zap, ChevronRight, Binary, Database, Box } from 'lucide-react'

export default function Terminal() {
    const [text, setText] = useState('');
    const fullText = "AUTHENTICATED_SESSION_0x82... INITIALIZING VORTEX_DEFENSE_CLOUD...";

    useEffect(() => {
        let i = 0;
        const timer = setInterval(() => {
            setText(fullText.slice(0, i));
            i++;
            if (i > fullText.length) clearInterval(timer);
        }, 50);
        return () => clearInterval(timer);
    }, []);

    return (
        <div className="terminal-root bg-[#0A0A0A] text-[#00FF41] min-h-screen font-mono overflow-x-hidden selection:bg-[#00FF41] selection:text-black">
            <style>{`
                .terminal-root {
                    --accent: #00FF41;
                    --glow: rgba(0, 255, 65, 0.2);
                    --border: 1px solid rgba(0, 255, 65, 0.3);
                    --crt-scanline: linear-gradient(to bottom, transparent font-size: 50%, rgba(0, 0, 0, 0.1) 50%);
                }
                .terminal-root .crt::before {
                    content: " ";
                    display: block;
                    position: fixed;
                    top: 0; left: 0; bottom: 0; right: 0;
                    background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.1) 50%), 
                                linear-gradient(90deg, rgba(255, 0, 0, 0.03), rgba(0, 255, 0, 0.01), rgba(0, 0, 255, 0.03));
                    z-index: 100;
                    background-size: 100% 4px, 6px 100%;
                    pointer-events: none;
                }
                .terminal-root .crt::after {
                    content: " ";
                    display: block;
                    position: fixed;
                    top: 0; left: 0; bottom: 0; right: 0;
                    background: rgba(18, 16, 16, 0.05);
                    opacity: 0;
                    z-index: 100;
                    pointer-events: none;
                    animation: flicker 0.15s infinite;
                }
                @keyframes flicker {
                    0% { opacity: 0.27861; } 5% { opacity: 0.34769; } 
                    10% { opacity: 0.23604; } 15% { opacity: 0.90626; }
                    20% { opacity: 0.18128; } 25% { opacity: 0.83891; }
                    30% { opacity: 0.65583; } 35% { opacity: 0.57807; }
                    40% { opacity: 0.26559; } 45% { opacity: 0.84693; }
                    50% { opacity: 0.96019; } 55% { opacity: 0.08523; }
                    60% { opacity: 0.71056; } 65% { opacity: 0.73437; }
                    70% { opacity: 0.28574; } 75% { opacity: 0.96387; }
                    80% { opacity: 0.22679; } 85% { opacity: 0.57148; }
                    90% { opacity: 0.82983; } 95% { opacity: 0.43479; }
                    100% { opacity: 0.35123; }
                }
                .terminal-root .btn-terminal {
                    border: 1px solid var(--accent);
                    background: transparent;
                    color: var(--accent);
                    padding: 10px 20px;
                    text-transform: uppercase;
                    transition: all 0.2s ease;
                    cursor: pointer;
                    box-shadow: 0 0 10px var(--glow);
                }
                .terminal-root .btn-terminal:hover {
                    background: var(--accent);
                    color: black;
                    box-shadow: 0 0 25px var(--accent);
                }
                .terminal-root .panel {
                    border: var(--border);
                    background: rgba(0, 40, 0, 0.05);
                    padding: 20px;
                    position: relative;
                }
                .terminal-root .panel::before {
                    content: "STATUS_OK";
                    position: absolute;
                    top: -10px; right: 20px;
                    background: #0A0A0A;
                    padding: 0 10px;
                    font-size: 10px;
                }
            `}</style>

            <div className="crt">
                {/* Header / Nav */}
                <header className="p-8 border-b border-[#00FF41]/30 flex justify-between items-center bg-[#070707]">
                    <div className="flex items-center gap-4">
                        <TerminalIcon className="animate-pulse" size={24} />
                        <div className="flex flex-col">
                            <h1 className="text-xl font-bold tracking-widest uppercase">Vortex Defense</h1>
                            <span className="text-[10px] opacity-60">KERNEL_VER_10.2.0-STABLE</span>
                        </div>
                    </div>
                    <div className="hidden md:flex gap-10 text-xs">
                        <span className="hover:bg-[#00FF41] hover:text-black px-2 cursor-pointer transition-colors">[ NETWORK ]</span>
                        <span className="hover:bg-[#00FF41] hover:text-black px-2 cursor-pointer transition-colors">[ SECURITY ]</span>
                        <span className="hover:bg-[#00FF41] hover:text-black px-2 cursor-pointer transition-colors">[ STORAGE ]</span>
                        <span className="hover:bg-[#00FF41] hover:text-black px-2 cursor-pointer transition-colors">[ MANIFEST ]</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs">
                        <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-ping" />
                        UPTIME: 14:02:44
                    </div>
                </header>

                {/* Hero / Terminal Intro */}
                <section className="p-12 md:p-24 grid grid-cols-1 md:grid-cols-12 gap-16">
                    <div className="md:col-span-12">
                        <div className="text-sm opacity-60 mb-8">{text}<span className="animate-bounce">_</span></div>
                        <h2 className="text-[10vw] font-black tracking-tighter leading-none mb-12">
                            DEFENSE_GRADE<br />CLOUD_OS
                        </h2>

                        {/* ASCII Art Simulation */}
                        <pre className="text-[8px] md:text-[10px] leading-none mb-12 opacity-80 text-[#008F11]">
                            {`   __________________________________________________________________________
  /                                                                          \\
 |    __________________________________________________________________    |
 |   |                                                                  |   |
 |   |   VORTEX CORE: ACTIVE                                            |   |
 |   |   THREAT REDUCTION: 99.98%                                       |   |
 |   |   LATENCY: 0.04ms                                                |   |
 |   |   ENCRYPTION: QUANTUM_ENABLED                                    |   |
 |   |__________________________________________________________________|   |
 |                                                                          |
  \\__________________________________________________________________________/`}
                        </pre>

                        <div className="flex flex-wrap gap-6">
                            <button className="btn-terminal">Initialize Deployment</button>
                            <button className="border border-[#00FF41]/30 p-2 text-xs flex items-center gap-2 hover:bg-[#00FF41]/10">
                                <Binary size={14} /> View Kernel Source
                            </button>
                        </div>
                    </div>
                </section>

                {/* Dashboard grid */}
                <section className="px-12 md:px-24 py-12 grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        { icon: <Shield />, label: 'HARDWARE_ENCLAVE', val: 'SECURE' },
                        { icon: <Zap />, label: 'THROUGHPUT_EFF', val: '942GB/S' },
                        { icon: <Lock />, label: 'ROOT_ACCESS', val: 'ENCRYPTED' }
                    ].map((item, i) => (
                        <div key={i} className="panel flex items-center gap-6 group hover:bg-[#00FF41]/5 transition-colors cursor-crosshair">
                            <div className="text-3xl opacity-40 group-hover:opacity-100 group-hover:scale-110 transition-all">
                                {item.icon}
                            </div>
                            <div>
                                <div className="text-[10px] opacity-40 mb-1">{item.label}</div>
                                <div className="text-xl font-bold tracking-widest">{item.val}</div>
                            </div>
                        </div>
                    ))}
                </section>

                {/* Interactive Log simulation */}
                <section className="px-12 md:px-24 py-20">
                    <div className="panel bg-black/40 min-h-[400px]">
                        <div className="flex justify-between border-b border-[#00FF41]/20 pb-4 mb-6">
                            <span className="text-xs uppercase font-bold">[ SYSTEM_LOGS / FEB_24 ]</span>
                            <div className="flex gap-2">
                                <div className="w-2 h-2 rounded-full bg-red-500/50" />
                                <div className="w-2 h-2 rounded-full bg-yellow-500/50" />
                                <div className="w-2 h-2 rounded-full bg-green-500/50" />
                            </div>
                        </div>
                        <div className="flex flex-col gap-2 font-mono text-xs opacity-80 overflow-hidden h-[300px]">
                            <div className="text-[#008F11]">[ 04:22:01 ] INBOUND_CONNECTION_ESTABLISHED: 192.168.0.1</div>
                            <div className="text-[#008F11]">[ 04:22:04 ] AUTHENTICATION_SUCCESS: USER_ADMIN_VORTEX</div>
                            <div className="text-[#00FF41]">[ 04:22:08 ] LOADING_RESOURCES: [ ########## ] 100%</div>
                            <div className="text-yellow-500">[ 04:22:12 ] WARN: RESOURCE_LEAK_IN_MODULE_KBN</div>
                            <div className="text-[#008F11]">[ 04:22:15 ] INITIALIZING_QUANTUM_HANDSHAKE...</div>
                            <div className="text-[#008F11]">[ 04:22:18 ] SHIELD_PROTOCOLS_ENGAGED</div>
                            <div className="text-[#008F11]">[ 04:22:20 ] STANDBY_MODE_DISENGAGED</div>
                            <div className="text-red-500">[ 04:22:24 ] ERR: MALICIOUS_PACKET_DETECTED_AND_DROPPED</div>
                            <div className="text-[#008F11]">[ 04:22:28 ] LOGGING_SESSION_METADATA_TO_DB04</div>
                            <div className="text-white/20">... system scanning ...</div>
                        </div>
                        <div className="mt-8 pt-6 border-t border-[#00FF41]/10 flex justify-between items-center">
                            <div className="text-xs flex items-center gap-4">
                                <span className="flex items-center gap-2"><Database size={12} /> DB_ACTIVE</span>
                                <span className="flex items-center gap-2"><Cpu size={12} /> CORE_94%</span>
                            </div>
                            <div className="flex items-center gap-2 text-xs">
                                EXPORT_LOGS <ChevronRight size={14} className="animate-bounce" />
                            </div>
                        </div>
                    </div>
                </section>

                {/* Footer */}
                <footer className="p-12 md:p-24 border-t border-[#00FF41]/30 bg-[#050505]">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-16">
                        <div className="col-span-2">
                            <div className="text-3xl font-black mb-6 tracking-widest uppercase flex items-center gap-4">
                                <Box className="text-[#00FF41]" /> VORTEX.SYSTEMS
                            </div>
                            <p className="text-sm opacity-50 max-w-sm mb-12">
                                THE WORLD'S ONLY TRUE QUANTUM-HARDENED CLOUD INFRASTRUCTURE.
                                BUILT FOR THE ERA OF POST-SILICON SURVEILLANCE.
                            </p>
                        </div>
                        <div className="flex flex-col gap-4 text-xs">
                            <h4 className="font-bold opacity-30">[ COMMANDS ]</h4>
                            <a href="#" className="hover:text-white transition-colors">/deploy</a>
                            <a href="#" className="hover:text-white transition-colors">/scan</a>
                            <a href="#" className="hover:text-white transition-colors">/secure</a>
                            <a href="#" className="hover:text-white transition-colors">/reboot</a>
                        </div>
                        <div className="flex flex-col gap-4 text-xs">
                            <h4 className="font-bold opacity-30">[ NODES ]</h4>
                            <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-[#00FF41]" /> US_EAST_01</span>
                            <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-[#00FF41]" /> EU_WEST_04</span>
                            <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-red-500" /> ASIA_SOUTH_02 (OFFLINE)</span>
                            <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-[#00FF41]" /> GLOBAL_CORE_00</span>
                        </div>
                    </div>
                    <div className="mt-24 pt-12 border-t border-[#00FF41]/10 flex flex-col md:flex-row justify-between items-center gap-12 text-[10px] opacity-40">
                        <div>© 2024 VORTEX DEFENSE SYSTEMS. NO RIGHTS RESERVED. CODE IS FREE.</div>
                        <div className="flex gap-8 italic">
                            <span>REDACTED_PROTOCOL_V4</span>
                            <span>OPERATOR: MNML_SYS</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    )
}
