import React, { useEffect } from 'react'
import { ArrowRight, ChevronDown, Share2, Bookmark, MessageSquare, Search, Menu } from 'lucide-react'

export default function Newsprint() {
    useEffect(() => {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Inter:wght@400;500;600;700;800;900&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }, []);

    return (
        <div className="newsprint-root bg-[#FDFCF6] text-[#1A1A1A] min-h-screen font-serif selection:bg-[#F2E8CF] selection:text-[#1A1A1A] pb-20">
            <style>{`
                .newsprint-root {
                    --ink: #1A1A1A;
                    --paper: #FDFCF6;
                    --gray: #E0DCD0;
                    --accent: #A31A1A;
                }
                .newsprint-root h1, .newsprint-root h2, .newsprint-root h3, .newsprint-root h4 {
                    font-family: "Playfair Display", serif;
                    font-weight: 900;
                    letter-spacing: -0.02em;
                    line-height: 1.1;
                    color: var(--ink);
                }
                .newsprint-root p {
                    font-family: "Crimson Text", serif;
                    line-height: 1.65;
                    font-size: 19px;
                    color: rgba(26, 26, 26, 0.9);
                    margin-bottom: 24px;
                }
                .newsprint-root .masthead {
                    border-bottom: 8px double var(--ink);
                    border-top: 2px solid var(--ink);
                    padding: 50px 0;
                    margin: 30px 0;
                }
                .newsprint-root .kicker {
                    font-family: "Inter", sans-serif;
                    text-transform: uppercase;
                    letter-spacing: 0.25em;
                    font-size: 11px;
                    font-weight: 800;
                    color: var(--accent);
                    margin-bottom: 12px;
                    display: block;
                }
                .newsprint-root .dropcap::first-letter {
                    float: left;
                    font-size: 6.5rem;
                    line-height: 0.82;
                    padding-right: 12px;
                    font-weight: 900;
                    font-family: "Playfair Display", serif;
                    color: var(--ink);
                }
                .newsprint-root .rule-heavy {
                    border-top: 4px solid var(--ink);
                }
                .newsprint-root .rule-thin {
                    border-top: 1px solid var(--gray);
                }
                .newsprint-root .featured-quote {
                    font-style: italic;
                    font-size: 2.2rem;
                    line-height: 1.2;
                    border-left: 2px solid var(--accent);
                    padding-left: 30px;
                    margin: 40px 0;
                    font-weight: 400;
                }
                .newsprint-root .sidebar-item {
                    border-bottom: 1px solid var(--gray);
                    padding-bottom: 24px;
                    margin-bottom: 24px;
                }
                .newsprint-root .sidebar-item:last-child {
                    border-bottom: none;
                }
            `}</style>

            {/* Top Bar */}
            <div className="max-w-[1400px] mx-auto px-6 md:px-12">
                <header className="flex justify-between items-center py-6 border-b border-zinc-200 font-sans text-[10px] uppercase tracking-[0.2em] font-black text-zinc-500">
                    <div className="flex items-center gap-8">
                        <Menu size={16} />
                        <span className="hidden md:block">Volume 142 // Issue 082</span>
                    </div>
                    <div className="text-zinc-900 border-x border-zinc-200 px-8">
                        Tuesday, Feb 24, 2024
                    </div>
                    <div className="flex items-center gap-8">
                        <span className="hidden md:block">Price: $4.50</span>
                        <Search size={16} />
                    </div>
                </header>

                {/* Main Masthead */}
                <div className="masthead text-center">
                    <h1 className="text-8xl md:text-[13rem] tracking-tighter leading-none">
                        THE BROADSHEET.
                    </h1>
                </div>

                {/* Sub-Masthead Info */}
                <div className="flex justify-center py-2 border-b-2 border-black mb-12">
                    <div className="mono text-[11px] uppercase tracking-widest font-black text-zinc-800">
                        Politics • Philosophy • Architecture • Technology • Culture
                    </div>
                </div>

                {/* Main Content Layout */}
                <main className="grid grid-cols-1 md:grid-cols-12 gap-16">
                    {/* Primary Article */}
                    <div className="md:col-span-8">
                        <article className="animate-in">
                            <span className="kicker">Perspective / Technology</span>
                            <h2 className="text-6xl md:text-[6.5rem] leading-[0.9] mb-12">
                                The Return to Density:<br />Why Whitespace is Losing Its Authority.
                            </h2>

                            <div className="flex items-center gap-6 py-6 border-y border-zinc-200 mb-12">
                                <div className="w-12 h-12 rounded-none bg-zinc-900" />
                                <div className="flex flex-col">
                                    <span className="font-sans font-black text-xs uppercase tracking-tight">By Julian S. Vane</span>
                                    <span className="font-sans text-[10px] text-zinc-500 uppercase tracking-widest">Global Creative Lead, MNML_SYS</span>
                                </div>
                                <div className="ml-auto flex gap-4 text-zinc-400">
                                    <Share2 size={16} className="hover:text-black cursor-pointer" />
                                    <Bookmark size={16} className="hover:text-black cursor-pointer" />
                                </div>
                            </div>

                            <div className="columns-1 md:columns-2 gap-12 border-b border-zinc-100 pb-12">
                                <p className="dropcap">
                                    For the past decade, digital design has been obsessed with the void. We were told that whitespace was the ultimate luxury—a mark of sophistication that differentiated the "premium" from the "cluttered." But as the internet matures into a permanent fixture of our intellectual lives, a silent revolution is brewing. Users are starving for density. They are looking for the authoritative weight of information that once belonged exclusively to the morning newspaper.
                                </p>
                                <p>
                                    This movement, often termed "Editorial Rigor," rejects the fleeting, swipe-based economy of social media in favor of a narrative architecture that demands focus. It is a return to form where typography is not just a medium for content, but the hero of the interface itself.
                                </p>
                                <div className="featured-quote">
                                    "We have reached peak minimalism; the user is now starving for content that feels heavy, researched, and permanent."
                                </div>
                                <p>
                                    High-contrast serifs, once considered too "slow" for the screen, are now the weapon of choice for the new creative elite. These typefaces, optimized for the highest resolutions, bring a sense of history and permanence to the ephemeral digital window.
                                </p>
                                <p>
                                    When we look at the most successful digital publications of the modern year, we see a common thread: they communicate authority through density. They do not hide their content; they organize it with surgical precision into columns, rules, and mastheads that command respect.
                                </p>
                            </div>

                            {/* Secondary Article within column */}
                            <div className="mt-12">
                                <span className="kicker !text-zinc-400">Related / Philosophical Inquiry</span>
                                <h3 className="text-4xl mb-6 italic">The Vanishing Art of the Drop Cap and Why It Must Be Revived.</h3>
                                <p className="text-lg">
                                    The drop cap was never merely a decoration. It was a beacon—a starting point for the eye to anchor itself before diving into the depths of a complex narrative...
                                </p>
                                <button className="font-sans font-black text-[10px] uppercase tracking-widest flex items-center gap-2 group">
                                    Continue Reading <ArrowRight size={14} className="group-hover:translate-x-2 transition-transform" />
                                </button>
                            </div>
                        </article>
                    </div>

                    {/* Sidebar / Secondary News Column */}
                    <aside className="md:col-span-4 flex flex-col gap-10">
                        <div className="bg-white border-t-8 border-black p-0">
                            <div className="p-8 border-x border-black">
                                <h3 className="text-2xl font-black mb-8 border-b-2 border-zinc-100 pb-4">Most Read</h3>

                                {[
                                    { rank: '01', cat: 'ECONOMICS', title: 'Global shift towards Monospace fonts in High Finance.' },
                                    { rank: '02', cat: 'ARCHIVE', title: 'The Brutalist blue-prints of early Silicon Valley.' },
                                    { rank: '03', cat: 'EDITORIAL', title: 'Why the 12-column grid is a moral imperative.' },
                                    { rank: '04', cat: 'CULTURE', title: 'The return of the physical book and its digital shadow.' }
                                ].map((item, i) => (
                                    <div key={i} className="sidebar-item group cursor-pointer">
                                        <div className="flex justify-between items-start mb-2">
                                            <span className="mono text-[10px] text-zinc-400">{item.cat}</span>
                                            <span className="text-zinc-200 text-3xl font-black italic group-hover:text-[var(--accent)] transition-colors">{item.rank}</span>
                                        </div>
                                        <h4 className="text-xl leading-tight group-hover:underline">{item.title}</h4>
                                    </div>
                                ))}
                            </div>
                            <div className="bg-black text-white p-10">
                                <h4 className="text-2xl mb-4 italic text-white/90">The Weekly Edition</h4>
                                <p className="text-sm text-white/50 mb-8 leading-relaxed">
                                    Substantive analysis delivered once per week. No notifications. No dopamine loops. Just the weight of the word.
                                </p>
                                <div className="flex flex-col gap-3">
                                    <input type="text" placeholder="JOURNALIST@EMAIL.COM" className="bg-zinc-900 border border-zinc-800 p-4 font-sans text-[10px] tracking-widest text-white outline-none focus:border-zinc-500" />
                                    <button className="bg-[var(--accent)] p-4 font-sans font-black text-[11px] tracking-widest hover:bg-white hover:text-black transition-colors">SUBSCRIBE NOW</button>
                                </div>
                            </div>
                        </div>

                        {/* Visual Asset Section */}
                        <div className="border border-zinc-200 p-2">
                            <div className="aspect-[4/5] bg-zinc-100 p-12 flex flex-col justify-end relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-t from-zinc-200 to-transparent opacity-50" />
                                <div className="relative z-10">
                                    <span className="kicker !text-[#888]">Visual Theory</span>
                                    <h4 className="text-3xl italic">The Geometry of Truth.</h4>
                                </div>
                                <div className="absolute top-8 right-8 border border-zinc-300 p-2 rounded-full group-hover:rotate-45 transition-transform duration-700">
                                    <ArrowRight className="-rotate-45" size={20} />
                                </div>
                            </div>
                        </div>
                    </aside>
                </main>

                {/* Horizontal Section - Visual Divider */}
                <div className="my-24 py-12 border-y-4 border-black grid grid-cols-1 md:grid-cols-4 gap-12 bg-white">
                    {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="flex flex-col gap-4 px-6 md:px-0 md:border-r border-zinc-100 last:border-0">
                            <span className="kicker !text-zinc-300">Section_C{i}</span>
                            <h4 className="text-2xl italic leading-none">The Precision of the Mathematical Line.</h4>
                            <p className="text-sm mb-0">How 20th century editorial rules define today's luxury web-sites.</p>
                        </div>
                    ))}
                </div>

                {/* Footer Section */}
                <footer className="mt-40 pt-20 border-t-8 border-black">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-20">
                        <div className="col-span-1 md:col-span-2">
                            <h2 className="text-5xl font-black italic mb-8 underline decoration-8 underline-offset-8">THE BROADSHEET.</h2>
                            <p className="max-w-md italic text-zinc-500">
                                Dedicated to the preservation of high-density editorial standards. A product of the MNML_SYS creative laboratory.
                            </p>
                        </div>
                        <div className="flex flex-col gap-6 font-sans font-black text-[11px] tracking-widest uppercase">
                            <h5 className="text-zinc-300">EDITIONS</h5>
                            <a href="#" className="hover:text-[var(--accent)]">Daily Digital</a>
                            <a href="#" className="hover:text-[var(--accent)]">Weekly Physical</a>
                            <a href="#" className="hover:text-[var(--accent)]">The Archive</a>
                            <a href="#" className="hover:text-[var(--accent)]">Limited Prints</a>
                        </div>
                        <div className="flex flex-col gap-6 font-sans font-black text-[11px] tracking-widest uppercase">
                            <h5 className="text-zinc-300">SOCIAL NODES</h5>
                            <a href="#" className="hover:text-[var(--accent)]">Instagram</a>
                            <a href="#" className="hover:text-[var(--accent)]">Twitter / X</a>
                            <a href="#" className="hover:text-[var(--accent)]">LinkedIn</a>
                            <a href="#" className="hover:text-[var(--accent)]">RSS Feed</a>
                        </div>
                    </div>
                    <div className="mt-40 flex justify-between items-center py-12 border-t border-zinc-200 mono text-[9px] text-zinc-400">
                        <div>© 1924-2024 THE BROADSHEET PUBLISHING GROUP. ALL RIGHTS RESERVED.</div>
                        <div className="flex gap-12">
                            <span>PLATFORM_V_12.8.4</span>
                            <span>DESIGNED_BY_JULIAN_S_VANE</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    )
}
