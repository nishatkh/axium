import React, { useEffect } from 'react'
import { ArrowRight, Grid3X3, ArrowDownRight, Square, Circle, Triangle, Layers, Plus } from 'lucide-react'

export default function Swiss() {
    useEffect(() => {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }, []);

    return (
        <div className="swiss-root bg-[#FFFFFF] text-[#000000] min-h-screen font-sans selection:bg-[#FF0000] selection:text-white" style={{ fontFamily: '"Inter", Helvetica, Arial, sans-serif' }}>
            <style>{`
                .swiss-root {
                    --grid-unit: 80px;
                    --gray: #F2F2F2;
                    --accent: #FF0000;
                }
                .swiss-root h1, .swiss-root h2, .swiss-root h3 {
                    font-weight: 900;
                    letter-spacing: -0.06em;
                    line-height: 0.8;
                    text-transform: uppercase;
                }
                .swiss-root .mono {
                    font-family: "JetBrains Mono", monospace;
                    text-transform: uppercase;
                    font-size: 10px;
                    letter-spacing: 0.1em;
                    font-weight: 500;
                }
                .swiss-root .btn-swiss {
                    background: #000;
                    color: #fff;
                    padding: 1.25rem 2.5rem;
                    text-transform: uppercase;
                    font-size: 12px;
                    font-weight: 900;
                    letter-spacing: 0.1em;
                    border: none;
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 12px;
                    transition: all 0.3s ease;
                }
                .swiss-root .btn-swiss:hover {
                    background: var(--accent);
                    padding-right: 3.5rem;
                }
                .swiss-root .rule {
                    border-top: 1px solid #000;
                    width: 100%;
                }
                .swiss-root .rule-heavy {
                    border-top: 10px solid #000;
                    width: 100%;
                }
                @keyframes slideIn {
                    from { transform: translateX(-100px); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                .swiss-root .animate-slide {
                    animation: slideIn 1s cubic-bezier(0.16, 1, 0.3, 1) both;
                }
            `}</style>

            {/* Structured Grid Layout Overlay (Background) */}
            <div className="fixed inset-0 pointer-events-none opacity-[0.03] z-0 grid grid-cols-6 md:grid-cols-12 gap-0 divide-x divide-black">
                {Array.from({ length: 12 }).map((_, i) => <div key={i} />)}
            </div>

            {/* Header / Nav */}
            <header className="relative z-10 p-12 md:p-20 flex justify-between items-start border-b-[20px] border-black">
                <div className="animate-slide">
                    <div className="text-4xl font-black tracking-tighter mb-4">MUSEUM_OF_SYSTEM.</div>
                    <div className="mono opacity-40">ZURICH / BASEL / 1954 - 2024</div>
                </div>
                <div className="hidden md:flex flex-col gap-6 text-right mono font-black">
                    <a href="#" className="hover:text-[var(--accent)] underline decoration-2 underline-offset-4 decoration-white hover:decoration-[var(--accent)] transition-all">OBJECTS_01</a>
                    <a href="#" className="hover:text-[var(--accent)]">THE_GRID_02</a>
                    <a href="#" className="hover:text-[var(--accent)]">ARCHIVE_03</a>
                    <a href="#" className="hover:text-[var(--accent)]">DIRECTIVE_04</a>
                </div>
                <div className="md:hidden">
                    <Plus size={32} />
                </div>
            </header>

            {/* Hero Section */}
            <section className="relative z-10 grid grid-cols-1 md:grid-cols-12 items-end">
                <div className="md:col-span-8 p-12 md:p-20 border-r-0 md:border-r-[10px] border-black min-h-[60vh] flex flex-col justify-end">
                    <h1 className="text-[16vw] md:text-[12vw] leading-[0.75] mb-12">
                        THE<br />OBJECTIVE<br />STRUCTURE.
                    </h1>
                    <div className="flex flex-col md:flex-row gap-12 items-start mt-12">
                        <button className="btn-swiss">Register Method</button>
                        <div className="max-w-[280px] text-xs font-bold leading-relaxed uppercase">
                            Architecture should not be a means of expression; it should facilitate the emergence of meaning.
                        </div>
                    </div>
                </div>
                <div className="md:col-span-4 p-12 md:p-20 flex flex-col justify-between min-h-[60vh] bg-black text-white">
                    <div className="mono text-white/40">Section 08 / Mathematical Order</div>
                    <div className="text-[10rem] font-black leading-none italic opacity-20">08.</div>
                    <div className="flex flex-col gap-8">
                        <p className="text-xl font-bold leading-tight">THE GRID IS NOT A CAGE. IT IS A LANGUAGE OF FREEDOM THROUGH CONSTRAINT.</p>
                        <ArrowDownRight size={48} className="text-[var(--accent)]" />
                    </div>
                </div>
            </section>

            {/* Visual Discipline Catalog */}
            <section className="relative z-10 grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x-[10px] divide-black border-y-[10px] border-black">
                <div className="p-12 md:p-20 flex flex-col gap-12 group cursor-pointer hover:bg-zinc-50 transition-colors">
                    <div className="flex justify-between items-start">
                        <div className="w-16 h-16 bg-black flex items-center justify-center text-white font-black text-3xl transition-all group-hover:bg-[#FF0000]">01.</div>
                        <Square className="opacity-10 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div>
                        <h2 className="text-5xl mb-6 italic">TYPOGRAPHY.</h2>
                        <p className="text-sm font-medium leading-relaxed opacity-60">Objective sans-serif typefaces eliminate personal bias and focus on the direct transmission of information.</p>
                    </div>
                </div>

                <div className="p-12 md:p-20 flex flex-col gap-12 group cursor-pointer bg-[#FF0000] text-white overflow-hidden relative">
                    <div className="absolute top-0 right-0 p-12 opacity-10">
                        <Circle size={200} fill="white" />
                    </div>
                    <div className="relative z-10 flex flex-col h-full">
                        <div className="flex justify-between items-start mb-12">
                            <div className="mono text-white/50">Node_Ref_02</div>
                            <Plus size={32} className="rotate-45" />
                        </div>
                        <h2 className="text-5xl mb-6 italic mt-auto">HIERARCHY.</h2>
                        <p className="text-sm font-bold leading-relaxed">Systematic organization of visual weight ensures the observer is guided with absolute precision through the data-scape.</p>
                    </div>
                </div>

                <div className="p-12 md:p-20 flex flex-col gap-12 group cursor-pointer hover:bg-zinc-50 transition-colors">
                    <div className="flex justify-between items-start">
                        <div className="w-16 h-16 bg-black flex items-center justify-center text-white font-bold text-3xl transition-all group-hover:bg-[#FF0000]">03.</div>
                        <Triangle className="opacity-10 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div>
                        <h2 className="text-5xl mb-6 italic">THE GRID.</h2>
                        <p className="text-sm font-medium leading-relaxed opacity-60">Mathematical division of the surface area creates a rhythmic skeleton for all communicative components.</p>
                    </div>
                </div>
            </section>

            {/* Full Width Technical Illustration */}
            <section className="relative z-10 py-40 px-12 md:px-20 bg-white overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
                    <div className="md:col-span-5">
                        <div className="mono text-zinc-300 mb-8 tracking-[0.4em]">REGISTRATION_MARKS</div>
                        <h2 className="text-7xl md:text-9xl mb-12 leading-[0.8]">GRID<br />AS<br />TRUTH.</h2>
                        <button className="btn-swiss group">
                            <span>Examine Standards</span>
                            <ArrowRight size={18} className="group-hover:translate-x-4 transition-transform" />
                        </button>
                    </div>
                    <div className="md:col-span-7 relative">
                        {/* Abstract Grid Visual */}
                        <div className="aspect-video bg-zinc-50 border-[1px] border-black/10 flex items-center justify-center overflow-hidden">
                            <div className="w-full h-full grid grid-cols-10 grid-rows-10 divide-x divide-y divide-black/5">
                                {Array.from({ length: 100 }).map((_, i) => (
                                    <div key={i} className="flex items-center justify-center font-mono text-[8px] opacity-10 uppercase">
                                        node_{i}
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="absolute -top-12 -right-12 w-64 h-64 bg-[#FF0000] -z-10 animate-slide" />
                    </div>
                </div>
            </section>

            {/* Bottom Content / Catalog */}
            <section className="relative z-10 p-12 md:p-20 border-t-[10px] border-black">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-20">
                    {[
                        { title: 'GEOMETRY', desc: 'The fundamental primitives of the visual universe.' },
                        { title: 'ACCURACY', desc: 'Zero tolerance for decorative abstraction.' },
                        { title: 'RHYTHM', desc: 'Structured repetition of elements creates harmony.' },
                        { title: 'CLARITY', desc: 'The ultimate purpose of the designer is transparency.' }
                    ].map((item, i) => (
                        <div key={i} className="flex flex-col gap-6">
                            <div className="h-2 bg-black w-full" />
                            <h3 className="text-3xl italic">{item.title}</h3>
                            <p className="text-xs font-bold opacity-40 uppercase leading-loose">{item.desc}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Footer */}
            <footer className="relative z-10 bg-black text-white p-12 md:p-40">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-20 items-start">
                    <div className="md:col-span-8">
                        <div className="text-[10vw] font-black italic tracking-tighter leading-none mb-12">SYSTEMATIC.</div>
                        <p className="max-w-2xl text-xl font-light leading-relaxed text-zinc-400">
                            THE SWISS INTERNATIONAL TYPOGRAPHIC STYLE WAS NOT DEVISED AS AN AESTHETIC GENRE,
                            BUT AS A SCIENTIFIC RESPONSE TO THE COMPLEXITY OF MODERN INFORMATION.
                            WE PRESERVE THIS DISCIPLINE FOR THE DIGITAL ARCHIVE.
                        </p>
                    </div>
                    <div className="md:col-span-4 flex flex-col gap-12 mono text-xs">
                        <div className="flex flex-col gap-4">
                            <h4 className="text-white/30 tracking-[0.4em]">NODES_INDEX</h4>
                            <a href="#" className="hover:text-[var(--accent)] underline decoration-[var(--accent)]">[ ZURICH_CENTRE ]</a>
                            <a href="#" className="hover:text-[var(--accent)] underline decoration-[var(--accent)]">[ BASEL_DEPOT ]</a>
                            <a href="#" className="hover:text-[var(--accent)] underline decoration-[var(--accent)]">[ GENEVA_GATE ]</a>
                        </div>
                        <div className="flex flex-col gap-4 mt-12">
                            <h4 className="text-white/30 tracking-[0.4em]">PROTOCOL_VER</h4>
                            <div>VER_1.4.0_REV_6</div>
                            <div>AUTH: MNML_SYS</div>
                        </div>
                    </div>
                </div>
                <div className="mt-40 pt-12 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-12 mono text-[10px] opacity-30">
                    <div>© 1954-2024 INSTITUT FÜR SYSTEMATISCHE GESTALTUNG. ALL RIGHTS RESERVED.</div>
                    <div className="flex gap-12">
                        <div className="flex gap-3">
                            <Square size={10} fill="white" />
                            <Circle size={10} fill="white" />
                            <Triangle size={10} fill="white" />
                        </div>
                        <span>MADE_IN_SWITZERLAND</span>
                    </div>
                </div>
            </footer>
        </div>
    )
}
