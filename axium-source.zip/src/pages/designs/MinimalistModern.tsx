import React, { useEffect } from 'react'
import { ArrowRight, Box, Check, Cpu, Globe, Layout, MessageSquare, Zap, Play, Github, Twitter, Layers } from 'lucide-react'

export default function MinimalistModern() {
    useEffect(() => {
        const link = document.createElement('link');
        link.href = 'https://fonts.googleapis.com/css2?family=Calistoga&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }, []);

    return (
        <div className="modern-root bg-[#FAFAFA] text-[#0F172A] min-h-screen font-sans selection:bg-[#0052FF]/20 overflow-x-hidden" style={{ fontFamily: '"Inter", sans-serif' }}>
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=Calistoga&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

                .modern-root {
                    --bg: #FAFAFA;
                    --fg: #0F172A;
                    --accent: #0052FF;
                    --accent-light: #4D7CFF;
                    --muted: #F1F5F9;
                    --muted-fg: #64748B;
                }

                .modern-root h1, .modern-root h2, .modern-root h3, .modern-root .serif {
                    font-family: 'Calistoga', serif;
                    line-height: 1.15;
                }

                .modern-root .mono {
                    font-family: 'JetBrains Mono', monospace;
                }

                /* Gradient Text */
                .modern-root .gradient-text {
                    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-light) 100%);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }

                /* Pulse Dot */
                .modern-root .pulse-dot {
                    width: 6px;
                    height: 6px;
                    background-color: var(--accent);
                    border-radius: 50%;
                    position: relative;
                }

                .modern-root .pulse-dot::after {
                    content: "";
                    position: absolute;
                    top: -4px;
                    left: -4px;
                    right: -4px;
                    bottom: -4px;
                    border: 1px solid var(--accent);
                    border-radius: 50%;
                    animation: pulse 2s cubic-bezier(0, 0.45, 0.45, 1) infinite;
                }

                @keyframes pulse {
                    0% { transform: scale(0.5); opacity: 1; }
                    100% { transform: scale(2.5); opacity: 0; }
                }

                /* Floating Animation */
                .modern-root .float-anim {
                    animation: float 5s ease-in-out infinite;
                }

                @keyframes float {
                    0%, 100% { transform: translateY(0); }
                    50% { transform: translateY(-20px); }
                }

                /* Gradient Border */
                .modern-root .gradient-border {
                    position: relative;
                    background: white;
                    border-radius: 1rem;
                }

                .modern-root .gradient-border::before {
                    content: "";
                    position: absolute;
                    inset: -2px;
                    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-light) 100%);
                    z-index: -1;
                    border-radius: 1.1rem;
                }

                /* Ghost Grid */
                .modern-root .ghost-grid {
                    background-image: radial-gradient(#E2E8F0 1px, transparent 1px);
                    background-size: 32px 32px;
                }

                /* Custom Button */
                .modern-root .btn-modern {
                    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-light) 100%);
                    color: white;
                    padding: 1rem 2rem;
                    border-radius: 0.75rem;
                    font-weight: 600;
                    display: inline-flex;
                    align-items: center;
                    gap: 12px;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
                    box-shadow: 0 4px 14px rgba(0, 82, 255, 0.25);
                }

                .modern-root .btn-modern:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 8px 20px rgba(0, 82, 255, 0.35);
                }
            `}</style>

            {/* Navbar */}
            <nav className="fixed top-0 left-0 right-0 z-50 px-8 py-6 flex justify-between items-center bg-[#FAFAFA]/80 backdrop-blur-md border-b border-slate-200">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-[#0052FF] to-[#4D7CFF] rounded-xl flex items-center justify-center text-white shadow-lg">
                        <Zap size={20} fill="currentColor" />
                    </div>
                    <span className="text-xl font-bold tracking-tight serif">Streamline</span>
                </div>

                <div className="hidden md:flex items-center gap-10 text-sm font-medium text-slate-500">
                    <a href="#" className="hover:text-[#0052FF] transition-colors">Product</a>
                    <a href="#" className="hover:text-[#0052FF] transition-colors">Ecosystem</a>
                    <a href="#" className="hover:text-[#0052FF] transition-colors">Enterprise</a>
                    <a href="#" className="hover:text-[#0052FF] transition-colors">Pricing</a>
                </div>

                <div className="flex items-center gap-6">
                    <button className="text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors">Sign in</button>
                    <button className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-slate-800 transition-all">Get Started</button>
                </div>
            </nav>

            {/* Hero Section */}
            <section className="pt-40 pb-32 px-8 overflow-hidden relative">
                <div className="ghost-grid absolute inset-0 opacity-40 -z-10"></div>

                <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-20">
                    <div className="md:w-1/2 relative z-10">
                        <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full border border-slate-200 bg-white shadow-sm mb-10">
                            <div className="pulse-dot"></div>
                            <span className="mono text-[10px] uppercase tracking-[0.15em] font-bold text-slate-500">v2.0 Now Platform Ready</span>
                        </div>

                        <h1 className="text-6xl md:text-8xl mb-8 serif tracking-tight">
                            Build with <br />
                            <span className="gradient-text italic">Momentum.</span>
                        </h1>

                        <p className="text-lg md:text-xl text-slate-500 max-w-lg mb-12 leading-relaxed">
                            A high-fidelity design system for scaling modern interfaces. Minimalist structure meets maximalist confidence in every interaction.
                        </p>

                        <div className="flex flex-col sm:flex-row items-center gap-6">
                            <button className="btn-modern w-full sm:w-auto">
                                Start Deploying
                                <ArrowRight size={18} />
                            </button>
                            <button className="flex items-center gap-3 font-semibold text-slate-600 hover:text-slate-900 transition-colors group">
                                <span className="w-10 h-10 rounded-full border border-slate-200 flex items-center justify-center group-hover:border-[#0052FF] transition-colors">
                                    <Play size={14} fill="currentColor" className="ml-0.5" />
                                </span>
                                View Demo
                            </button>
                        </div>
                    </div>

                    <div className="md:w-1/2 relative">
                        {/* Abstract Hero Graphic */}
                        <div className="relative w-full aspect-square flex items-center justify-center">
                            <div className="absolute inset-0 bg-gradient-to-br from-[#0052FF]/10 to-[#4D7CFF]/5 rounded-[4rem] blur-3xl -z-10"></div>

                            <div className="float-anim w-full h-full relative flex items-center justify-center">
                                {/* Geometric Blobs */}
                                <div className="absolute top-0 right-0 w-64 h-64 bg-slate-900 rounded-[3rem] rotate-12 flex items-center justify-center shadow-2xl p-10 overflow-hidden group">
                                    <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[#0052FF]/20 to-transparent"></div>
                                    <Cpu size={120} className="text-white/20 group-hover:scale-110 transition-transform duration-700" strokeWidth={1} />
                                    <div className="absolute top-6 left-6 flex gap-2">
                                        <div className="w-12 h-1 bg-white/20 rounded-full"></div>
                                        <div className="w-6 h-1 bg-white/20 rounded-full"></div>
                                    </div>
                                </div>

                                <div className="absolute bottom-10 left-0 w-80 h-48 bg-white rounded-3xl shadow-xl p-8 border border-slate-100 float-anim [animation-delay:-2.5s]">
                                    <div className="flex items-center gap-4 mb-6">
                                        <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center text-[#0052FF]">
                                            <Globe size={24} />
                                        </div>
                                        <div>
                                            <div className="text-sm font-bold">Latency Optimization</div>
                                            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Active nodes</div>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        {Array.from({ length: 12 }).map((_, i) => (
                                            <div key={i} className={`h-2 rounded-full flex-1 ${i < 8 ? 'bg-[#0052FF]' : 'bg-slate-100'}`}></div>
                                        ))}
                                    </div>
                                </div>

                                {/* Floating Orb */}
                                <div className="absolute top-20 left-20 w-16 h-16 bg-[#0052FF] rounded-full shadow-[0_0_40px_rgba(0,82,255,0.4)] flex items-center justify-center text-white float-anim [animation-delay:-1s]">
                                    <Zap size={20} fill="currentColor" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section className="py-32 px-8 bg-slate-900 text-white relative overflow-hidden">
                <div className="ghost-grid absolute inset-0 opacity-[0.03] -z-0"></div>
                <div className="absolute top-0 right-0 w-96 h-96 bg-[#0052FF]/20 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2"></div>

                <div className="max-w-7xl mx-auto relative z-10">
                    <div className="text-center mb-24">
                        <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full border border-white/10 bg-white/5 mb-8">
                            <span className="mono text-[10px] uppercase tracking-[0.15em] font-bold text-[#4D7CFF]">Engineered for Performance</span>
                        </div>
                        <h2 className="text-5xl md:text-7xl serif tracking-tight mb-8">
                            Precision meets <br />
                            <span className="gradient-text italic">Confidence.</span>
                        </h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                        {[
                            { icon: <Layout />, title: 'Structural Clarity', desc: 'Pre-defined patterns that prioritize hierarchy and visual flow across any device density.' },
                            { icon: <Box />, title: 'Atomic Foundations', desc: 'Every component is built on a rigid atomic system, ensuring perfect synchronization.' },
                            { icon: <MessageSquare />, title: 'Dynamic Interaction', desc: 'Buttery-smooth animations and meaningful micro-interactions that communicate state.' }
                        ].map((feature, i) => (
                            <div key={i} className="p-10 rounded-[2rem] bg-white/5 border border-white/10 hover:bg-white/[0.08] transition-all group overflow-hidden relative">
                                <div className="absolute -bottom-10 -right-10 text-white/5 group-hover:text-[#0052FF]/20 group-hover:scale-125 transition-all duration-700 pointer-events-none">
                                    {React.cloneElement(feature.icon as React.ReactElement<{ size?: number }>, { size: 160 })}
                                </div>
                                <div className="w-14 h-14 rounded-2xl bg-[#0052FF] flex items-center justify-center mb-8 shadow-lg shadow-[#0052FF]/20">
                                    {React.cloneElement(feature.icon as React.ReactElement<{ size?: number }>, { size: 24 })}
                                </div>
                                <h3 className="text-2xl font-bold mb-4 serif tracking-tight group-hover:gradient-text transition-all">{feature.title}</h3>
                                <p className="text-slate-400 leading-relaxed">{feature.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Showcase Section */}
            <section className="py-44 px-8">
                <div className="max-w-7xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-32 items-center">
                        <div>
                            <div className="w-16 h-1 bg-[#0052FF] mb-12"></div>
                            <h2 className="text-5xl md:text-6xl serif mb-10 leading-tight">
                                Design that feels <br />
                                <span className="italic">as good</span> as it looks.
                            </h2>
                            <p className="text-lg text-slate-500 mb-12 leading-relaxed">
                                We've obsessed over the details so you don't have to. From the exact weight of our focus rings to the acceleration curves of our drawer reveals.
                            </p>

                            <div className="space-y-6">
                                {['Ultra-low bundle footprint', 'Accessible-first primitives', 'Developer-experience priority'].map((item, i) => (
                                    <div key={i} className="flex items-center gap-4 text-slate-700 font-semibold italic">
                                        <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center text-[#0052FF]">
                                            <Check size={14} />
                                        </div>
                                        {item}
                                    </div>
                                ))}
                            </div>

                            <button className="mt-16 text-[#0052FF] font-bold tracking-widest uppercase text-xs flex items-center gap-3 group">
                                View Full Archive
                                <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
                            </button>
                        </div>

                        <div className="relative">
                            <div className="gradient-border p-1">
                                <div className="rounded-[0.9rem] overflow-hidden bg-slate-100 aspect-square relative group">
                                    <img
                                        src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=1200"
                                        alt="Modern Code"
                                        className="w-full h-full object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000"
                                    />
                                    <div className="absolute inset-0 flex items-center justify-center bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-[#0052FF] shadow-2xl scale-75 group-hover:scale-100 transition-transform">
                                            <Play size={24} fill="currentColor" className="ml-1" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Accent Radiant */}
                            <div className="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-br from-[#0052FF] to-[#4D7CFF] rounded-[2rem] -z-10 group-hover:rotate-12 transition-transform duration-1000"></div>
                        </div>
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-32 px-8">
                <div className="max-w-5xl mx-auto text-center px-10 py-24 rounded-[3rem] bg-gradient-to-br from-slate-900 to-slate-800 text-white relative overflow-hidden">
                    <div className="ghost-grid absolute inset-0 opacity-[0.03] -z-0"></div>
                    <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-[#0052FF]/30 blur-[100px] rounded-full"></div>

                    <div className="relative z-10">
                        <h2 className="text-5xl md:text-7xl serif mb-8 tracking-tight">Ready for a upgrade?</h2>
                        <p className="text-slate-400 max-w-xl mx-auto mb-14 text-lg">
                            Join over 2,000+ engineers building the tomorrow's most characterful interfaces.
                        </p>
                        <div className="flex flex-col sm:flex-row justify-center items-center gap-6">
                            <button className="btn-modern px-10">Download Framework</button>
                            <button className="bg-white/10 hover:bg-white/20 text-white px-10 py-4 rounded-xl font-semibold transition-all">Schedule Demo</button>
                        </div>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="pt-32 pb-12 px-8 border-t border-slate-200">
                <div className="max-w-7xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-20 mb-32">
                        <div className="md:col-span-4">
                            <div className="flex items-center gap-3 mb-8">
                                <div className="w-10 h-10 bg-gradient-to-br from-[#0052FF] to-[#4D7CFF] rounded-xl flex items-center justify-center text-white">
                                    <Zap size={20} fill="currentColor" />
                                </div>
                                <span className="text-xl font-bold tracking-tight serif">Streamline</span>
                            </div>
                            <p className="text-slate-500 max-w-xs mb-10 leading-relaxed">
                                The ultimate design system for modern engineering teams who value clarity, confidence, and character.
                            </p>
                            <div className="flex gap-6 text-slate-400">
                                <a href="#" className="hover:text-[#0052FF] transition-colors"><Twitter size={20} /></a>
                                <a href="https://github.com/nishatkh/axium.git" target="_blank" rel="noreferrer" className="hover:text-[#0052FF] transition-colors"><Github size={20} /></a>
                                <a href="#" className="hover:text-[#0052FF] transition-colors"><Layers size={20} /></a>
                            </div>
                        </div>

                        {[
                            { title: 'Product', links: ['Features', 'API Design', 'Security', 'Enterprise'] },
                            { title: 'Resources', links: ['Documentation', 'Guides', 'Community', 'Academy'] },
                            { title: 'Company', links: ['Our Story', 'Careers', 'Changelog', 'Support'] }
                        ].map((column, i) => (
                            <div key={i} className="md:col-span-2">
                                <h4 className="font-bold serif text-lg mb-8 tracking-tight">{column.title}</h4>
                                <ul className="space-y-4">
                                    {column.links.map((link, j) => (
                                        <li key={j}>
                                            <a href="#" className="text-slate-500 hover:text-[#0052FF] transition-colors font-medium">{link}</a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>

                    <div className="pt-12 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6 text-sm font-medium text-slate-400">
                        <p>© 2024 Streamline Inc. Built with absolute confidence.</p>
                        <div className="flex gap-10">
                            <a href="#" className="hover:text-slate-900 transition-colors">Privacy</a>
                            <a href="#" className="hover:text-slate-900 transition-colors">Terms</a>
                            <a href="#" className="hover:text-slate-900 transition-colors">Cookies</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    )
}
