import React, { lazy, Suspense, useEffect, Component, type ReactNode } from 'react'
import { useLocation } from 'react-router-dom'
import COMPONENT_PROMPTS from '../data/prompts'
import DemoSection from '../components/DemoSection'
import Sidebar from '../components/Sidebar'
import '../components/UIPreviews.css'
import './DetailPage.css'

// Lazy load all previews
const DockPreview = lazy(() => import('../components/UI/DockPreview'))
const NotificationPreview = lazy(() => import('../components/UI/NotificationPreview'))
const FolderPreview = lazy(() => import('../components/UI/FolderPreview'))
const NavPreview = lazy(() => import('../components/UI/NavPreview'))
const LensPreview = lazy(() => import('../components/UI/LensPreview'))
const TimelinePreview = lazy(() => import('../components/UI/TimelinePreview'))
const MarqueePreview = lazy(() => import('../components/UI/MarqueePreview'))
const RevealPreview = lazy(() => import('../components/UI/RevealPreview'))
const TestimonialsPreview = lazy(() => import('../components/UI/TestimonialsPreview'));
const ImagesBadgeDemo = lazy(() => import('../components/UI/ImagesBadgeDemo'));
const ExpandableCardDemo = lazy(() => import('../components/UI/expandable-card-demo-standard'));

const DEMOS = [
    { id: 'dock', title: 'Liquid Dock', desc: 'macOS-style liquid glass dock with dynamic magnification and physics.' },
    { id: 'notification', title: 'Animated Notification', desc: 'Stackable toast notifications with spring physics and glassmorphism.' },
    { id: 'nav', title: 'Dynamic Navigation', desc: 'Pill-shaped segmented control with sliding active background.' },
    { id: 'folder', title: 'Glass Folder', desc: '3D perspective hover folder with layered translucent panels.' },
    { id: 'lens', title: 'Magnifying Lens', desc: 'Cursor-following spotlight lens that reveals hidden content via masking.' },
    { id: 'timeline', title: 'Scroll Timeline', desc: 'Vertical path with scroll progress indicator and staggered reveals.' },
    { id: 'marquee', title: 'Sliding Marquee', desc: 'Infinite horizontal scrolling container for logos with blurred edges.' },
    { id: 'reveal', title: 'Image Reveal', desc: 'Hover-triggered following image preview pinned to cursor.' },
    { id: 'testimonials', title: 'Animated Testimonials', desc: 'Stacked image cards with rotation, word-by-word blur quote reveal, and prev/next navigation.' },
    { id: 'images-badge', title: 'Images Badge', desc: 'Interactive visual badge showing a fan-out image preview via physics-based animation.' },
    { id: 'expandable-card', title: 'Expandable Card', desc: 'Interactive grid of cards that expand to show full content with seamless origin animations and useOutsideClick.' }
]

const PreviewLoader = () => (
    <div className="uip-preview uip-preview--loading">
        <div className="uip-preview__spinner" />
    </div>
)

class ErrorBoundary extends Component<{ children: ReactNode, id: string }, { hasError: boolean }> {
    constructor(props: { children: ReactNode, id: string }) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError() {
        return { hasError: true };
    }

    componentDidCatch(error: any, errorInfo: any) {
        console.error(`Error in component ${this.props.id}:`, error, errorInfo);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div className="uip-preview flex flex-col items-center justify-center p-8 text-center bg-red-500/5 border border-red-500/20 rounded-2xl">
                    <div className="w-12 h-12 rounded-full bg-red-500/10 flex items-center justify-center mb-4">
                        <span className="text-red-500 text-2xl">!</span>
                    </div>
                    <h3 className="text-lg font-bold text-red-500 mb-2">Preview Crashed</h3>
                    <p className="text-sm text-neutral-500 max-w-xs"> This component encountered an error during rendering. Check the console for details. </p>
                    <button
                        onClick={() => this.setState({ hasError: false })}
                        className="mt-6 px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold rounded-full transition-colors"
                    >
                        Retry Preview
                    </button>
                </div>
            );
        }

        return this.props.children;
    }
}

function UIPreview({ id }: { id: string }) {
    return (
        <ErrorBoundary id={id}>
            <Suspense fallback={<PreviewLoader />}>
                {(() => {
                    switch (id) {
                        case 'dock': return <DockPreview />
                        case 'notification': return <NotificationPreview />
                        case 'nav': return <NavPreview />
                        case 'folder': return <FolderPreview />
                        case 'lens': return <LensPreview />
                        case 'timeline': return <TimelinePreview />
                        case 'marquee': return <MarqueePreview />
                        case 'reveal': return <RevealPreview />
                        case 'testimonials': return <TestimonialsPreview />
                        case 'images-badge': return <ImagesBadgeDemo />
                        case 'expandable-card': return <ExpandableCardDemo />
                        default: return <div className="uip-preview uip-preview--placeholder"><span className="uip-preview__label">{id.toUpperCase()}</span></div>
                    }
                })()}
            </Suspense>
        </ErrorBoundary>
    )
}

export default function UIComponents() {
    const location = useLocation()

    useEffect(() => {
        if (location.hash) {
            const el = document.getElementById(location.hash.slice(1))
            if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
        }
    }, [location])

    return (
        <div className="detail">
            <Sidebar items={DEMOS.map(d => ({ id: d.id, label: d.title }))} />
            <main className="detail__main">
                <div className="detail__inner">
                    <header className="detail__header fade-up">
                        <h1 className="detail__title">UI Components</h1>
                        <p className="detail__desc">Premium, accessible, high-performance UI components with AI-ready prompts.</p>
                    </header>
                    {DEMOS.map(demo => (
                        <DemoSection key={demo.id} id={demo.id} title={demo.title} description={demo.desc} prompt={COMPONENT_PROMPTS[demo.id] || ''}>
                            <UIPreview id={demo.id} />
                        </DemoSection>
                    ))}
                </div>
            </main>
        </div>
    )
}
