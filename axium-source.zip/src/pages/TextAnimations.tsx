import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import COMPONENT_PROMPTS from '../data/prompts'
import DemoSection from '../components/DemoSection'
import Sidebar from '../components/Sidebar'
import {
    ScrollRevealPreview, ShinyTextPreview, TextMarqueePreview,
    TypingTextPreview, CanvasTextPreview, EncryptedTextPreview,
    LayoutTextFlipPreview, FlipWordsPreview, TextHoverEffectPreview,
    ContainerTextFlipPreview, HeroHighlightPreview,
    TextRevealCardPreview, TypewriterEffectPreview
} from '../components/TextPreviews'
import './DetailPage.css'

const DEMOS = [
    { id: 'scrollreveal', title: 'Scroll Reveal', desc: 'Word-by-word staggered reveal with scroll-linked rotation and blur fade-in.' },
    { id: 'shinytext', title: 'Shiny Text', desc: 'Animated gradient shimmer with configurable direction and speed controls.' },
    { id: 'textmarquee', title: 'Text Scroll Marquee', desc: 'Scroll-velocity reactive infinite text loop with direction awareness.' },
    { id: 'typingtext', title: 'Typing Text', desc: 'Character-by-character typing animation with configurable delay and loop support.' },
    { id: 'canvastext', title: 'Canvas Text', desc: 'Canvas-drawn animated bezier curves behind transparent text with DPR-aware rendering.' },
    { id: 'encryptedtext', title: 'Encrypted Text', desc: 'Matrix-style character scramble that progressively reveals the target text.' },
    { id: 'layouttextflip', title: 'Layout Text Flip', desc: 'Cycling word display with AnimatePresence popLayout and blur transitions.' },
    { id: 'flipwords', title: 'Flip Words', desc: 'Spring-physics word cycling with per-letter staggered blur reveal.' },
    { id: 'texthovereffect', title: 'Text Hover Effect', desc: 'SVG stroke-draw animation with cursor-tracking gradient mask reveal.' },
    { id: 'containertextflip', title: 'Container Text Flip', desc: 'Auto-sizing container that animates width to fit cycling words.' },
    { id: 'herohighlight', title: 'Hero Highlight', desc: 'Mouse-tracking dot pattern with animated text highlight background reveal.' },
    { id: 'textrevealcard', title: 'Text Reveal Card', desc: 'Swipe-to-reveal text card with clip-path animation and star particles.' },
    { id: 'typewritereffect', title: 'Typewriter Effect', desc: 'Staggered character reveal with blinking cursor and smooth width expansion.' },
]

function TextPreview({ id }: { id: string }) {
    switch (id) {
        case 'scrollreveal': return <ScrollRevealPreview />
        case 'shinytext': return <ShinyTextPreview />
        case 'textmarquee': return <TextMarqueePreview />
        case 'typingtext': return <TypingTextPreview />
        case 'canvastext': return <CanvasTextPreview />
        case 'encryptedtext': return <EncryptedTextPreview />
        case 'layouttextflip': return <LayoutTextFlipPreview />
        case 'flipwords': return <FlipWordsPreview />
        case 'texthovereffect': return <TextHoverEffectPreview />
        case 'containertextflip': return <ContainerTextFlipPreview />
        case 'herohighlight': return <HeroHighlightPreview />
        case 'textrevealcard': return <TextRevealCardPreview />
        case 'typewritereffect': return <TypewriterEffectPreview />
        default: return <div className="txp-preview">{id.toUpperCase()}</div>
    }
}

export default function TextAnimations() {
    const location = useLocation()

    useEffect(() => {
        if (location.hash) {
            const el = document.getElementById(location.hash.slice(1))
            if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
        }
    }, [location])

    return (
        <div className="detail">
            <Sidebar items={DEMOS.map(d => ({ id: d.id, label: d.title }))} />
            <main className="detail__main">
                <div className="detail__inner">
                    <header className="detail__header fade-up">
                        <h1 className="detail__title">Text Animations</h1>
                        <p className="detail__desc">Premium, high-performance text animation components with AI-ready prompts.</p>
                    </header>
                    {DEMOS.map(demo => (
                        <DemoSection key={demo.id} id={demo.id} title={demo.title} description={demo.desc} prompt={COMPONENT_PROMPTS[demo.id] || ''}>
                            <TextPreview id={demo.id} />
                        </DemoSection>
                    ))}
                </div>
            </main>
        </div>
    )
}
