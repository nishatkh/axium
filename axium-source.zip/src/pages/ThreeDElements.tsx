import { lazy, Suspense, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import COMPONENT_PROMPTS from '../data/prompts'
import DemoSection from '../components/DemoSection'
import Sidebar from '../components/Sidebar'
import '../components/ThreeDPreviews.css'
import './DetailPage.css'

// Lazy load all previews
const RingPreview = lazy(() => import('../components/ThreeD/RingPreview'))
const CarouselPreview = lazy(() => import('../components/ThreeD/CarouselPreview'))
const GalleryPreview = lazy(() => import('../components/ThreeD/GalleryPreview'))
const MarqueePreview = lazy(() => import('../components/ThreeD/MarqueePreview'))
const ScrollTriggerPreview = lazy(() => import('../components/ThreeD/ScrollTriggerPreview'))
const SliderPreview = lazy(() => import('../components/ThreeD/SliderPreview'))
const AngledPreview = lazy(() => import('../components/ThreeD/AngledPreview'))
const BeamPreview = lazy(() => import('../components/ThreeD/BeamPreview'))

const DEMOS = [
    { id: 'ring', title: '3D Image Ring', desc: 'Draggable ring with parallax depth, inertia physics, and mobile responsiveness.' },
    { id: 'carousel', title: '3D Image Carousel', desc: 'Cascade slider with 3D positioning, autoplay, swipe gestures, and navigation arrows.' },
    { id: 'hovergallery', title: '3D Hover Gallery', desc: 'Perspective gallery with expand-on-hover, 3D depth transforms, keyboard navigation, and autoplay.' },
    { id: 'marquee', title: '3D Marquee', desc: 'Tilted image grid with infinite scrolling columns and hover effects.' },
    { id: 'scrolltrigger', title: 'Scroll Trigger', desc: 'Velocity-reactive horizontal marquee rows with scroll physics.' },
    { id: 'slider', title: '3D Slider', desc: 'Fanned card stack with wheel/drag-based navigation, 60fps animation loop.' },
    { id: 'beam', title: 'Beam Circle', desc: 'Orbital animation with configurable rings and pulsing center.' },
]

const PreviewLoader = () => (
    <div className="td-preview td-preview--loading">
        <div className="td-preview__spinner" />
    </div>
)

function ThreeDPreview({ id }: { id: string }) {
    return (
        <Suspense fallback={<PreviewLoader />}>
            {(() => {
                switch (id) {
                    case 'ring': return <RingPreview />
                    case 'carousel': return <CarouselPreview />
                    case 'hovergallery': return <GalleryPreview />
                    case 'marquee': return <MarqueePreview />
                    case 'scrolltrigger': return <ScrollTriggerPreview />
                    case 'slider': return <SliderPreview />
                    case 'beam': return <BeamPreview />
                    default: return <div className="td-preview td-preview--placeholder"><span className="td-preview__label">{id.toUpperCase()}</span></div>
                }
            })()}
        </Suspense>
    )
}

export default function ThreeDElements() {
    const location = useLocation()

    useEffect(() => {
        if (location.hash) {
            const el = document.getElementById(location.hash.slice(1))
            if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
        }
    }, [location])

    return (
        <div className="detail">
            <Sidebar items={DEMOS.map(d => ({ id: d.id, label: d.title }))} />
            <main className="detail__main">
                <div className="detail__inner">
                    <header className="detail__header fade-up">
                        <h1 className="detail__title">3D Elements</h1>
                        <p className="detail__desc">Interactive 3D components for premium interfaces. Each includes a full working AI prompt.</p>
                    </header>
                    {DEMOS.map(demo => (
                        <DemoSection key={demo.id} id={demo.id} title={demo.title} description={demo.desc} prompt={COMPONENT_PROMPTS[demo.id] || ''}>
                            <ThreeDPreview id={demo.id} />
                        </DemoSection>
                    ))}
                </div>
            </main>
        </div>
    )
}
