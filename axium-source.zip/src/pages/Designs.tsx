import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { designPrompts } from '../data/designPrompts'
import { Globe, ArrowLeft, Copy, ExternalLink, ChevronRight } from 'lucide-react'
import { ShineButton } from '../components/ShineButton'
import './Designs.css'

export default function Designs() {
    // Determine initial ID immediately to avoid blank iframe or gallery-in-gallery
    const getInitialId = () => {
        const hash = window.location.hash.slice(1)
        if (hash) return hash
        if (designPrompts.length > 0) {
            return designPrompts[0].title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
        }
        return ''
    }

    const [activeId, setActiveId] = useState(getInitialId())
    const [copied, setCopied] = useState(false)

    // Sync state if hash changes externally
    useEffect(() => {
        const handleHashChange = () => {
            const hash = window.location.hash.slice(1)
            if (hash && hash !== activeId) {
                setActiveId(hash)
            }
        }
        window.addEventListener('hashchange', handleHashChange)
        return () => window.removeEventListener('hashchange', handleHashChange)
    }, [activeId])

    const activeDesign = designPrompts.find(d =>
        d.title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') === activeId
    ) || designPrompts[0]

    const handleCopy = () => {
        navigator.clipboard.writeText(activeDesign.prompt)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
    }

    return (
        <div className="designs-gallery">
            {/* Sidebar */}
            <aside className="designs-sidebar">
                <div className="designs-sidebar__header">
                    <Link to="/" className="designs-sidebar__logo" style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: '4px' }}>
                        <div style={{ fontSize: '1.1rem', color: '#fff', lineHeight: 1 }}>Full Website UI</div>
                        <span style={{ fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.15em', fontWeight: 600 }}>using prompt</span>
                    </Link>
                    <p className="designs-sidebar__desc">
                        Drop these prompts into any AI assistant and ship beautiful, consistent interfaces in minutes.
                    </p>
                </div>

                <nav className="designs-sidebar__nav">
                    {designPrompts.map((design) => {
                        const id = design.title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
                        const isActive = activeId === id
                        return (
                            <button
                                key={id}
                                className={`designs-sidebar__item ${isActive ? 'is-active' : ''}`}
                                onClick={() => {
                                    setActiveId(id)
                                    window.location.hash = id
                                }}
                            >
                                <div className="designs-sidebar__icon" style={{ background: isActive ? 'rgba(167, 139, 250, 0.2)' : '' }}>
                                    <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-purple-400' : 'bg-zinc-700'}`}
                                        style={{ backgroundColor: isActive ? '#a78bfa' : '#3f3f46' }}
                                    />
                                </div>
                                <span className="designs-sidebar__label">{design.title}</span>
                            </button>
                        )
                    })}
                </nav>
            </aside>

            {/* Main Content */}
            <main className="designs-content">
                {/* Dashboard Bar */}
                <header className="designs-dashboard">
                    <div className="designs-dashboard__left">
                        <div className="designs-dashboard__visual" />
                        <div className="designs-dashboard__meta">
                            <h1 className="designs-dashboard__title">{activeDesign.title}</h1>
                            <p className="designs-dashboard__tagline">{activeDesign.description}</p>
                        </div>
                    </div>

                    <div className="designs-dashboard__actions">
                        <ShineButton
                            label={copied ? 'Copied!' : 'Get Prompt'}
                            onClick={handleCopy}
                            size="md"
                        />
                        <Link to={`/website-designs/${activeId}`} target="_blank" className="btn-open">
                            Open
                            <ExternalLink size={16} />
                        </Link>
                    </div>
                </header>

                {/* Viewport */}
                <div className="designs-viewport">
                    <div className="browser-frame">
                        <div className="browser-frame__header">
                            <div className="browser-frame__dots">
                                <div className="browser-frame__dot browser-frame__dot--red" />
                                <div className="browser-frame__dot browser-frame__dot--yellow" />
                                <div className="browser-frame__dot browser-frame__dot--green" />
                            </div>
                            <div className="browser-frame__address">
                                <Globe size={14} />
                                designprompts.dev/<span>{activeId}</span>
                            </div>
                            <div className="flex gap-4 text-zinc-600">
                                <ChevronRight size={18} className="rotate-180" />
                                <ChevronRight size={18} />
                            </div>
                        </div>
                        <div className="browser-frame__content">
                            <iframe
                                src={`/website-designs/${activeId}`}
                                className="browser-frame__iframe"
                                title={activeDesign.title}
                            />
                        </div>
                    </div>
                </div>
            </main>
        </div>
    )
}
