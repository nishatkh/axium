import { useState, useRef, useCallback } from 'react'
import { ShineButton } from './ShineButton'
import './CopyPrompt.css'

interface CopyPromptProps {
    prompt: string
    title: string
}

export default function CopyPrompt({ prompt, title }: CopyPromptProps) {
    const [expanded, setExpanded] = useState(false)
    const [copied, setCopied] = useState(false)
    const [btnCopied, setBtnCopied] = useState(false)
    const contentRef = useRef<HTMLDivElement>(null)
    const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

    const handleCopy = useCallback(async () => {
        try {
            await navigator.clipboard.writeText(prompt)
        } catch {
            const ta = document.createElement('textarea')
            ta.value = prompt
            ta.style.cssText = 'position:fixed;opacity:0'
            document.body.appendChild(ta)
            ta.select()
            document.execCommand('copy')
            document.body.removeChild(ta)
        }
        setCopied(true)
        if (timeoutRef.current) clearTimeout(timeoutRef.current)
        timeoutRef.current = setTimeout(() => setCopied(false), 2000)
    }, [prompt])

    const handleBtnCopy = useCallback(async () => {
        try {
            await navigator.clipboard.writeText(prompt)
        } catch {
            const ta = document.createElement('textarea')
            ta.value = prompt
            ta.style.cssText = 'position:fixed;opacity:0'
            document.body.appendChild(ta)
            ta.select()
            document.execCommand('copy')
            document.body.removeChild(ta)
        }
        setBtnCopied(true)
        setTimeout(() => setBtnCopied(false), 2000)
    }, [prompt])

    return (
        <div className="cprompt">
            <button className={`cprompt__trigger ${expanded ? 'is-active' : ''}`} onClick={() => setExpanded(e => !e)}>
                <div className="cprompt__trigger-left">
                    <svg className={`cprompt__chevron ${expanded ? 'is-open' : ''}`} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="9 18 15 12 9 6" />
                    </svg>
                    <span className="cprompt__trigger-label">
                        {expanded ? 'Hide Prompt' : 'View Prompt'}
                    </span>
                </div>
                <ShineButton
                    label={btnCopied ? 'Copied!' : 'Copy Prompt'}
                    onClick={() => { handleBtnCopy() }}
                    size="sm"
                    className="ml-auto"
                />
            </button>

            <div
                className="cprompt__content"
                style={{
                    maxHeight: expanded ? `${contentRef.current?.scrollHeight ?? 600}px` : '0px',
                    opacity: expanded ? 1 : 0,
                }}
            >
                <div ref={contentRef} className="cprompt__inner">
                    <div className="cprompt__bar">
                        <span className="cprompt__label">{title}</span>
                        <ShineButton
                            label={copied ? 'Copied!' : 'Copy'}
                            onClick={handleCopy}
                            size="sm"
                        />
                    </div>
                    <pre className="cprompt__code"><code>{prompt}</code></pre>
                </div>
            </div>
        </div>
    )
}
