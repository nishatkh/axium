"use client";
import React, { useEffect, useState } from "react";
import { ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { CountUp } from "./Charts";

export const UIAnalytics = () => {
    const [stats, setStats] = useState({
        buttons: 0,
        cards: 0,
        sections: 0,
        icons: 0,
        interactive: 0
    });

    const scanDOM = () => {
        // Target specific project elements
        const buttons = document.querySelectorAll('button, .heroButton, [class*="Button"]').length;
        const cards = document.querySelectorAll('.bento__item, [class*="Card"]').length;
        const sections = document.querySelectorAll('section, footer, nav').length;
        const icons = document.querySelectorAll('svg, .lucide, [class*="icon"]').length;
        const interactive = document.querySelectorAll('button, a, input, [onClick]').length;

        setStats({ buttons, cards, sections, icons, interactive });
    };

    useEffect(() => {
        scanDOM();

        // Dynamic Update: Set up an interval or MutationObserver if intensive change is expected
        const interval = setInterval(scanDOM, 5000);

        // Also scan on interactions
        window.addEventListener('scroll', scanDOM);

        return () => {
            clearInterval(interval);
            window.removeEventListener('scroll', scanDOM);
        };
    }, []);

    const pieData = [
        { name: "Buttons", value: stats.buttons },
        { name: "Cards", value: stats.cards },
        { name: "Sections", value: stats.sections },
        { name: "Icons", value: stats.icons },
    ];
    const COLORS = ["#2563eb", "#7c3aed", "#3b82f6", "#6d28d9"];

    const growthData = Array.from({ length: 7 }, (_, i) => ({
        day: i,
        count: Math.floor((stats.buttons + stats.cards) * (0.9 + Math.random() * 0.2))
    }));

    return (
        <div className="flex flex-col w-full gap-6">
            {/* Numeric Counters: Compact Row */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {[
                    { label: "Buttons", val: stats.buttons },
                    { label: "Cards", val: stats.cards },
                    { label: "Sections", val: stats.sections },
                    { label: "Icons", val: stats.icons },
                    { label: "Interacts", val: stats.interactive },
                ].map((item, i) => (
                    <div key={i} className="bg-black/40 border border-white/[0.02] rounded-lg p-3 flex flex-col items-center justify-center">
                        <div className="text-xl font-bold text-white tabular-nums"><CountUp value={item.val} /></div>
                        <div className="text-[8px] text-white/30 uppercase tracking-[0.2em] font-medium">{item.label}</div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* UI Distribution Pie - Compact */}
                <div className="h-[160px] flex items-center justify-center bg-black/20 border border-white/[0.02] rounded-xl p-4 overflow-hidden">
                    <div className="flex-1 h-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={pieData}
                                    innerRadius={40}
                                    outerRadius={55}
                                    paddingAngle={5}
                                    dataKey="value"
                                    animationDuration={1500}
                                >
                                    {pieData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="transparent" />
                                    ))}
                                </Pie>
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="flex flex-col gap-2 ml-4">
                        {pieData.map((item, i) => (
                            <div key={i} className="flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                                <span className="text-[9px] text-white/20 uppercase tracking-widest">{item.name}</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Growth Simulation - Compact */}
                <div className="h-[160px] bg-black/20 border border-white/[0.02] rounded-xl p-4 flex flex-col">
                    <div className="flex-1 overflow-hidden">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={growthData}>
                                <Line type="monotone" dataKey="count" stroke="#7c3aed" strokeWidth={2} dot={false} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="flex justify-between items-center mt-2 px-1">
                        <div className="text-[9px] text-white/20 uppercase tracking-[0.2em] font-medium">Flux Density</div>
                        <div className="text-[9px] text-purple-500 font-bold tracking-tighter">OPTIMIZED</div>
                    </div>
                </div>
            </div>
        </div>
    );
};
