"use client";
import React from "react";
import { motion } from "motion/react";
import { GlassCard } from "./GlassCard";
import { UsageRadial, AdoptionLine, PopularityBar, LimitationsDonut, SafetyGauge, LatencyMatrix } from "./Charts";
import { PointerHighlight } from "../UI/pointer-highlight";

export const AnalyticsDashboard = () => {
    return (
        <section className="relative w-full py-24 bg-black overflow-hidden border-t border-white/5">
            {/* Background Glows: Deep Purple and Royal Blue */}
            <div className="absolute top-0 left-1/4 w-[800px] h-[600px] bg-purple-900/10 rounded-full blur-[160px] pointer-events-none" />
            <div className="absolute bottom-1/4 right-0 w-[600px] h-[600px] bg-blue-900/10 rounded-full blur-[140px] pointer-events-none" />

            <div className="container mx-auto px-4 relative z-10">
                {/* Unified Dashboard Shell */}
                <div className="bg-[#030303] rounded-3xl border border-white/5 shadow-2xl overflow-hidden">

                    {/* Top Bar / Header */}
                    <div className="flex flex-col md:flex-row items-center justify-between px-4 sm:px-8 py-6 sm:py-10 border-b border-white/[0.03]">
                        <div>
                            <h2 className="text-2xl sm:text-3xl md:text-4xl font-display font-bold text-white tracking-tight">
                                AI Intelligence <PointerHighlight><span className="text-blue-700">Survey Dashboard</span></PointerHighlight>
                            </h2>
                        </div>
                    </div>

                    {/* Main Grid Content */}
                    <div className="p-4 sm:p-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">

                        {/* Row 1 */}
                        <GlassCard title="Global Daily Usage" subtitle="AI penetration index" delay={0.1}>
                            <UsageRadial />
                        </GlassCard>

                        <GlassCard title="Axium Adoption" subtitle="Dev velocity trendline" delay={0.2}>
                            <AdoptionLine />
                        </GlassCard>

                        <GlassCard title="AI Safety Index" subtitle="Ethics & Alignment Score" delay={0.3}>
                            <SafetyGauge />
                        </GlassCard>

                        <GlassCard title="Latency Matrix" subtitle="Global Node Response (ms)" delay={0.4}>
                            <LatencyMatrix />
                        </GlassCard>

                        {/* Row 2 */}
                        <GlassCard title="Top Tier Tooling" subtitle="Platform engagement rank" className="lg:col-span-2" delay={0.5}>
                            <PopularityBar />
                        </GlassCard>

                        <GlassCard title="System Constraints" subtitle="Reported performance gaps" className="lg:col-span-2" delay={0.6}>
                            <LimitationsDonut />
                        </GlassCard>

                    </div>

                    {/* Footer Stats Line */}
                    <div className="px-4 sm:px-8 py-3 sm:py-4 bg-white/[0.02] border-t border-white/[0.03] flex flex-col sm:flex-row justify-between items-center gap-2 text-[9px] text-white/20 uppercase tracking-[0.3em]">
                        <div className="flex gap-4 sm:gap-6 flex-wrap justify-center">
                            <span>US-EAST: 12ms</span>
                            <span>EU-WEST: 48ms</span>
                            <span>ASIA-SOUTH: 102ms</span>
                        </div>
                        <div className="hidden sm:block">© 2026 AXIUM INTELLIGENCE SYSTEMS</div>
                    </div>
                </div>
            </div>
        </section>
    );
};
