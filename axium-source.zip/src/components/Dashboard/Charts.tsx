"use client";
import React, { useState, useEffect } from "react";
import {
    ResponsiveContainer,
    PieChart, Pie, Cell,
    LineChart, Line, XAxis, YAxis, Tooltip,
    BarChart, Bar,
    RadialBarChart, RadialBar,
    AreaChart, Area
} from "recharts";
import { motion, useSpring, useTransform } from "motion/react";

// --- Numeric Counter ---
export const CountUp = ({ value, suffix = "" }: { value: number, suffix?: string }) => {
    const spring = useSpring(0, { damping: 40, stiffness: 100 });
    const displayValue = useTransform(spring, (current) => Math.floor(current).toLocaleString() + suffix);

    useEffect(() => {
        spring.set(value);
    }, [value, spring]);

    return <motion.span>{displayValue}</motion.span>;
};

// --- AI Daily Usage (Radial Progress) ---
export const UsageRadial = () => {
    const data = [{ name: "Usage", value: 84, fill: "url(#radialGradient)" }];

    return (
        <div className="relative w-full h-[180px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart innerRadius="80%" outerRadius="100%" data={data} startAngle={180} endAngle={-180}>
                    <defs>
                        <linearGradient id="radialGradient" x1="0" y1="0" x2="1" y2="1">
                            <stop offset="0%" stopColor="#2563eb" />
                            <stop offset="100%" stopColor="#7c3aed" />
                        </linearGradient>
                    </defs>
                    <RadialBar dataKey="value" cornerRadius={10} />
                </RadialBarChart>
            </ResponsiveContainer>
            <div className="absolute flex flex-col items-center">
                <div className="text-3xl font-bold text-white tracking-tighter"><CountUp value={84} suffix="%" /></div>
                <div className="text-[9px] text-blue-400 uppercase font-bold tracking-[0.2em] mt-1">
                    <span>Active Usage</span>
                </div>
            </div>
        </div>
    );
};

// --- Axium Adoption (Animated Line) ---
export const AdoptionLine = () => {
    const data = [
        { time: "09:00", value: 30 },
        { time: "11:00", value: 45 },
        { time: "13:00", value: 40 },
        { time: "15:00", value: 65 },
        { time: "17:00", value: 82 },
        { time: "19:00", value: 75 },
    ];

    return (
        <div className="w-full h-[180px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data}>
                    <defs>
                        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                            <feGaussianBlur stdDeviation="3" result="blur" />
                            <feComposite in="SourceGraphic" in2="blur" operator="over" />
                        </filter>
                    </defs>
                    <Tooltip
                        contentStyle={{ backgroundColor: 'rgba(5,5,5,0.95)', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '8px', fontSize: '10px' }}
                        itemStyle={{ color: '#fff' }}
                        cursor={{ stroke: 'rgba(255,255,255,0.05)', strokeWidth: 1 }}
                    />
                    <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#2563eb"
                        strokeWidth={4}
                        dot={false}
                        animationDuration={2000}
                        style={{ filter: 'url(#glow)' }}
                    />
                </LineChart>
            </ResponsiveContainer>
        </div>
    );
};

// --- AI Tool Popularity (Bar Chart) ---
export const PopularityBar = () => {
    const data = [
        { name: "Cursor", val: 92 },
        { name: "Bolt", val: 85 },
        { name: "Lovable", val: 78 },
        { name: "Claude", val: 88 },
        { name: "Replit", val: 74 },
        { name: "Builder", val: 68 },
    ];

    return (
        <div className="w-full h-[180px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                    <XAxis
                        dataKey="name"
                        stroke="rgba(255,255,255,0.2)"
                        fontSize={8}
                        axisLine={false}
                        tickLine={false}
                        interval={0}
                    />
                    <Bar
                        dataKey="val"
                        radius={[2, 2, 0, 0]}
                        animationDuration={1500}
                    >
                        {data.map((entry, index) => (
                            <Cell key={index} fill={index % 2 === 0 ? "#2563eb" : "#7c3aed"} fillOpacity={0.7} />
                        ))}
                    </Bar>
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

// --- AI Limitations (Donut Chart) ---
export const LimitationsDonut = () => {
    const data = [
        { name: "Accuracy", value: 35 },
        { name: "Hallucinations", value: 25 },
        { name: "Cost", value: 20 },
        { name: "Privacy", value: 20 },
    ];
    const COLORS = ["#2563eb", "#7c3aed", "#1d4ed8", "#6d28d9"];

    return (
        <div className="w-full h-[180px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                        data={data}
                        innerRadius={50}
                        outerRadius={65}
                        paddingAngle={5}
                        dataKey="value"
                        animationDuration={1500}
                    >
                        {data.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="transparent" />
                        ))}
                    </Pie>
                    <Tooltip
                        contentStyle={{ backgroundColor: 'rgba(5,5,5,0.95)', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '8px', fontSize: '10px' }}
                    />
                </PieChart>
            </ResponsiveContainer>
        </div>
    );
};

// --- AI Safety Index (Radial Gauge) ---
export const SafetyGauge = () => {
    const data = [{ name: "Safety", value: 94, fill: "url(#safetyGradient)" }];

    return (
        <div className="relative w-full h-[160px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart innerRadius="80%" outerRadius="100%" data={data} startAngle={180} endAngle={0}>
                    <defs>
                        <linearGradient id="safetyGradient" x1="0" y1="0" x2="1" y2="0">
                            <stop offset="0%" stopColor="#7c3aed" />
                            <stop offset="100%" stopColor="#2563eb" />
                        </linearGradient>
                    </defs>
                    <RadialBar dataKey="value" cornerRadius={10} />
                </RadialBarChart>
            </ResponsiveContainer>
            <div className="absolute top-[60%] flex flex-col items-center">
                <div className="text-2xl font-bold text-white tracking-tighter">94.2</div>
                <div className="text-[8px] text-purple-400 uppercase font-bold tracking-[0.2em]">Safety Score</div>
            </div>
        </div>
    );
};

// --- Latency Matrix (Area Chart Simulation) ---
export const LatencyMatrix = () => {
    const data = Array.from({ length: 12 }, (_, i) => ({
        time: i,
        ping: 20 + Math.random() * 15
    }));

    return (
        <div className="w-full h-[160px] mt-2">
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                    <defs>
                        <linearGradient id="latencyGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                        </linearGradient>
                    </defs>
                    <Tooltip
                        contentStyle={{ backgroundColor: 'rgba(5,5,5,0.95)', border: 'none', borderRadius: '4px', fontSize: '8px' }}
                        labelStyle={{ display: 'none' }}
                    />
                    <Area
                        type="stepAfter"
                        dataKey="ping"
                        stroke="#2563eb"
                        fillOpacity={1}
                        fill="url(#latencyGradient)"
                        strokeWidth={1}
                        animationDuration={1000}
                    />
                </AreaChart>
            </ResponsiveContainer>
        </div>
    );
};
