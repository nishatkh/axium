"use client";
import React from "react";
import { motion } from "motion/react";
import { cn } from "@/lib/utils";

interface GlassCardProps {
    children: React.ReactNode;
    className?: string;
    title?: string;
    subtitle?: string;
    delay?: number;
}

export const GlassCard = ({
    children,
    className,
    title,
    subtitle,
    delay = 0,
}: GlassCardProps) => {
    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{
                duration: 0.8,
                delay,
                ease: [0.16, 1, 0.3, 1]
            }}
            className={cn(
                "group relative flex flex-col p-5 rounded-xl border border-white/[0.03] bg-black backdrop-blur-3xl overflow-hidden",
                "shadow-[0_4px_24px_-10px_rgba(0,0,0,0.9),inset_0_1px_1px_rgba(255,255,255,0.02)]",
                "hover:border-blue-500/20 transition-all duration-500",
                className
            )}
        >
            {/* Technical Detail: Top Left Corner */}
            <div className="absolute top-0 left-0 w-8 h-[1px] bg-gradient-to-r from-blue-500/40 to-transparent" />
            <div className="absolute top-0 left-0 w-[1px] h-8 bg-gradient-to-b from-blue-500/40 to-transparent" />

            {/* Glow Accent */}
            <div className="absolute -inset-px bg-gradient-to-tr from-blue-600/0 via-purple-600/0 to-blue-400/0 rounded-[inherit] opacity-0 group-hover:opacity-100 group-hover:from-blue-600/5 group-hover:via-purple-600/5 group-hover:to-blue-400/5 blur-xl transition-opacity duration-700 pointer-events-none" />

            {(title || subtitle) && (
                <div className="mb-4 relative z-10 flex flex-col items-start">
                    {title && <h4 className="text-white/80 font-bold text-sm uppercase tracking-widest">{title}</h4>}
                    {subtitle && <p className="text-white/20 text-[9px] uppercase tracking-tighter mt-1">{subtitle}</p>}
                </div>
            )}

            <div className="relative z-10 flex-1 flex items-center justify-center">
                {children}
            </div>
        </motion.div>
    );
};
