import { useEffect, useRef, useState, type ReactNode } from 'react'
import CopyPrompt from './CopyPrompt'
import './DemoSection.css'

interface DemoSectionProps {
    id: string
    title: string
    description: string
    prompt: string
    children: ReactNode
}

export default function DemoSection({ id, title, description, prompt, children }: DemoSectionProps) {
    const ref = useRef<HTMLElement>(null)
    const [isVisible, setIsVisible] = useState(false)

    useEffect(() => {
        const el = ref.current
        if (!el) return
        const obs = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    el.classList.add('is-visible')
                    setIsVisible(true)
                    obs.unobserve(el)
                }
            },
            { threshold: 0.1, rootMargin: '200px' }
        )
        obs.observe(el)
        return () => obs.disconnect()
    }, [])

    return (
        <section className="demo" id={id} ref={ref}>
            <div className="demo__head">
                <h2 className="demo__title">{title}</h2>
                <p className="demo__desc">{description}</p>
            </div>
            <div className="demo__stage">
                {children}
            </div>
            <CopyPrompt prompt={prompt} title={`${title} — Full Prompt`} />
        </section>
    )
}
