import { useState, useCallback } from 'react'

const SAMPLE_IMAGES = [
    'https://images.pexels.com/photos/26797335/pexels-photo-26797335/free-photo-of-scenic-view-of-mountains.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/12194487/pexels-photo-12194487.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32423809/pexels-photo-32423809.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32296519/pexels-photo-32296519.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32396739/pexels-photo-32396739.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32304900/pexels-photo-32304900.jpeg?auto=compress&cs=tinysrgb&w=400',
]

export default function SliderPreview() {
    const [progress, setProgress] = useState(50)
    const items = SAMPLE_IMAGES.map((src, i) => ({ src, title: `Card ${i + 1}`, num: `0${i + 1}` }))

    const onWheel = useCallback((e: React.WheelEvent) => {
        setProgress(p => Math.max(0, Math.min(100, p + e.deltaY * 0.08)))
    }, [])

    const activeFloat = (progress / 100) * (items.length - 1)

    return (
        <div className="rp rp--slider" onWheel={onWheel}>
            {items.map((item, i) => {
                const ratio = (i - activeFloat) / (items.length - 1)
                const tx = ratio * 600
                const ty = ratio * 150
                const rot = ratio * 100
                const dist = Math.abs(i - activeFloat)
                const z = items.length - dist
                const opacity = Math.max(0, Math.min(1, (z / items.length) * 3 - 2))
                return (
                    <div
                        key={i}
                        className="rps__card"
                        style={{
                            transform: `translate3d(${tx}%, ${ty}%, 0) rotate(${rot}deg)`,
                            zIndex: Math.round(z * 10),
                            opacity,
                        }}
                    >
                        <img src={item.src} alt="" draggable={false} />
                        <span className="rps__num">{item.num}</span>
                        <span className="rps__title">{item.title}</span>
                    </div>
                )
            })}
            <p className="rp__hint">Scroll to navigate</p>
        </div>
    )
}
