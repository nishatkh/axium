export default function BeamPreview() {
    return (
        <div className="rp rp--beam">
            <div className="rpb__center">☀️</div>
            <div className="rpb__orbit rpb__orbit--1">
                <div className="rpb__node rpb__node--1">⚡</div>
            </div>
            <div className="rpb__orbit rpb__orbit--2">
                <div className="rpb__node rpb__node--2">💬</div>
                <div className="rpb__node rpb__node--3" style={{ top: 'auto', bottom: '-12px' }}>🔗</div>
            </div>
            <div className="rpb__orbit rpb__orbit--3">
                <div className="rpb__node rpb__node--4">💼</div>
                <div className="rpb__node rpb__node--5" style={{ left: '-12px', top: '50%' }}>🎨</div>
                <div className="rpb__node rpb__node--6" style={{ right: '-12px', top: '50%', left: 'auto' }}>📦</div>
            </div>
            <div className="rpb__orbit rpb__orbit--4">
                <div className="rpb__node rpb__node--7">🚀</div>
            </div>
        </div>
    )
}
