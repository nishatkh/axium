const SAMPLE_IMAGES = [
    'https://images.pexels.com/photos/26797335/pexels-photo-26797335/free-photo-of-scenic-view-of-mountains.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/12194487/pexels-photo-12194487.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32423809/pexels-photo-32423809.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32296519/pexels-photo-32296519.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32396739/pexels-photo-32396739.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32304900/pexels-photo-32304900.jpeg?auto=compress&cs=tinysrgb&w=400',
]

export default function MarqueePreview() {
    const cols = 4
    const perCol = 4
    return (
        <div className="rp rp--mq">
            <div className="rpm__tilt">
                {Array.from({ length: cols }).map((_, col) => (
                    <div key={col} className={`rpm__col ${col % 2 === 0 ? 'rpm__col--up' : 'rpm__col--down'}`}>
                        {Array.from({ length: perCol * 2 }).map((_, row) => (
                            <div key={row} className="rpm__cell">
                                <img src={SAMPLE_IMAGES[(col * perCol + row) % SAMPLE_IMAGES.length]} alt="" draggable={false} />
                            </div>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    )
}
