import React, { useRef, useState, useEffect, useCallback } from 'react'

const SAMPLE_IMAGES = [
    'https://images.pexels.com/photos/26797335/pexels-photo-26797335/free-photo-of-scenic-view-of-mountains.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/12194487/pexels-photo-12194487.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32423809/pexels-photo-32423809.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32296519/pexels-photo-32296519.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32396739/pexels-photo-32396739.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32304900/pexels-photo-32304900.jpeg?auto=compress&cs=tinysrgb&w=400',
]

export default function RingPreview() {
    const [rotation, setRotation] = useState(0)
    const dragging = useRef(false)
    const startX = useRef(0)
    const startRot = useRef(0)
    const velocity = useRef(0)
    const lastX = useRef(0)
    const animRef = useRef<number>(0)

    useEffect(() => {
        let lastTime = Date.now()
        const spin = () => {
            if (!dragging.current) {
                const now = Date.now()
                const dt = (now - lastTime) / 1000
                lastTime = now
                if (Math.abs(velocity.current) > 0.1) {
                    velocity.current *= 0.96
                    setRotation(r => r + velocity.current * dt * 60)
                } else {
                    velocity.current = 0
                    setRotation(r => r + 12 * dt)
                }
            }
            animRef.current = requestAnimationFrame(spin)
        }
        animRef.current = requestAnimationFrame(spin)
        return () => cancelAnimationFrame(animRef.current)
    }, [])

    const onDown = useCallback((e: React.MouseEvent | React.TouchEvent) => {
        dragging.current = true
        const x = 'touches' in e ? e.touches[0].clientX : e.clientX
        startX.current = x
        lastX.current = x
        startRot.current = rotation
        velocity.current = 0
    }, [rotation])

    useEffect(() => {
        const onMove = (e: MouseEvent | TouchEvent) => {
            if (!dragging.current) return
            const x = 'touches' in e ? (e as TouchEvent).touches[0].clientX : (e as MouseEvent).clientX
            const dx = x - startX.current
            velocity.current = (x - lastX.current) * 0.5
            lastX.current = x
            setRotation(startRot.current + dx * 0.5)
        }
        const onUp = () => { dragging.current = false }
        window.addEventListener('mousemove', onMove)
        window.addEventListener('mouseup', onUp)
        window.addEventListener('touchmove', onMove)
        window.addEventListener('touchend', onUp)
        return () => {
            window.removeEventListener('mousemove', onMove)
            window.removeEventListener('mouseup', onUp)
            window.removeEventListener('touchmove', onMove)
            window.removeEventListener('touchend', onUp)
        }
    }, [])

    const count = SAMPLE_IMAGES.length
    const angle = 360 / count

    return (
        <div className="rp rp--ring" onMouseDown={onDown} onTouchStart={onDown}>
            <div className="rp__perspective">
                <div className="rp__track" style={{ transform: `rotateY(${rotation}deg)` }}>
                    {SAMPLE_IMAGES.map((src, i) => (
                        <div key={i} className="rp__face" style={{ transform: `rotateY(${i * angle}deg) translateZ(180px)` }}>
                            <img src={src} alt="" draggable={false} />
                        </div>
                    ))}
                </div>
            </div>
            <p className="rp__hint">Drag to spin</p>
        </div>
    )
}
