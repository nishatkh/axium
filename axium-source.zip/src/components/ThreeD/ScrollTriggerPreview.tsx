const SAMPLE_IMAGES = [
    'https://images.pexels.com/photos/26797335/pexels-photo-26797335/free-photo-of-scenic-view-of-mountains.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/12194487/pexels-photo-12194487.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32423809/pexels-photo-32423809.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32296519/pexels-photo-32296519.jpeg?auto=compress&cs=tinysrgb&w=400',
]

export default function ScrollTriggerPreview() {
    const RowContent = () => (
        <>
            <span>AXIUM</span>
            <img src={SAMPLE_IMAGES[0]} alt="" />
            <span>PREMIUM</span>
            <img src={SAMPLE_IMAGES[1]} alt="" />
            <span>3D COMPONENTS</span>
            <img src={SAMPLE_IMAGES[2]} alt="" />
            <span>REACT</span>
            <img src={SAMPLE_IMAGES[3]} alt="" />
        </>
    )

    return (
        <div className="rp rp--st">
            <div className="rpst__row rpst__row--l">
                <div className="rpst__inner">
                    <RowContent /><RowContent />
                </div>
            </div>
            <div className="rpst__row rpst__row--r">
                <div className="rpst__inner">
                    <RowContent /><RowContent />
                </div>
            </div>
            <div className="rpst__row rpst__row--l rpst__row--slow">
                <div className="rpst__inner">
                    <RowContent /><RowContent />
                </div>
            </div>
        </div>
    )
}
