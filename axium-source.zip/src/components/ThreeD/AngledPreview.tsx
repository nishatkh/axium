const SAMPLE_IMAGES = [
    'https://images.pexels.com/photos/26797335/pexels-photo-26797335/free-photo-of-scenic-view-of-mountains.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/12194487/pexels-photo-12194487.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32423809/pexels-photo-32423809.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32296519/pexels-photo-32296519.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32396739/pexels-photo-32396739.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32304900/pexels-photo-32304900.jpeg?auto=compress&cs=tinysrgb&w=400',
]

export default function AngledPreview() {
    return (
        <div className="rp rp--angled">
            <div className="rpa__track">
                {[...SAMPLE_IMAGES, ...SAMPLE_IMAGES].map((src, i) => (
                    <div key={i} className="rpa__card">
                        <div className="rpa__card-inner">
                            <img src={src} alt="" draggable={false} />
                        </div>
                    </div>
                ))}
            </div>
            <p className="rp__hint">Hover to focus</p>
        </div>
    )
}
