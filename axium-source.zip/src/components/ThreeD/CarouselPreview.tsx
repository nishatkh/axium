import { useState, useEffect } from 'react'

const SAMPLE_IMAGES = [
    'https://images.pexels.com/photos/26797335/pexels-photo-26797335/free-photo-of-scenic-view-of-mountains.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/12194487/pexels-photo-12194487.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32423809/pexels-photo-32423809.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32296519/pexels-photo-32296519.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32396739/pexels-photo-32396739.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/32304900/pexels-photo-32304900.jpeg?auto=compress&cs=tinysrgb&w=400',
]

export default function CarouselPreview() {
    const [active, setActive] = useState(0)
    const count = SAMPLE_IMAGES.length

    useEffect(() => {
        const iv = setInterval(() => setActive(a => (a + 1) % count), 3000)
        return () => clearInterval(iv)
    }, [count])

    const getClass = (i: number) => {
        const diff = ((i - active) % count + count) % count
        if (diff === 0) return 'now'
        if (diff === 1) return 'next'
        if (diff === count - 1) return 'prev'
        if (diff === 2) return 'next2'
        if (diff === count - 2) return 'prev2'
        return ''
    }

    return (
        <div className="rp rp--carousel">
            <div className="rpc__slides">
                {SAMPLE_IMAGES.map((src, i) => (
                    <div key={i} className={`rpc__item ${getClass(i)}`}>
                        <img src={src} alt="" draggable={false} />
                    </div>
                ))}
            </div>
            <button className="rpc__arr rpc__arr--l" onClick={() => setActive((active - 1 + count) % count)}>‹</button>
            <button className="rpc__arr rpc__arr--r" onClick={() => setActive((active + 1) % count)}>›</button>
        </div>
    )
}
