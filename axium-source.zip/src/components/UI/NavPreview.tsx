"use client";
import React, { useState } from "react";
import { motion } from "framer-motion";

export default function NavPreview() {
    const tabs = ["Home", "Components", "Pricing", "About"];
    const [active, setActive] = useState(tabs[0]);

    return (
        <div className="flex h-64 w-full items-center justify-center bg-neutral-950">
            <div className="flex space-x-1 rounded-full bg-white/5 p-1 backdrop-blur-md border border-white/10">
                {tabs.map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActive(tab)}
                        className="relative rounded-full px-6 py-2 text-sm font-medium text-white transition-colors hover:text-white/80"
                    >
                        {active === tab && (
                            <motion.div
                                layoutId="nav-pill"
                                className="absolute inset-0 rounded-full bg-white/10"
                                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                            />
                        )}
                        <span className="relative z-10">{tab}</span>
                    </button>
                ))}
            </div>
        </div>
    );
}
