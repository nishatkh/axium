"use client";
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function TestimonialsPreview() {
    const [active, setActive] = useState(0);

    const testimonials = [
        {
            name: "Sarah Chen",
            role: "Lead Designer at Vercel",
            quote: "Axium has completely transformed how we approach high-fidelity UI engineering.",
            img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&auto=format&fit=crop"
        },
        {
            name: "Michael Torres",
            role: "Senior Engineer at Linear",
            quote: "The physics and fluid animations feel like native mobile experiences out of the box.",
            img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop"
        },
        {
            name: "Alex Rivera",
            role: "Creative Director at Stripe",
            quote: "I've never seen a library this meticulous with physics parameters and glassmorphism.",
            img: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=800&auto=format&fit=crop"
        }
    ];

    return (
        <div className="flex h-[400px] w-full items-center justify-center bg-neutral-950 font-sans p-8">
            <div className="relative w-full max-w-3xl grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
                <div className="relative h-64 perspective-[1000px]">
                    <AnimatePresence>
                        {testimonials.map((t, i) => (
                            i === active ? (
                                <motion.img
                                    key={t.name}
                                    src={t.img}
                                    initial={{ opacity: 0, rotateY: 10, scale: 0.9, z: -100 }}
                                    animate={{ opacity: 1, rotateY: 0, scale: 1, z: 0 }}
                                    exit={{ opacity: 0, rotateY: -10, scale: 0.9, z: 100 }}
                                    transition={{ type: "spring", stiffness: 200, damping: 20 }}
                                    className="absolute inset-0 w-full h-full object-cover rounded-2xl shadow-2xl border border-white/10"
                                />
                            ) : null
                        ))}
                    </AnimatePresence>
                </div>

                <div className="flex flex-col space-y-4 text-left p-4">
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={active}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.3 }}
                        >
                            <h3 className="text-xl font-bold text-white">{testimonials[active].name}</h3>
                            <p className="text-sm text-neutral-400 font-medium mb-6">{testimonials[active].role}</p>

                            <p className="text-lg text-neutral-300 leading-relaxed min-h-[100px]">
                                {testimonials[active].quote.split(" ").map((word, wIdx) => (
                                    <motion.span
                                        key={wIdx}
                                        initial={{ filter: "blur(10px)", opacity: 0 }}
                                        animate={{ filter: "blur(0px)", opacity: 1 }}
                                        transition={{ delay: wIdx * 0.04, duration: 0.3 }}
                                        className="inline-block mr-1"
                                    >
                                        {word}
                                    </motion.span>
                                ))}
                            </p>
                        </motion.div>
                    </AnimatePresence>

                    <div className="flex space-x-4 pt-4">
                        <button
                            onClick={() => setActive((active - 1 + testimonials.length) % testimonials.length)}
                            className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors border border-white/10"
                        >
                            <div className="w-3 h-3 border-l-2 border-b-2 border-white transform rotate-45 ml-1" />
                        </button>
                        <button
                            onClick={() => setActive((active + 1) % testimonials.length)}
                            className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors border border-white/10"
                        >
                            <div className="w-3 h-3 border-r-2 border-t-2 border-white transform rotate-45 mr-1" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
