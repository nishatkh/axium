"use client";
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function NotificationPreview() {
    const [notifications, setNotifications] = useState([1, 2, 3]);

    return (
        <div className="flex h-[300px] w-full items-center justify-center bg-neutral-950">
            <div className="relative w-80 h-40 font-sans">
                <AnimatePresence>
                    {notifications.map((id, index) => (
                        <motion.div
                            key={id}
                            layout
                            initial={{ opacity: 0, y: 50, scale: 0.8 }}
                            animate={{
                                opacity: 1 - index * 0.2,
                                y: index * 15,
                                scale: 1 - index * 0.05,
                                zIndex: notifications.length - index,
                            }}
                            exit={{ opacity: 0, y: -50, scale: 0.8 }}
                            onClick={() => setNotifications((n) => n.filter((nId) => nId !== id))}
                            className="absolute inset-x-0 top-0 cursor-pointer flex items-center p-4 rounded-xl bg-neutral-900 border border-white/10 shadow-2xl backdrop-blur-md"
                        >
                            <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center mr-4 shrink-0">
                                <div className="w-4 h-4 rounded-full bg-blue-500" />
                            </div>
                            <div className="flex flex-col">
                                <span className="text-white font-medium text-sm">System Update</span>
                                <span className="text-neutral-400 text-xs">Tap to dismiss notification {id}</span>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
                {notifications.length === 0 && (
                    <button
                        onClick={() => setNotifications([Date.now(), Date.now() + 1, Date.now() + 2])}
                        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white/50 text-sm border border-white/10 px-4 py-2 rounded-full"
                    >
                        Reset
                    </button>
                )}
            </div>
        </div>
    );
}
