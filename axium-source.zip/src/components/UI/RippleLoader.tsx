"use client";
import React from "react";
import { motion } from "motion/react";

type RippleLoaderProps = {
    icon?: React.ReactNode;
    size?: number;
    duration?: number; // in seconds
    logoColor?: string;
    websiteName?: string;
};

const RippleLoader: React.FC<RippleLoaderProps> = ({
    icon,
    size = 300,
    duration = 2.5,
    logoColor = "#7c3aed",
    websiteName = "AXIUM",
}) => {
    const baseInset = 40;
    const rippleBoxes = Array.from({ length: 3 }, (_, i) => ({
        inset: `${30 - i * 15}%`,
        zIndex: 99 - i,
        delay: i * 0.3,
        opacity: 0.6 - i * 0.2,
    }));

    return (
        <div
            className="relative flex items-center justify-center"
            style={{ width: size, height: size }}
        >
            {rippleBoxes.map((box, i) => (
                <motion.div
                    key={i}
                    className="absolute rounded-full border-t border-white/10 backdrop-blur-[8px]"
                    style={{
                        inset: box.inset,
                        zIndex: box.zIndex,
                        borderColor: `rgba(124, 58, 237, ${box.opacity * 0.3})`,
                        background: "linear-gradient(180deg, rgba(124, 58, 237, 0.05) 0%, rgba(0, 0, 0, 0) 100%)",
                    }}
                    animate={{
                        scale: [1, 1.15, 1],
                        boxShadow: [
                            "0 10px 40px -10px rgba(0, 0, 0, 0.5)",
                            "0 30px 60px -15px rgba(0, 0, 0, 0.6)",
                            "0 10px 40px -10px rgba(0, 0, 0, 0.5)",
                        ],
                    }}
                    transition={{
                        repeat: Infinity,
                        duration,
                        delay: box.delay,
                        ease: "easeInOut",
                    }}
                />
            ))}

            {/* CENTER CONTENT REMOVED AS PER USER REQUEST */}
        </div>
    );
};

export default RippleLoader;
