"use client";
import React from "react";
import { motion } from "framer-motion";

export default function MarqueePreview() {
    const items = ["React", "Framer Motion", "Tailwind CSS", "TypeScript", "Vite", "Next.js", "Node", "Vercel"];

    return (
        <div className="flex h-64 w-full items-center justify-center bg-neutral-950 font-sans overflow-hidden">
            <div className="relative w-full max-w-4xl flex items-center py-10" style={{ maskImage: "linear-gradient(to right, transparent, black 10%, black 90%, transparent)" }}>
                <motion.div
                    animate={{ x: [0, -1000] }}
                    transition={{ repeat: Infinity, ease: "linear", duration: 20 }}
                    className="flex gap-16 pr-16 whitespace-nowrap"
                >
                    {[...items, ...items, ...items].map((item, idx) => (
                        <div key={idx} className="text-3xl font-bold tracking-tighter text-neutral-600 hover:text-white transition-colors cursor-pointer">
                            {item}
                        </div>
                    ))}
                </motion.div>
            </div>
        </div>
    );
}
