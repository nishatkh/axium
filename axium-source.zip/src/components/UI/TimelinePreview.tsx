"use client";
import {
    useScroll,
    useTransform,
    motion,
} from "framer-motion";
import React, { useEffect, useRef, useState } from "react";

interface TimelineEntry {
    title: string;
    content: React.ReactNode;
}

export const Timeline = ({ data, containerRef }: { data: TimelineEntry[]; containerRef: React.RefObject<HTMLDivElement | null> }) => {
    const ref = useRef<HTMLDivElement>(null);
    const [height, setHeight] = useState(0);

    useEffect(() => {
        if (!ref.current) return;

        const updateHeight = () => {
            if (ref.current) {
                setHeight(ref.current.scrollHeight);
            }
        };

        const resizeObserver = new ResizeObserver(updateHeight);
        resizeObserver.observe(ref.current);

        // Final fallback update
        setTimeout(updateHeight, 500);

        return () => resizeObserver.disconnect();
    }, [data]);

    const { scrollYProgress } = useScroll({
        container: containerRef,
        target: ref,
        offset: ["start start", "end end"], // Map 0 to 1 perfectly
    });

    const heightTransform = useTransform(scrollYProgress, [0, 1], [0, height]);
    const opacityTransform = useTransform(scrollYProgress, [0, 0.1], [0, 1]);

    return (
        <div className="w-full bg-white dark:bg-neutral-950 font-sans md:px-10">
            <div className="max-w-7xl mx-auto py-20 px-4 md:px-8 lg:px-10 text-left">
                <h2 className="text-xl md:text-5xl mb-4 text-black dark:text-white max-w-4xl font-bold tracking-tight">
                    Development Journey
                </h2>
                <p className="text-neutral-700 dark:text-neutral-400 text-sm md:text-lg max-w-xl leading-relaxed">
                    A retrospective on the evolution of premium animation patterns and high-fidelity UI systems.
                </p>
            </div>

            <div ref={ref} className="relative max-w-7xl mx-auto pb-40">
                {data.map((item, index) => (
                    <div
                        key={index}
                        className="flex justify-start pt-20 md:pt-48 md:gap-10"
                    >
                        <div className="sticky flex flex-col md:flex-row z-40 items-center top-20 self-start max-w-xs lg:max-w-sm md:w-full">
                            <div className="h-10 absolute left-3 md:left-3 w-10 rounded-full bg-white dark:bg-black flex items-center justify-center border border-neutral-200 dark:border-neutral-800 shadow-sm">
                                <div className="h-4 w-4 rounded-full bg-neutral-200 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700" />
                            </div>
                            <h3 className="hidden md:block text-xl md:pl-20 md:text-6xl font-bold text-neutral-200 dark:text-neutral-800 transition-colors duration-500 hover:text-blue-500/50">
                                {item.title}
                            </h3>
                        </div>

                        <div className="relative pl-20 pr-4 md:pl-4 w-full text-left">
                            <h3 className="md:hidden block text-3xl mb-4 text-left font-bold text-neutral-500 dark:text-neutral-500">
                                {item.title}
                            </h3>
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true, margin: "-100px" }}
                                transition={{ duration: 0.8 }}
                            >
                                {item.content}
                            </motion.div>
                        </div>
                    </div>
                ))}

                {/* Vertical Progress Line */}
                <div
                    style={{
                        height: height + "px",
                    }}
                    className="absolute md:left-8 left-8 top-0 overflow-hidden w-[2px] bg-[linear-gradient(to_bottom,var(--tw-gradient-stops))] from-transparent from-[0%] via-neutral-200 dark:via-neutral-800 to-transparent to-[99%] [mask-image:linear-gradient(to_bottom,transparent_0%,black_10%,black_90%,transparent_100%)]"
                >
                    <motion.div
                        style={{
                            height: heightTransform,
                            opacity: opacityTransform,
                        }}
                        className="absolute inset-x-0 top-0 w-[2px] bg-gradient-to-t from-blue-600 via-purple-500 to-transparent from-[0%] via-[10%] rounded-full shadow-[0_0_15px_rgba(59,130,246,0.5)]"
                    />
                </div>
            </div>
        </div>
    );
};

export default function TimelinePreview() {
    const containerRef = useRef<HTMLDivElement>(null);
    const data = [
        {
            title: "2024.Q1",
            content: (
                <div className="bg-neutral-50 dark:bg-neutral-900 p-10 rounded-3xl border border-black/5 dark:border-white/5 shadow-2xl">
                    <p className="text-neutral-800 dark:text-neutral-200 text-sm md:text-lg font-medium mb-10 leading-relaxed">
                        Inauguration of the platform. Focused on bridging the gap between design and engineering with real-time feedback loops.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <img src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?q=80&w=2070&auto=format&fit=crop" className="rounded-2xl object-cover h-44 lg:h-72 w-full shadow-2xl hover:scale-[1.02] transition-transform duration-500" />
                        <img src="https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=2070&auto=format&fit=crop" className="rounded-2xl object-cover h-44 lg:h-72 w-full shadow-2xl hover:scale-[1.02] transition-transform duration-500" />
                    </div>
                </div>
            )
        },
        {
            title: "2024.Q2",
            content: (
                <div className="bg-neutral-50 dark:bg-neutral-900 p-10 rounded-3xl border border-black/5 dark:border-white/5 shadow-2xl">
                    <p className="text-neutral-800 dark:text-neutral-200 text-sm md:text-lg font-medium mb-10 leading-relaxed">
                        Mastery of the "Liquid Design" philosophy. Introduced glassmorphism components with sophisticated physics.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <img src="https://images.unsplash.com/photo-1633167606207-d840b5070fc2?w=800&auto=format&fit=crop" className="rounded-2xl object-cover h-44 lg:h-72 w-full shadow-2xl hover:scale-[1.02] transition-transform duration-500" />
                        <img src="https://images.unsplash.com/photo-1614850523296-e8c041de83a4?w=800&auto=format&fit=crop" className="rounded-2xl object-cover h-44 lg:h-72 w-full shadow-2xl hover:scale-[1.02] transition-transform duration-500" />
                    </div>
                </div>
            )
        },
        {
            title: "2024.Q4",
            content: (
                <div className="bg-neutral-50 dark:bg-neutral-900 p-10 rounded-3xl border border-black/5 dark:border-white/5 shadow-2xl">
                    <p className="text-neutral-800 dark:text-neutral-200 text-sm md:text-lg font-medium mb-10 leading-relaxed">
                        Scale phase. Integrated multi-agent AI coordination to automate high-fidelity asset generation.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop" className="rounded-2xl object-cover h-44 lg:h-72 w-full shadow-2xl hover:scale-[1.02] transition-transform duration-500" />
                        <img src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2070&auto=format&fit=crop" className="rounded-2xl object-cover h-44 lg:h-72 w-full shadow-2xl hover:scale-[1.02] transition-transform duration-500" />
                    </div>
                </div>
            )
        }
    ];

    return (
        <div
            ref={containerRef}
            className="w-full h-full overflow-y-auto bg-white dark:bg-neutral-950 scroll-smooth touch-pan-y"
            style={{
                borderRadius: '12px',
                border: '1px solid rgba(255,255,255,0.05)',
                position: 'relative' // Ensure sticky works relative to this
            }}
        >
            <Timeline data={data} containerRef={containerRef} />
        </div>
    );
}
