"use client";
import React from 'react';
import { ImagesBadge } from "@/components/UI/images-badge";

export default function ImagesBadgeDemo() {
    return (
        <div className="flex min-h-[400px] w-full items-center justify-center bg-white dark:bg-neutral-950 font-sans">
            <ImagesBadge
                folderSize={{ width: 80, height: 60 }}
                teaserImageSize={{ width: 50, height: 35 }}
                hoverImageSize={{ width: 120, height: 80 }}
                hoverTranslateY={-70}
                hoverSpread={50}
                hoverRotation={20}
                images={[
                    "https://assets.aceternity.com/pro/agenforce-1.webp",
                    "https://assets.aceternity.com/pro/agenforce-2.webp",
                    "https://assets.aceternity.com/pro/agenforce-3.webp",
                ]}
            />
        </div>
    );
}
