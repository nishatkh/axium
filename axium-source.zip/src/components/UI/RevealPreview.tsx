"use client";
import React, { useRef, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

const LINKS = [
    { text: "Acme Corp", image: "https://images.unsplash.com/photo-1497215848122-330110d3ada5?auto=format&fit=crop&w=600&q=80" },
    { text: "Globex", image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=600&q=80" },
    { text: "Soylent", image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=600&q=80" },
    { text: "Initech", image: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=600&q=80" },
];

export default function RevealPreview() {
    const [active, setActive] = useState(-1);
    const containerRef = useRef<HTMLDivElement>(null);

    const x = useMotionValue(0);
    const y = useMotionValue(0);

    const springX = useSpring(x, { stiffness: 300, damping: 30 });
    const springY = useSpring(y, { stiffness: 300, damping: 30 });

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        x.set(e.clientX - rect.left);
        y.set(e.clientY - rect.top);
    };

    return (
        <div
            className="relative flex h-[400px] w-full flex-col items-center justify-center bg-black p-8 font-sans overflow-hidden"
            ref={containerRef}
            onMouseMove={handleMouseMove}
        >
            <div className="flex w-full max-w-xl flex-col gap-0 border-t border-neutral-800">
                {LINKS.map((link, i) => (
                    <div
                        key={i}
                        onMouseEnter={() => setActive(i)}
                        onMouseLeave={() => setActive(-1)}
                        className="group relative flex cursor-pointer items-center justify-between border-b border-neutral-800 py-6 transition-colors hover:bg-neutral-900/50 px-4"
                    >
                        <h3 className="text-3xl font-bold text-neutral-400 transition-colors group-hover:text-white uppercase tracking-tighter">
                            {link.text}
                        </h3>
                        <span className="text-neutral-600 transition-colors group-hover:text-neutral-400 font-mono text-sm">
                            0{i + 1}
                        </span>
                    </div>
                ))}
            </div>

            {/* Floating Image */}
            <motion.div
                className="pointer-events-none absolute z-50 overflow-hidden rounded-xl shadow-[0_20px_40px_rgba(0,0,0,0.8)] border border-white/10 bg-neutral-900"
                style={{
                    width: 250,
                    height: 150,
                    left: springX,
                    top: springY,
                    x: "-50%",
                    y: "-50%",
                }}
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{
                    opacity: active !== -1 ? 1 : 0,
                    scale: active !== -1 ? 1 : 0.8,
                    rotate: active !== -1 ? (active % 2 === 0 ? 4 : -4) : 0
                }}
                transition={{ duration: 0.2, ease: "easeOut" }}
            >
                {active !== -1 && (
                    <img
                        src={LINKS[active].image}
                        alt="Reveal"
                        className="h-full w-full object-cover"
                    />
                )}
            </motion.div>
        </div>
    );
}
