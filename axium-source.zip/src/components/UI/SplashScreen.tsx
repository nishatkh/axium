"use client";
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import RippleLoader from "./RippleLoader";

export const SplashScreen = ({ children }: { children: React.ReactNode }) => {
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Artificial delay for premium feel
        const timer = setTimeout(() => {
            setLoading(false);
        }, 3500);

        return () => clearTimeout(timer);
    }, []);

    return (
        <>
            <AnimatePresence mode="wait">
                {loading && (
                    <motion.div
                        key="loader"
                        initial={{ opacity: 1 }}
                        exit={{
                            opacity: 0,
                            transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] }
                        }}
                        className="fixed inset-0 z-[9999] flex items-center justify-center bg-black overflow-hidden"
                    >
                        {/* Background Pure Black */}
                        <div className="absolute inset-0 bg-black" />

                        <RippleLoader websiteName="AXIUM" />

                        {/* Loading Text */}
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.5, duration: 1 }}
                            className="absolute bottom-12 flex flex-col items-center gap-2"
                        >
                            <div className="text-[10px] text-white/20 uppercase tracking-[0.5em] font-medium">Initializing Systems</div>
                            <div className="flex gap-1">
                                {[0, 1, 2].map((i) => (
                                    <motion.div
                                        key={i}
                                        animate={{ opacity: [0.2, 1, 0.2] }}
                                        transition={{ repeat: Infinity, duration: 1.5, delay: i * 0.2 }}
                                        className="w-1 h-1 rounded-full bg-purple-500"
                                    />
                                ))}
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{
                    opacity: loading ? 0 : 1,
                    scale: loading ? 0.98 : 1
                }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
                className="w-full"
            >
                {!loading && children}
            </motion.div>
        </>
    );
};
