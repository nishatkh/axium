"use client";
import React from "react";
import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

interface HeroButtonProps {
    children: React.ReactNode;
    to?: string;
    onClick?: () => void;
    variant?: "primary" | "secondary";
    className?: string;
}

export const HeroButton = ({
    children,
    to,
    onClick,
    variant = "primary",
    className,
}: HeroButtonProps) => {
    const isLink = !!to;

    const baseStyles = "relative px-8 py-3.5 rounded-full font-bold transition-all duration-300 flex items-center justify-center overflow-hidden active:scale-[0.98]";
    const fontStyles = { fontFamily: 'var(--space)' };

    const variants = {
        primary: "bg-white text-black shadow-lg hover:shadow-xl hover:bg-neutral-100",
        secondary: "bg-white/5 text-white border border-white/10 backdrop-blur-md hover:bg-white/10 hover:border-white/30"
    };

    const content = (
        <span className="relative z-10">{children}</span>
    );

    if (isLink) {
        return (
            <Link to={to} className={cn(baseStyles, variants[variant], className)} style={fontStyles}>
                {content}
            </Link>
        );
    }

    return (
        <button onClick={onClick} className={cn(baseStyles, variants[variant], className)} style={fontStyles}>
            {content}
        </button>
    );
};
