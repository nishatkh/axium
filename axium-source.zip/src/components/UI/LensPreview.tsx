"use client";
import React, { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

const IMG_SRC = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=2070&auto=format&fit=crop"; // A very clear, contrasty Nike shoe on red

export default function LensPreview() {
    const containerRef = useRef<HTMLDivElement>(null);
    const [pos, setPos] = useState({ x: 0, y: 0 });
    const [isHovering, setIsHovering] = useState(false);

    // Magic numbers: 150px lens, 2x zoom
    const LENS_RADIUS = 80;
    const ZOOM = 2;

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        setPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    };

    return (
        <div className="flex h-[500px] w-full items-center justify-center bg-black p-8 font-sans cursor-none">
            <div
                ref={containerRef}
                onMouseMove={handleMouseMove}
                onMouseEnter={() => setIsHovering(true)}
                onMouseLeave={() => setIsHovering(false)}
                className="relative h-full w-full max-w-2xl overflow-hidden rounded-2xl bg-neutral-900 border border-white/10"
            >
                {/* The Base Image (Greyed out) */}
                <img
                    src={IMG_SRC}
                    alt="Base Object"
                    className="absolute inset-0 h-full w-full object-cover transition-opacity duration-300"
                    style={{
                        opacity: isHovering ? 0.5 : 1,
                    }}
                />

                {/* Text Overlay (Visible only when not hovering) */}
                {!isHovering && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none bg-black/20">
                        <h2 className="text-4xl font-black text-white tracking-widest drop-shadow-lg">INSPECT</h2>
                        <p className="text-neutral-200 mt-2 tracking-widest text-sm drop-shadow-md">Bring the details to light</p>
                    </div>
                )}

                {/* The Magnified Layer (Uses Clip-Path) */}
                <AnimatePresence>
                    {isHovering && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="absolute inset-0 pointer-events-none"
                            style={{
                                clipPath: `circle(${LENS_RADIUS}px at ${pos.x}px ${pos.y}px)`,
                            }}
                        >
                            {/* Scaled up image centered on mouse */}
                            <div
                                className="absolute inset-0"
                                style={{
                                    transformOrigin: `${pos.x}px ${pos.y}px`,
                                    transform: `scale(${ZOOM})`,
                                }}
                            >
                                <img
                                    src={IMG_SRC}
                                    alt="Magnified Object"
                                    className="absolute inset-0 h-full w-full object-cover"
                                />
                            </div>

                            {/* Removed inner radial gradient shadow to keep lens pure */}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
}
