"use client";
import React, { useState } from "react";
import { motion } from "framer-motion";

export default function FolderPreview() {
    const [hovered, setHovered] = useState(false);

    return (
        <div className="flex h-[400px] w-full items-center justify-center bg-black cursor-pointer font-sans">
            <motion.div
                className="relative"
                onHoverStart={() => setHovered(true)}
                onHoverEnd={() => setHovered(false)}
                style={{ perspective: 1000 }}
            >
                <motion.div
                    animate={{ rotateX: hovered ? -20 : -10, y: hovered ? 10 : 0 }}
                    transition={{ type: "spring", stiffness: 200, damping: 20 }}
                    className="relative w-48 h-36 origin-bottom"
                >
                    {/* Back of folder */}
                    <div className="absolute inset-x-0 bottom-0 h-full rounded-2xl bg-neutral-800 border border-neutral-700/50" />
                    <div className="absolute -top-4 left-4 h-6 w-16 rounded-t-lg bg-neutral-800 border border-neutral-700/50 border-b-0" />

                    {/* Documents inside */}
                    <motion.div
                        animate={{ y: hovered ? -40 : 0, scale: hovered ? 1.05 : 1 }}
                        transition={{ type: "spring", stiffness: 300, damping: 25 }}
                        className="absolute inset-x-4 bottom-4 h-24 rounded-lg bg-neutral-900 border border-neutral-700 blur-[0.5px] shadow-xl flex items-center justify-center overflow-hidden"
                    >
                        <div className="h-full w-full bg-neutral-900/50 backdrop-blur-sm flex flex-col items-start p-4 gap-2">
                            <div className="w-full h-2 bg-neutral-700/50 rounded-full" />
                            <div className="w-3/4 h-2 bg-neutral-700/50 rounded-full" />
                            <div className="w-1/2 h-2 bg-neutral-700/50 rounded-full" />
                        </div>
                    </motion.div>

                    {/* Front cover */}
                    <motion.div
                        animate={{ rotateX: hovered ? -30 : 0 }}
                        transition={{ type: "spring", stiffness: 200, damping: 20 }}
                        className="absolute inset-x-0 bottom-0 h-[85%] origin-bottom rounded-xl bg-neutral-800/80 backdrop-blur-md border border-neutral-600/30 shadow-[0_-10px_20px_rgba(0,0,0,0.5)] flex items-end p-3"
                    >
                        <span className="text-xs font-semibold text-neutral-400">Project Files</span>
                    </motion.div>
                </motion.div>
            </motion.div>
        </div>
    );
}
