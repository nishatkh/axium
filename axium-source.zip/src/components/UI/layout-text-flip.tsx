"use client";
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "@/lib/utils";

export const LayoutTextFlip = ({
    text = "Build Amazing",
    words = ["Landing Pages", "Component Blocks", "Page Sections", "3D Shaders"],
    duration = 3000,
    className = "",
}: {
    text: string;
    words: string[];
    duration?: number;
    className?: string;
}) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % words.length);
        }, duration);

        return () => clearInterval(interval);
    }, [words.length, duration]);

    return (
        <div className={cn("flex flex-col sm:flex-row items-center justify-center gap-4", className)}>
            <motion.span
                layoutId="subtext"
                className="text-4xl font-bold tracking-tight drop-shadow-xl md:text-6xl"
                style={{ fontFamily: 'system-ui', fontWeight: 600 }}
            >
                {text}
            </motion.span>

            <motion.span
                layout
                className="relative w-fit overflow-hidden rounded-xl border border-white/10 bg-white/5 px-8 py-3 font-sans text-4xl font-bold text-white shadow-2xl backdrop-blur-md md:text-6xl"
                style={{ fontFamily: 'system-ui', fontWeight: 700 }}
            >
                <AnimatePresence mode="popLayout">
                    <motion.span
                        key={currentIndex}
                        initial={{ y: -40, filter: "blur(10px)", opacity: 0 }}
                        animate={{
                            y: 0,
                            filter: "blur(0px)",
                            opacity: 1
                        }}
                        exit={{ y: 50, filter: "blur(10px)", opacity: 0 }}
                        transition={{
                            duration: 0.5,
                            ease: [0.23, 1, 0.32, 1]
                        }}
                        className={cn("inline-block whitespace-nowrap")}
                    >
                        {words[currentIndex]}
                    </motion.span>
                </AnimatePresence>
            </motion.span>
        </div>
    );
};
