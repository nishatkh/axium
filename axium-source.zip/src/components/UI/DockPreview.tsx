"use client";
import React, { useRef } from "react";
import { motion, useMotionValue, useSpring, useTransform, MotionValue } from "framer-motion";

import { Sparkles, Palette, Code2, Rocket, Settings } from "lucide-react";

export default function DockPreview() {
    const mouseX = useMotionValue(Infinity);

    return (
        <div className="flex h-[400px] w-full items-center justify-center bg-black dark:bg-black font-sans">
            <motion.div
                onMouseMove={(e) => mouseX.set(e.pageX)}
                onMouseLeave={() => mouseX.set(Infinity)}
                className="mx-auto flex h-16 items-end gap-4 rounded-2xl bg-neutral-900/80 px-4 pb-3 shadow-[0_0_0_1px_rgba(255,255,255,0.05),_0_10px_40px_rgba(0,0,0,0.8)] backdrop-blur-xl"
            >
                {[
                    { icon: Sparkles, label: "Sparkles" },
                    { icon: Palette, label: "Design" },
                    { icon: Code2, label: "Code" },
                    { icon: Rocket, label: "Deploy" },
                    { icon: Settings, label: "Settings" },
                ].map((item, i) => (
                    <DockItem key={i} mouseX={mouseX} item={item} />
                ))}
            </motion.div>
        </div>
    );
}

function DockItem({ mouseX, item }: { mouseX: MotionValue<number>; item: any }) {
    const ref = useRef<HTMLDivElement>(null);

    const distance = useTransform(mouseX, (val: number) => {
        let bounds = ref.current?.getBoundingClientRect() ?? { x: 0, width: 0 };
        return val - bounds.x - bounds.width / 2;
    });

    let widthSync = useTransform(distance, [-150, 0, 150], [40, 80, 40]);
    let width = useSpring(widthSync, { mass: 0.1, stiffness: 150, damping: 12 });

    return (
        <motion.div
            ref={ref}
            style={{ width }}
            className="group relative flex aspect-square items-center justify-center rounded-full bg-neutral-800 border border-neutral-700/50 shadow-[inset_0_1px_1px_rgba(255,255,255,0.1)] text-neutral-400 hover:text-white transition-colors"
        >
            <item.icon className="h-6 w-6" />
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md bg-neutral-800 px-3 py-1.5 text-xs text-neutral-300 opacity-0 transition-opacity group-hover:opacity-100 border border-neutral-700/50 shadow-xl pointer-events-none">
                {item.label}
            </div>
        </motion.div>
    );
}
