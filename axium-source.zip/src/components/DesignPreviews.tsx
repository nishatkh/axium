import React from 'react'

export function MinimalistPreview() {
    return (
        <div className="w-full h-full min-h-[400px] flex items-center justify-center bg-white text-black p-8 font-serif" style={{ border: '1px solid #e5e5e5' }}>
            <div className="w-full max-w-2xl flex flex-col gap-6">
                <div className="w-full border-t-4 border-black pt-4">
                    <h1 className="text-5xl md:text-7xl font-bold tracking-tighter leading-none" style={{ fontFamily: 'Playfair Display, Georgia, serif' }}>
                        ESSENCE.
                    </h1>
                </div>
                <p className="text-lg md:text-xl text-neutral-600 max-w-md leading-relaxed" style={{ fontFamily: 'Source Serif 4, Georgia, serif' }}>
                    Reduction to the absolute foundation. Pure black, pure white, and uncompromised architectural precision.
                </p>
                <div className="flex gap-4 pt-4">
                    <button className="px-8 py-3 bg-black text-white uppercase tracking-widest text-xs font-semibold hover:bg-white hover:text-black hover:outline hover:outline-2 hover:outline-black transition-all duration-100">
                        Discover
                    </button>
                    <button className="px-8 py-3 bg-transparent text-black uppercase tracking-widest text-xs font-semibold border-b-2 border-black hover:bg-gray-100 transition-all duration-100">
                        View Archive
                    </button>
                </div>
            </div>
        </div>
    )
}

export function BauhausPreview() {
    return (
        <div className="w-full h-full min-h-[400px] bg-[#F7F5F0] text-[#111] p-6 lg:p-12 font-sans border-4 border-[#111]">
            <div className="grid grid-cols-12 h-full border-4 border-[#111] bg-white divide-x-4 divide-[#111]">
                <div className="col-span-8 flex flex-col divide-y-4 divide-[#111]">
                    <div className="p-8 pb-16 relative overflow-hidden bg-[#FFD300]">
                        <div className="absolute top-4 right-4 w-32 h-32 rounded-full bg-[#E32636] mix-blend-multiply" />
                        <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tighter mix-blend-difference text-white">FORM</h1>
                        <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tighter text-[#111]">FUNCTION</h1>
                    </div>
                    <div className="p-6 flex-1 flex items-end">
                        <button className="px-6 py-3 bg-[#0038A8] text-[#F7F5F0] uppercase font-bold tracking-widest border-2 border-[#111] shadow-[4px_4px_0_0_#111] hover:shadow-none hover:translate-x-1 hover:translate-y-1 transition-all">
                            Axium
                        </button>
                    </div>
                </div>
                <div className="col-span-4 bg-[#E32636] relative flex items-center justify-center">
                    <div className="rotate-90 origin-center text-white font-mono text-sm tracking-widest uppercase absolute whitespace-nowrap">
                        Staatliches Bauhaus
                    </div>
                </div>
            </div>
        </div>
    )
}

export function ModernPreview() {
    return (
        <div className="w-full h-full min-h-[400px] bg-[#0A0A0A] text-[#EDEDED] p-8 font-sans overflow-hidden relative rounded-xl border border-white/10" style={{ boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.05)' }}>
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-[#5E6AD2]/20 blur-[100px] rounded-full mix-blend-screen pointer-events-none" />

            <div className="relative z-10 w-full max-w-xl mx-auto flex flex-col items-center justify-center h-full text-center gap-6 mt-12">
                <div className="px-3 py-1 text-xs font-medium text-[#5E6AD2] bg-[#5E6AD2]/10 border border-[#5E6AD2]/20 rounded-full">
                    Linear / Modern Design v2.0
                </div>
                <h1 className="text-4xl md:text-5xl font-semibold tracking-tight text-white drop-shadow-md">
                    Fluid. Precise. Engineered.
                </h1>
                <p className="text-[#8A8F98] text-sm md:text-base max-w-md">
                    The pinnacle of contemporary tech design. Ultra-refined details, deep space backgrounds, and buttery-smooth micro-interactions.
                </p>
                <div className="flex gap-4 mt-4">
                    <button className="px-5 py-2.5 bg-[#5E6AD2] hover:bg-[#6B79E3] text-white text-sm font-medium rounded-md shadow-[0_0_20px_rgba(94,106,210,0.3)] border border-white/10 transition-all">
                        Get Started
                    </button>
                    <button className="px-5 py-2.5 bg-[#1A1A1A] hover:bg-[#222] text-[#EDEDED] text-sm font-medium rounded-md border border-white/10 shadow-sm transition-all" style={{ boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.05)' }}>
                        Read Documentation
                    </button>
                </div>
            </div>

            <div className="absolute bottom-0 w-full h-[150px] bg-gradient-to-t from-[#0A0A0A] to-transparent z-20 pointer-events-none" />
        </div>
    )
}

export function NewsprintPreview() {
    return (
        <div className="w-full h-full min-h-[400px] bg-[#FDFCF6] text-[#1A1A1A] p-6 lg:p-10 font-serif border border-[#E0DCD0]">
            <div className="w-full border-y-[4px] border-[#1A1A1A] py-4 mb-8 text-center">
                <h1 className="text-4xl md:text-6xl font-black tracking-tight uppercase" style={{ fontFamily: 'Playfair Display, Georgia, serif' }}>
                    The Daily Wire
                </h1>
                <div className="flex justify-between items-center px-4 mt-2 text-xs font-sans text-[#555] uppercase tracking-widest border-t border-[#E0DCD0] pt-2">
                    <span>Vol. CXLIV, No. 50,000</span>
                    <span>Late Edition</span>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 divide-y md:divide-y-0 md:divide-x divide-[#E0DCD0]">
                <div className="md:col-span-2 pr-4 flex flex-col gap-4">
                    <span className="text-xs uppercase tracking-widest font-sans text-[#A31A1A] font-semibold">Architecture</span>
                    <h2 className="text-3xl font-bold leading-tight" style={{ fontFamily: 'Playfair Display, Georgia, serif' }}>
                        The Return of Authoritative Digital Typography
                    </h2>
                    <p className="text-base text-[#1A1A1A] leading-relaxed columns-1 lg:columns-2 gap-6 text-justify">
                        <span className="float-left text-5xl font-black pr-2 pt-1 leading-none" style={{ fontFamily: 'Playfair Display, Georgia, serif' }}>D</span>
                        igital broadsheet aesthetics bring the timeless, authoritative feel of a classic newspaper into the modern web. It prioritizes reading experience, dense information architecture, strict columnar grids, and absolute typographic rigor. It asks the user to slow down and read, valuing content over decoration.
                    </p>
                </div>
                <div className="pl-4 flex flex-col gap-3 pt-4 md:pt-0">
                    <h3 className="text-lg font-bold italic" style={{ fontFamily: 'Playfair Display, Georgia, serif' }}>In Other News</h3>
                    <ul className="flex flex-col gap-3">
                        <li className="border-b border-[#E0DCD0] pb-2 text-sm">Minimalism sees sharp decline in experimental circles.</li>
                        <li className="border-b border-[#E0DCD0] pb-2 text-sm">Serif fonts report highest usage since early 2010s.</li>
                    </ul>
                </div>
            </div>
        </div>
    )
}

export function TerminalPreview() {
    return (
        <div className="w-full h-full min-h-[400px] bg-[#000000] text-[#33FF00] p-6 font-mono border border-[#33FF00]">
            <div className="border-b border-dashed border-[#33FF00] pb-4 mb-4 flex justify-between items-end">
                <span>root@system:~/site$ ./init_design.sh</span>
                <span className="text-xs opacity-50">STATUS: ONLINE</span>
            </div>

            <div className="flex flex-col gap-4 text-sm mt-8">
                <div>
                    <span className="opacity-70">&gt; Loading core modules... </span>
                    <span>[ OK ]</span>
                </div>
                <div>
                    <span className="opacity-70">&gt; Fetching aesthetic components... </span>
                    <span>[ OK ]</span>
                </div>
                <div className="mt-4 border border-[#33FF00] p-4 text-[#33FF00] bg-transparent">
                    <pre className="text-xs">
                        +-----------------------------------------+
                        | SYSTEM ACCESS GRANTED                   |
                        | RENDER: TERMINAL_CLI_V1                 |
                        +-----------------------------------------+
                    </pre>
                </div>
                <div className="mt-6 flex items-center gap-2">
                    <span>root@system:~/site$</span>
                    <input type="text" className="bg-transparent border-none outline-none text-[#33FF00] flex-1" defaultValue="execute block" readOnly />
                    <span className="animate-pulse">█</span>
                </div>
                <div className="flex gap-4 mt-2">
                    <button className="px-4 py-1 text-[#33FF00] hover:bg-[#33FF00] hover:text-black uppercase">
                        [ Proceed ]
                    </button>
                    <button className="px-4 py-1 text-[#33FF00] hover:bg-[#33FF00] hover:text-black uppercase">
                        [ Abort ]
                    </button>
                </div>
            </div>
        </div>
    )
}

export function SwissPreview() {
    return (
        <div className="w-full h-full min-h-[400px] bg-white text-black p-8 font-sans border border-black overflow-hidden relative">
            <div className="absolute top-0 right-0 w-1/3 h-full bg-[#E32636]" />

            <div className="grid grid-cols-12 gap-6 h-full relative z-10">
                <div className="col-span-12 md:col-span-8 flex flex-col h-full justify-between">
                    <div>
                        <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-none mb-6 max-w-md">
                            Absolute Objectivity
                        </h1>
                        <div className="grid grid-cols-2 gap-4 max-w-lg mt-12">
                            <div>
                                <h3 className="text-sm font-bold border-t-2 border-black pt-1">01</h3>
                                <p className="text-xs mt-2 text-justify">Emerging from Switzerland in the 1950s, this style believes design should be a transparent vessel for information.</p>
                            </div>
                            <div>
                                <h3 className="text-sm font-bold border-t-2 border-black pt-1">02</h3>
                                <p className="text-xs mt-2 text-justify">It rejects ornamentation, personal expression, and subjectivity in favor of universal clarity against a mathematical grid.</p>
                            </div>
                        </div>
                    </div>

                    <button className="self-start mt-8 px-6 py-3 bg-[#E32636] text-white font-bold text-sm hover:bg-black transition-colors rounded-none">
                        Explore Method
                    </button>
                </div>
            </div>

            <div className="absolute bottom-8 right-8 text-white z-20 hidden md:block">
                <span className="text-4xl font-black">1950</span>
            </div>
        </div>
    )
}
