import React, { useRef, useEffect, useState, useCallback, useMemo, memo } from 'react'
import { motion, useMotionValue, useMotionTemplate, useSpring, useInView, useAnimate, stagger, AnimatePresence } from 'framer-motion'
import './TextPreviews.css'

/* ==========================================================
   1. SCROLL REVEAL PREVIEW
   ========================================================== */
export function ScrollRevealPreview() {
    const ref = useRef<HTMLDivElement>(null)
    const isInView = useInView(ref, { amount: 0.3 })
    const words = "Build stunning interfaces with elegant scroll-driven text reveals".split(' ')

    return (
        <div className="txp-preview txp-scroll-wrapper" ref={ref}>
            <p style={{ fontSize: '1.8rem', fontWeight: 700, lineHeight: 1.4, letterSpacing: '-0.02em' }}>
                {words.map((word, i) => (
                    <motion.span
                        key={i}
                        className="inline-block mr-[0.35em]"
                        initial={{ opacity: 0.1, filter: 'blur(4px)', y: 20 }}
                        animate={isInView ? { opacity: 1, filter: 'blur(0px)', y: 0 } : { opacity: 0.1, filter: 'blur(4px)', y: 20 }}
                        transition={{ delay: i * 0.06, duration: 0.5, type: 'spring', damping: 25, stiffness: 100 }}
                    >
                        {word}
                    </motion.span>
                ))}
            </p>
        </div>
    )
}

/* ==========================================================
   2. SHINY TEXT PREVIEW
   ========================================================== */
export function ShinyTextPreview() {
    return (
        <div className="txp-preview txp-shiny-wrapper">
            <span className="txp-shiny-text">Premium Shiny Text</span>
            <span style={{ fontSize: '0.85rem', color: '#71717a' }}>Hover & direction-aware shine</span>
        </div>
    )
}

/* ==========================================================
   3. TEXT SCROLL MARQUEE PREVIEW
   ========================================================== */
export function TextMarqueePreview() {
    const text = 'VELOCITY DRIVEN TEXT MARQUEE · SCROLL REACTIVE · INFINITE LOOP · '
    return (
        <div className="txp-preview" style={{ overflow: 'hidden' }}>
            <div className="txp-marquee-track">
                {[1, 2, 3, 4].map(i => <span key={i}>{text}</span>)}
            </div>
        </div>
    )
}

/* ==========================================================
   4. TYPING TEXT PREVIEW
   ========================================================== */
export function TypingTextPreview() {
    const text = 'Typing animation effect...'
    const [count, setCount] = useState(0)

    useEffect(() => {
        if (count >= text.length) {
            const t = setTimeout(() => setCount(0), 2000)
            return () => clearTimeout(t)
        }
        const t = setTimeout(() => setCount(c => c + 1), 80)
        return () => clearTimeout(t)
    }, [count, text.length])

    return (
        <div className="txp-preview">
            <div className="txp-typing-wrapper">
                <span>{text.slice(0, count)}</span>
                <span className="txp-typing-cursor" />
            </div>
        </div>
    )
}

/* ==========================================================
   5. CANVAS TEXT PREVIEW
   ========================================================== */
export function CanvasTextPreview() {
    return (
        <div className="txp-preview txp-canvas-wrapper">
            <span className="txp-canvas-text">Lightning Speed</span>
        </div>
    )
}

/* ==========================================================
   6. ENCRYPTED TEXT PREVIEW
   ========================================================== */
export function EncryptedTextPreview() {
    const text = 'Welcome to the Matrix, Neo.'
    const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()'
    const ref = useRef<HTMLSpanElement>(null)
    const isInView = useInView(ref, { once: true })
    const [revealCount, setRevealCount] = useState(0)
    const scrambleRef = useRef<string[]>(
        text.split('').map(c => c === ' ' ? ' ' : charset[Math.floor(Math.random() * charset.length)])
    )
    const [, forceUpdate] = useState(0)

    useEffect(() => {
        if (!isInView) return
        const startTime = performance.now()
        let raf: number
        const update = (now: number) => {
            const elapsed = now - startTime
            const currentReveal = Math.min(text.length, Math.floor(elapsed / 50))
            setRevealCount(currentReveal)
            if (currentReveal >= text.length) return
            // Re-scramble unrevealed characters
            for (let i = currentReveal; i < text.length; i++) {
                if (text[i] !== ' ') {
                    scrambleRef.current[i] = charset[Math.floor(Math.random() * charset.length)]
                }
            }
            forceUpdate(n => n + 1)
            raf = requestAnimationFrame(update)
        }
        raf = requestAnimationFrame(update)
        return () => cancelAnimationFrame(raf)
    }, [isInView])

    return (
        <div className="txp-preview txp-encrypt-wrapper">
            <span ref={ref} role="text" aria-label={text}>
                {text.split('').map((char, i) => (
                    <span key={i} className={i < revealCount ? 'txp-encrypt-revealed' : 'txp-encrypt-scrambled'}>
                        {i < revealCount ? char : (char === ' ' ? ' ' : scrambleRef.current[i])}
                    </span>
                ))}
            </span>
        </div>
    )
}

/* ==========================================================
   7. LAYOUT TEXT FLIP PREVIEW
   ========================================================== */
export function LayoutTextFlipPreview() {
    const words = ['Premium UI', 'Modern Apps', 'Fast Sites', 'Great DX']
    const [idx, setIdx] = useState(0)

    useEffect(() => {
        const t = setInterval(() => setIdx(i => (i + 1) % words.length), 2500)
        return () => clearInterval(t)
    }, [])

    return (
        <div className="txp-preview txp-flip-wrapper">
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap', justifyContent: 'center' }}>
                <span className="txp-flip-static">Build </span>
                <AnimatePresence mode="popLayout">
                    <motion.span
                        key={idx}
                        className="txp-flip-word"
                        initial={{ y: -30, filter: 'blur(8px)', opacity: 0 }}
                        animate={{ y: 0, filter: 'blur(0px)', opacity: 1 }}
                        exit={{ y: 40, filter: 'blur(8px)', opacity: 0 }}
                        transition={{ duration: 0.4 }}
                    >
                        {words[idx]}
                    </motion.span>
                </AnimatePresence>
            </div>
        </div>
    )
}

/* ==========================================================
   8. FLIP WORDS PREVIEW
   ========================================================== */
export function FlipWordsPreview() {
    const words = ['better', 'beautiful', 'modern', 'elegant']
    const [current, setCurrent] = useState(0)
    const [animating, setAnimating] = useState(false)

    useEffect(() => {
        if (!animating) {
            const t = setTimeout(() => {
                setCurrent(c => (c + 1) % words.length)
                setAnimating(true)
            }, 2500)
            return () => clearTimeout(t)
        }
    }, [animating])

    return (
        <div className="txp-preview txp-flipwords-wrapper">
            <div style={{ fontSize: '2rem', fontWeight: 600, color: '#a3a3a3' }}>
                Build{' '}
                <AnimatePresence onExitComplete={() => setAnimating(false)}>
                    <motion.span
                        key={current}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -40, x: 40, filter: 'blur(8px)', scale: 2, position: 'absolute' as const }}
                        transition={{ type: 'spring', stiffness: 100, damping: 10 }}
                        style={{ display: 'inline-block', color: '#fff', position: 'relative' }}
                    >
                        {words[current]}
                    </motion.span>
                </AnimatePresence>
                <br />
                <span style={{ fontSize: '1rem', color: '#525252', fontWeight: 400, display: 'block', marginTop: 8 }}>
                    websites with axium
                </span>
            </div>
        </div>
    )
}

/* ==========================================================
   9. TEXT HOVER EFFECT PREVIEW
   ========================================================== */
export function TextHoverEffectPreview() {
    const svgRef = useRef<SVGSVGElement>(null)
    const [hovered, setHovered] = useState(false)
    const mouseX = useMotionValue(50)
    const mouseY = useMotionValue(50)
    const maskImage = useMotionTemplate`radial-gradient(250px circle at ${mouseX}% ${mouseY}%, white 0%, transparent 100%)`

    return (
        <div className="txp-preview txp-hover-svg-wrapper"
            style={{ position: 'relative', overflow: 'hidden' }}
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => setHovered(false)}
            onMouseMove={(e) => {
                const r = e.currentTarget.getBoundingClientRect()
                mouseX.set(((e.clientX - r.left) / r.width) * 100)
                mouseY.set(((e.clientY - r.top) / r.height) * 100)
            }}>
            {/* Base text — always fully visible */}
            <h2 style={{
                fontSize: '4.5rem', fontWeight: 800, fontFamily: 'Inter, Helvetica, sans-serif',
                color: '#e5e5e5', letterSpacing: '-0.04em', textAlign: 'center',
                position: 'relative', zIndex: 1, userSelect: 'none', lineHeight: 1,
            }}>
                axium
            </h2>
            {/* Rainbow gradient overlay — follows cursor on hover */}
            <motion.h2
                style={{
                    fontSize: '4.5rem', fontWeight: 800, fontFamily: 'Inter, Helvetica, sans-serif',
                    letterSpacing: '-0.04em', textAlign: 'center',
                    position: 'absolute', inset: 0, zIndex: 2,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    lineHeight: 1, userSelect: 'none',
                    background: 'linear-gradient(90deg, #eab308, #ef4444, #ec4899, #3b82f6, #06b6d4, #8b5cf6)',
                    WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent',
                    WebkitMaskImage: hovered ? maskImage as any : 'none',
                    maskImage: hovered ? maskImage as any : 'none',
                    opacity: hovered ? 1 : 0,
                    transition: 'opacity 0.3s ease',
                }}
            >
                axium
            </motion.h2>
        </div>
    )
}

/* ==========================================================
   10. CONTAINER TEXT FLIP PREVIEW
   ========================================================== */
export function ContainerTextFlipPreview() {
    const words = ['better', 'modern', 'awesome', 'elegant']
    const [idx, setIdx] = useState(0)

    useEffect(() => {
        const t = setInterval(() => setIdx(i => (i + 1) % words.length), 2500)
        return () => clearInterval(t)
    }, [])

    return (
        <div className="txp-preview txp-container-flip">
            <motion.div className="txp-container-pill" layout key={words[idx]}>
                {words[idx].split('').map((l, i) => (
                    <motion.span key={i} style={{ display: 'inline-block' }}
                        initial={{ opacity: 0, filter: 'blur(10px)' }}
                        animate={{ opacity: 1, filter: 'blur(0px)' }}
                        transition={{ delay: i * 0.02 }}>
                        {l}
                    </motion.span>
                ))}
            </motion.div>
        </div>
    )
}

/* ==========================================================
   11. HERO HIGHLIGHT PREVIEW
   ========================================================== */
export function HeroHighlightPreview() {
    const mouseX = useMotionValue(0)
    const mouseY = useMotionValue(0)

    const dotDefault = `url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='16' height='16' fill='none'%3E%3Ccircle fill='%23404040' cx='10' cy='10' r='2.5'%3E%3C/circle%3E%3C/svg%3E")`
    const dotHover = `url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='16' height='16' fill='none'%3E%3Ccircle fill='%238183f4' cx='10' cy='10' r='2.5'%3E%3C/circle%3E%3C/svg%3E")`

    const maskImage = useMotionTemplate`radial-gradient(200px circle at ${mouseX}px ${mouseY}px, black 0%, transparent 100%)`

    return (
        <div className="txp-preview txp-hero-wrapper group"
            onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect()
                mouseX.set(e.clientX - rect.left)
                mouseY.set(e.clientY - rect.top)
            }}>
            {/* Default dots */}
            <div style={{ position: 'absolute', inset: 0, backgroundImage: dotDefault, pointerEvents: 'none' }} />
            {/* Hover dots with radial mask */}
            <motion.div
                className="pointer-events-none absolute inset-0 opacity-0 transition duration-300 group-hover:opacity-100"
                style={{ backgroundImage: dotHover, WebkitMaskImage: maskImage, maskImage: maskImage }}
            />
            <div className="txp-hero-text">
                Everything is far away. Everything is a{' '}
                <motion.span
                    initial={{ backgroundSize: '0% 100%' }}
                    animate={{ backgroundSize: '100% 100%' }}
                    transition={{ duration: 2, ease: 'linear', delay: 0.5 }}
                    style={{
                        backgroundRepeat: 'no-repeat', backgroundPosition: 'left center', display: 'inline',
                        borderRadius: '8px', padding: '2px 6px 4px',
                        backgroundImage: 'linear-gradient(to right, #6366f1, #8b5cf6)', color: '#fff'
                    }}>
                    copy, of a copy.
                </motion.span>
            </div>
        </div>
    )
}

/* ==========================================================
   12. TEXT REVEAL CARD PREVIEW
   ========================================================== */
export function TextRevealCardPreview() {
    return (
        <div className="txp-preview" style={{ background: '#0E0E10' }}>
            <div className="txp-reveal-card">
                <div className="txp-reveal-title">Sometimes, you just need to see it.</div>
                <div className="txp-reveal-desc">Hover over the card to reveal the hidden text.</div>
                <div className="txp-reveal-text-area">
                    <span className="txp-reveal-hidden">You know the business</span>
                    <span className="txp-reveal-shown">I know the chemistry</span>
                    <span className="txp-reveal-bar" />
                </div>
            </div>
        </div>
    )
}

/* ==========================================================
   13. TYPEWRITER EFFECT PREVIEW
   ========================================================== */
export function TypewriterEffectPreview() {
    const words = [
        { text: 'Build', className: '' },
        { text: 'awesome', className: '' },
        { text: 'apps', className: '' },
        { text: 'with', className: '' },
        { text: 'axium', className: 'text-blue-500' },
    ]
    const [scope, animate] = useAnimate()
    const isInView = useInView(scope)

    useEffect(() => {
        if (isInView) {
            animate('span', { display: 'inline-block', opacity: 1, width: 'fit-content' },
                { duration: 0.3, delay: stagger(0.1), ease: 'easeInOut' })
        }
    }, [isInView, animate])

    return (
        <div className="txp-preview" style={{ flexDirection: 'column', gap: 8, padding: 24 }}>
            <div style={{ fontSize: '2rem', fontWeight: 700, textAlign: 'center' }}>
                <motion.div ref={scope} className="inline">
                    {words.map((word, idx) => (
                        <div key={`word-${idx}`} className="inline-block">
                            {word.text.split('').map((char, index) => (
                                <motion.span
                                    key={`char-${index}`}
                                    className={`text-white opacity-0 hidden ${word.className}`}
                                >
                                    {char}
                                </motion.span>
                            ))}
                            &nbsp;
                        </div>
                    ))}
                </motion.div>
                <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.8, repeat: Infinity, repeatType: 'reverse' }}
                    className="inline-block rounded-sm w-[4px] h-6 bg-blue-500 ml-1 align-middle"
                />
            </div>
            <span style={{ fontSize: '0.85rem', color: '#525252' }}>Staggered character reveal with blinking cursor</span>
        </div>
    )
}
