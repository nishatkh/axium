import { useState, useEffect } from 'react'
import './Sidebar.css'

interface SidebarItem {
    id: string
    label: string
}

interface SidebarProps {
    items: SidebarItem[]
}

export default function Sidebar({ items }: SidebarProps) {
    const [activeId, setActiveId] = useState(items[0]?.id || '')

    useEffect(() => {
        const sections = items.map(i => document.getElementById(i.id)).filter(Boolean) as HTMLElement[]
        if (!sections.length) return

        const obs = new IntersectionObserver(entries => {
            entries.forEach(e => {
                if (e.isIntersecting) setActiveId(e.target.id)
            })
        }, { rootMargin: '-30% 0px -60% 0px' })

        sections.forEach(s => obs.observe(s))
        return () => obs.disconnect()
    }, [items])

    return (
        <aside className="sidebar">
            <nav className="sidebar__nav">
                <span className="sidebar__label">Components</span>
                {items.map(item => (
                    <a
                        key={item.id}
                        href={`#${item.id}`}
                        className={`sidebar__link ${activeId === item.id ? 'sidebar__link--active' : ''}`}
                        onClick={e => {
                            e.preventDefault()
                            document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
                        }}
                    >
                        {item.label}
                    </a>
                ))}
            </nav>
        </aside>
    )
}
